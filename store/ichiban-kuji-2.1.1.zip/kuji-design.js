/* ══════════════════════════════════════════════════════════════════════════
   이치방쿠지 전용 디자인 — 키 확인 + 구매한 HTML 을 디자인 팩으로 변환
   (제어판에서만 쓴다. 오버레이는 변환된 결과(design-*.json)만 읽는다)

   🔑 디자인 키
      KJ1.<내용>.<서명>   내용 = base64url(JSON {v, ext, sha256, name})
      서명 = 제작자 비밀 도장(ECDSA P-256)으로 <내용> 글자를 찍은 것.
      아래 PUBLIC_KEY 로 확인하므로 제작자 말고는 유효한 키를 만들 수 없다.
      sha256 은 구매한 HTML 파일의 지문이라 한 글자만 고쳐도 키가 안 맞는다.

   🎨 변환
      판매용 HTML 은 모두 같은 템플릿이라 쿠지판 뼈대가 오버레이와 같다.
      다른 곳만 옮겨 온다:
        css      <style> 통째 (그림은 파일로 빼서 {{A:이름}} 으로 바꿔 둔다)
        brand    #app 안 상단 로고 영역 (layout-toggle 다음 ~ setup-screen 전)
        modals   결과 팝업에 템플릿에 없는 장식 (예: 마스코트)
        face     쿠지 앞면 — 스크립트가 만드는 조각이라 스크립트를 "읽어서" 꺼낸다
        slots    스크립트가 innerHTML 로 끼워 넣는 마스코트 자리
        rankColor / rankText / confetti   스크립트 안의 색표
      구매한 파일의 스크립트는 실행하지 않는다. 꺼낸 마크업에서도 스크립트·on* 속성·
      외부 주소는 지운다.
   ══════════════════════════════════════════════════════════════════════════ */
(function (root) {
'use strict';

/* 제작자 공개키 — 디자인 키가 진짜인지 확인하는 데만 쓴다 (이걸로 키를 만들 수는 없다) */
var PUBLIC_KEY = {"crv":"P-256","ext":true,"key_ops":["verify"],"kty":"EC","x":"gKm9-3yglRG2ulok0PSdR45eUSBA_em6FNmH89jY2x8","y":"NISnwIlfmgAjxCNvhS8JrrP_XQuWx3nO1TqSTOXtzvY"};

var BIG_IMAGE = 350 * 1024;      // 이보다 큰 그림은 webp 로 다시 저장해 본다
var MAX_SIDE = 2560;

function b64uToBytes(s) {
    s = String(s).replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4) s += '=';
    var bin = atob(s), out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
}
function b64ToBlob(b64, mime) {
    var bin = atob(b64), out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return new Blob([out], { type: mime });
}
function hex(buf) {
    return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
}
function sha256Hex(buf) { return crypto.subtle.digest('SHA-256', buf).then(hex); }

function canCrypto() { return !!(root.crypto && root.crypto.subtle); }

/* ── 키 확인 ─────────────────────────────────────────────────────────────── */
function verifyKey(keyText, fileSha, extId) {
    var key = String(keyText || '').replace(/\s+/g, '');
    var m = key.match(/^KJ1\.([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/);
    if (!m) return Promise.reject('디자인 키 형식이 아니에요. 받은 키를 그대로 붙여 넣어 주세요.');
    var payload;
    try { payload = JSON.parse(new TextDecoder().decode(b64uToBytes(m[1]))); }
    catch (e) { return Promise.reject('디자인 키 형식이 아니에요. 받은 키를 그대로 붙여 넣어 주세요.'); }
    return crypto.subtle.importKey('jwk', PUBLIC_KEY, { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify'])
        .then(function (k) {
            return crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, k, b64uToBytes(m[2]), new TextEncoder().encode(m[1]));
        })
        .then(function (ok) {
            if (!ok) throw '올바른 디자인 키가 아니에요.';
            if (payload.ext && payload.ext !== extId) throw '이 확장모듈용 디자인 키가 아니에요.';
            if (String(payload.sha256 || '').toLowerCase() !== fileSha) throw '이 디자인 키는 다른 파일용이에요. 구매할 때 받은 파일을 그대로 넣어 주세요.';
            return payload;
        });
}

/* ── 정리 (스크립트·외부 주소 제거) ──────────────────────────────────────── */
var PH = /^\{\{A:[\w.-]+\}\}$/;
function okUrl(v) {
    v = String(v || '').trim();
    return PH.test(v) || v.charAt(0) === '#' || /^data:image\/(png|jpe?g|gif|webp|svg\+xml)[;,]/i.test(v);
}
function cleanCssText(css) {
    return String(css || '')
        .replace(/@import[^;]*;?/gi, '')
        .replace(/expression\s*\(/gi, '(')
        .replace(/url\(\s*(['"]?)([^)'"]*)\1\s*\)/gi, function (all, q, u) { return okUrl(u) ? all : 'none'; });
}
function cleanHtml(html) {
    var t = document.createElement('template');
    t.innerHTML = html || '';
    t.content.querySelectorAll('script,iframe,object,embed,link,meta,base,form,input,textarea,button,select,style,foreignObject')
        .forEach(function (n) { n.remove(); });
    t.content.querySelectorAll('*').forEach(function (el) {
        Array.prototype.slice.call(el.attributes).forEach(function (a) {
            var n = a.name.toLowerCase();
            if (n.indexOf('on') === 0) el.removeAttribute(a.name);
            else if ((n === 'src' || n === 'href' || n === 'xlink:href' || n === 'srcset' || n === 'action' || n === 'formaction') && !okUrl(a.value)) el.removeAttribute(a.name);
            else if (n === 'style') el.setAttribute('style', cleanCssText(a.value));
        });
    });
    return t.innerHTML;
}

/* ── 그림 빼내기 ─────────────────────────────────────────────────────────── */
var MIME_EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif',
                 'font/woff2': 'woff2', 'font/woff': 'woff', 'application/font-woff': 'woff', 'font/ttf': 'ttf' };

function shrink(blob) {
    if (blob.size <= BIG_IMAGE || !/^image\/(png|jpeg)$/.test(blob.type) || !root.createImageBitmap) return Promise.resolve(null);
    return createImageBitmap(blob).then(function (bmp) {
        var s = Math.min(1, MAX_SIDE / Math.max(bmp.width, bmp.height));
        var c = document.createElement('canvas');
        c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
        var g = c.getContext('2d');
        g.imageSmoothingEnabled = s < 1;
        g.drawImage(bmp, 0, 0, c.width, c.height);
        return new Promise(function (res) { c.toBlob(res, 'image/webp', 0.9); });
    }).then(function (w) { return w && w.size < blob.size * 0.8 ? w : null; }).catch(function () { return null; });
}

/* 원본 글자 전체에서 data: 그림을 찾아 {{A:이름}} 으로 바꾸고, 그림은 따로 모은다. */
function pullAssets(text) {
    var found = [], seen = {};
    var re = /data:([a-z]+\/[a-z0-9.+-]+);base64,([A-Za-z0-9+\/=]+)/gi, m;
    while ((m = re.exec(text))) {
        var mime = m[1].toLowerCase();
        if (!MIME_EXT[mime] || seen[m[0]]) continue;     // svg 등은 그대로 둔다 (그림으로만 쓰면 안전)
        seen[m[0]] = 1;
        found.push({ uri: m[0], mime: mime, b64: m[2] });
    }
    var assets = [];
    return found.reduce(function (p, f) {
        return p.then(function () {
            var blob = b64ToBlob(f.b64, f.mime);
            return shrink(blob).then(function (small) {
                var use = small || blob, ext = small ? 'webp' : MIME_EXT[f.mime];
                return use.arrayBuffer().then(sha256Hex).then(function (h) {
                    var name = 'kd-' + h.slice(0, 16) + '.' + ext;
                    if (!assets.some(function (a) { return a.name === name; })) assets.push({ name: name, blob: use });
                    text = text.split(f.uri).join('{{A:' + name + '}}');
                });
            });
        });
    }, Promise.resolve()).then(function () { return { text: text, assets: assets }; });
}

/* ── 스크립트 읽기 (실행하지 않는다) ─────────────────────────────────────── */
function unq(s) { return s.replace(/\\(.)/g, '$1'); }
function stringVars(js) {
    var out = {}, re = /\bvar\s+([A-Za-z_$][\w$]*)\s*=\s*(?:'((?:[^'\\]|\\.)*)'|"((?:[^"\\]|\\.)*)")\s*;/g, m;
    while ((m = re.exec(js))) out[m[1]] = unq(m[2] != null ? m[2] : m[3]);
    return out;
}
function joinExpr(seg, vars) {
    var out = '', re = /'((?:[^'\\]|\\.)*)'|"((?:[^"\\]|\\.)*)"|([A-Za-z_$][\w$]*)/g, m;
    while ((m = re.exec(seg))) {
        if (m[1] != null) out += unq(m[1]);
        else if (m[2] != null) out += unq(m[2]);
        else if (Object.prototype.hasOwnProperty.call(vars, m[3])) out += vars[m[3]];
    }
    return out;
}
function rankMap(js, name) {
    var m = js.match(new RegExp('\\bvar\\s+' + name + '\\s*=\\s*\\{([^}]*)\\}'));
    if (!m) return null;
    var out = {}, re = /([A-H])\s*:\s*['"]([^'"]+)['"]/g, x, n = 0;
    while ((x = re.exec(m[1]))) { out[x[1]] = x[2]; n++; }
    return n ? out : null;
}
function quoted(s) { return (String(s).match(/['"][^'"]+['"]/g) || []).map(function (q) { return q.slice(1, -1); }); }
function confetti(js) {
    var m = js.match(/var\s+colors\s*=\s*isTop\s*\?\s*\[([^\]]*)\]\s*:\s*\[([^\]]*)\]/);
    if (!m) return null;
    var top = quoted(m[1]), rest = quoted(m[2]);
    return top.length ? { top: top, other: rest.length ? rest[rest.length - 1] : top[0] } : null;
}
/* buildTicketEl 안의
       '<div class="ticket-face">' +  ……여기……  '<div class="ticket-no">No.' + ticketNo
   사이를 글자 조각·변수 이름 단위로 읽어 이어 붙인다. */
function faceHtml(js, vars) {
    var m = js.match(/ticket-face["']?\s*>(['"])/);
    if (!m) return null;
    var q = m[1], start = m.index + m[0].length;
    var end = js.indexOf(q + '<div class="ticket-no"', start);
    if (end < 0) end = js.indexOf(q + "<div class='ticket-no'", start);
    if (end < 0) return null;
    return joinExpr(js.slice(start, end), vars);
}
function slots(js, vars) {
    var out = [], m;
    var re1 = /querySelectorAll\(\s*['"]([^'"]+)['"]\s*\)\.forEach\(\s*function\s*\(\s*(\w+)\s*\)\s*\{\s*\2\.innerHTML\s*=\s*([A-Za-z_$][\w$]*)\s*;?\s*\}\s*\)/g;
    while ((m = re1.exec(js))) if (vars[m[3]] != null) out.push({ sel: m[1], html: vars[m[3]] });
    var re2 = /getElementById\(\s*['"]([\w-]+)['"]\s*\)\.innerHTML\s*=\s*([A-Za-z_$][\w$]*)\s*;/g;
    while ((m = re2.exec(js))) if (vars[m[2]] != null) out.push({ sel: '#' + m[1], html: vars[m[2]] });
    return out;
}

/* 결과 팝업 장식: 템플릿에 원래 있는 칸이 아닌 것만 옮긴다 */
var MODAL_BASE = {
    'reveal-modal':  ['reveal-badge', 'reveal-img', 'reveal-rank', 'reveal-name', 'reveal-close', 'reveal-who'],
    'lastone-modal': ['reveal-badge', 'reveal-img', 'reveal-rank', 'reveal-name', 'reveal-close'],
    'batch-modal':   ['batch-modal-title', 'batch-modal-sub', 'batch-modal-list', 'reveal-close']
};
function baseClass(el, base) {
    for (var i = 0; i < base.length; i++) if (el.classList && el.classList.contains(base[i])) return base[i];
    return null;
}
function modalExtras(doc) {
    var out = {};
    Object.keys(MODAL_BASE).forEach(function (id) {
        var m = doc.getElementById(id), inner = m && m.firstElementChild;
        if (!inner) return;
        var base = MODAL_BASE[id], kids = Array.prototype.slice.call(inner.children), list = [];
        kids.forEach(function (el, i) {
            if (baseClass(el, base)) return;
            var before = null;
            for (var j = i + 1; j < kids.length && !before; j++) before = baseClass(kids[j], base);
            var hidden = /display\s*:\s*none/i.test(el.getAttribute('style') || '');
            el.removeAttribute('id');
            list.push({ html: cleanHtml(el.outerHTML), before: before, noimg: hidden });
        });
        if (list.length) out[id] = list;
    });
    return out;
}
function brandHtml(doc) {
    var app = doc.getElementById('app');
    if (!app) return '';
    var out = '';
    for (var el = app.firstElementChild; el; el = el.nextElementSibling) {
        if (el.id === 'setup-screen' || el.id === 'draw-screen') break;
        if (el.classList.contains('layout-toggle')) continue;
        out += el.outerHTML;
    }
    return cleanHtml(out);
}

/* ── 변환 ─────────────────────────────────────────────────────────────────
   → Promise<{ pack, assets:[{name, blob}] }>  실패하면 한국어 사유로 reject */
function convert(htmlText) {
    if (!/ticket-face/.test(htmlText) || !/id=["']draw-screen["']/.test(htmlText)) {
        return Promise.reject('이치방쿠지 디자인 파일이 아니에요.');
    }
    return pullAssets(htmlText).then(function (r) {
        var doc = new DOMParser().parseFromString(r.text, 'text/html');
        var css = Array.prototype.map.call(doc.querySelectorAll('style'), function (s) { return s.textContent; }).join('\n');
        var js = Array.prototype.map.call(doc.querySelectorAll('script:not([src])'), function (s) { return s.textContent; }).join('\n');
        var vars = stringVars(js);
        var face = faceHtml(js, vars);
        var pack = {
            kind: 'kuji-design', v: 1,
            title: (doc.title || '').trim(),
            css: cleanCssText(css),
            brand: brandHtml(doc),
            modals: modalExtras(doc),
            face: face == null ? null : cleanHtml(face),
            slots: slots(js, vars).map(function (s) { return { sel: s.sel, html: cleanHtml(s.html) }; }),
            rankColor: rankMap(js, 'RANK_COLOR'),
            rankText: rankMap(js, 'RANK_TEXT'),
            confetti: confetti(js),
            fonts: Array.prototype.map.call(doc.querySelectorAll('link[rel="stylesheet"][href^="https://fonts.googleapis.com/"]'),
                function (l) { return l.getAttribute('href'); }),
            assets: r.assets.map(function (a) { return a.name; })
        };
        /* 변환 결과에 실제로 쓰인 그림만 남긴다 (설정 화면에만 쓰던 그림 등은 버린다) */
        var used = JSON.stringify(pack);
        var assets = r.assets.filter(function (a) { return used.indexOf('{{A:' + a.name + '}}') >= 0; });
        pack.assets = assets.map(function (a) { return a.name; });
        return { pack: pack, assets: assets };
    });
}

root.KujiDesign = { verifyKey: verifyKey, convert: convert, sha256Hex: sha256Hex, canCrypto: canCrypto };
})(window);
