/* 손님, 어디 계세요?! — 채팅·프로필 스킨
   제작자 전용 「스킨 작업실」(skin-editor.html)에서 저장하면 이 파일이 바뀌어요. */
window.PIZZA_SKIN = {
 "version": "6",
 "skins": [
  {
   "name": "셰프 모자",
   "bubble": {
    "img": "img/chat/chat-chef.png",
    "slice": [
     68,
     137,
     69,
     175
    ],
    "scale": 88,
    "inset": [
     42,
     82,
     27,
     92
    ],
    "repeat": "mirror stretch",
    "pixel": false,
    "padX": 0,
    "padY": 0,
    "fixedH": true,
    "lines": 2,
    "mid": 40
   },
   "gift": {
    "use": false
   },
   "sys": {
    "use": true,
    "img": "",
    "bg": "#C8372D",
    "borderColor": "#3A2418",
    "borderW": 3,
    "radius": 999,
    "padX": 18,
    "padY": 6,
    "textColor": "#ffffff"
   },
   "text": {
    "font": "Soomini",
    "size": 19,
    "nameSize": 19,
    "nameColor": "#C8372D",
    "textColor": "#3A2418",
    "nameMode": "hidden"
   },
   "pf": {
    "show": true,
    "size": 80,
    "side": "left",
    "gap": 2
   },
   "frame": {
    "img": "img/frames/frame-chef.png",
    "hole": {
     "x": 11.1,
     "y": 14.0,
     "w": 79.0,
     "h": 77.3,
     "r": 50
    },
    "bg": "#E85B8A"
   },
   "width": 460,
   "anim": "pop",
   "life": 25,
   "max": 6,
   "align": "bottom",
   "hAlign": "left",
   "gapY": 4,
   "idle": "float"
  },
  {
   "name": "화덕",
   "bubble": {
    "img": "img/chat/chat-oven.png",
    "slice": [
     73,
     157,
     74,
     150
    ],
    "scale": 88,
    "inset": [
     50,
     125,
     29,
     108
    ],
    "repeat": "mirror stretch",
    "pixel": false,
    "padX": 0,
    "padY": 0,
    "fixedH": true,
    "lines": 2,
    "mid": 50
   },
   "gift": {
    "use": false
   },
   "sys": {
    "use": true,
    "img": "",
    "bg": "#B5541F",
    "borderColor": "#3A2418",
    "borderW": 3,
    "radius": 999,
    "padX": 18,
    "padY": 6,
    "textColor": "#ffffff"
   },
   "text": {
    "font": "Soomini",
    "size": 19,
    "nameSize": 19,
    "nameColor": "#B5541F",
    "textColor": "#3A2418",
    "nameMode": "hidden"
   },
   "pf": {
    "show": true,
    "size": 80,
    "side": "left",
    "gap": 2
   },
   "frame": {
    "img": "img/frames/frame-oven.png",
    "hole": {
     "x": 14.2,
     "y": 20.8,
     "w": 73.6,
     "h": 66.0,
     "r": 50
    },
    "bg": "#F2A530"
   },
   "width": 460,
   "anim": "up",
   "life": 25,
   "max": 6,
   "align": "bottom",
   "hAlign": "left",
   "gapY": 4,
   "idle": "float"
  },
  {
   "name": "배달 스쿠터",
   "bubble": {
    "img": "img/chat/chat-delivery.png",
    "slice": [
     66,
     144,
     67,
     170
    ],
    "scale": 88,
    "inset": [
     44,
     104,
     27,
     104
    ],
    "repeat": "mirror stretch",
    "pixel": false,
    "padX": 0,
    "padY": 0,
    "fixedH": true,
    "lines": 2,
    "mid": 40
   },
   "gift": {
    "use": false
   },
   "sys": {
    "use": true,
    "img": "",
    "bg": "#3A2418",
    "borderColor": "#3A2418",
    "borderW": 3,
    "radius": 999,
    "padX": 18,
    "padY": 6,
    "textColor": "#ffffff"
   },
   "text": {
    "font": "Soomini",
    "size": 19,
    "nameSize": 19,
    "nameColor": "#C8372D",
    "textColor": "#3A2418",
    "nameMode": "hidden"
   },
   "pf": {
    "show": true,
    "size": 80,
    "side": "left",
    "gap": 2
   },
   "frame": {
    "img": "img/frames/frame-delivery.png",
    "hole": {
     "x": 9.8,
     "y": 15.4,
     "w": 78.1,
     "h": 74.6,
     "r": 50
    },
    "bg": "#6A8FD8"
   },
   "width": 460,
   "anim": "right",
   "life": 25,
   "max": 6,
   "align": "bottom",
   "hAlign": "left",
   "gapY": 4,
   "idle": "float"
  },
  {
   "name": "치즈 듬뿍",
   "bubble": {
    "img": "img/chat/chat-cheese.png",
    "slice": [
     70,
     139,
     70,
     140
    ],
    "scale": 88,
    "inset": [
     37,
     82,
     29,
     100
    ],
    "repeat": "mirror stretch",
    "pixel": false,
    "padX": 0,
    "padY": 0,
    "fixedH": true,
    "lines": 2,
    "mid": 70
   },
   "gift": {
    "use": false
   },
   "sys": {
    "use": true,
    "img": "",
    "bg": "#E0A21E",
    "borderColor": "#3A2418",
    "borderW": 3,
    "radius": 999,
    "padX": 18,
    "padY": 6,
    "textColor": "#ffffff"
   },
   "text": {
    "font": "Soomini",
    "size": 19,
    "nameSize": 19,
    "nameColor": "#A8680E",
    "textColor": "#3A2418",
    "nameMode": "hidden"
   },
   "pf": {
    "show": true,
    "size": 80,
    "side": "left",
    "gap": 2
   },
   "frame": {
    "img": "img/frames/frame-cheese.png",
    "hole": {
     "x": 9.7,
     "y": 10.7,
     "w": 78.9,
     "h": 76.9,
     "r": 50
    },
    "bg": "#F2A530"
   },
   "width": 460,
   "anim": "pop",
   "life": 25,
   "max": 6,
   "align": "bottom",
   "hAlign": "left",
   "gapY": 4,
   "idle": "float"
  },
  {
   "name": "피자 가게",
   "bubble": {
    "img": "img/chat/chat-shop.png",
    "slice": [
     67,
     174,
     68,
     125
    ],
    "scale": 88,
    "inset": [
     49,
     86,
     27,
     54
    ],
    "repeat": "mirror stretch",
    "pixel": false,
    "padX": 0,
    "padY": 0,
    "fixedH": true,
    "lines": 2,
    "mid": 50
   },
   "gift": {
    "use": false
   },
   "sys": {
    "use": true,
    "img": "",
    "bg": "#2E7A4A",
    "borderColor": "#3A2418",
    "borderW": 3,
    "radius": 999,
    "padX": 18,
    "padY": 6,
    "textColor": "#ffffff"
   },
   "text": {
    "font": "Soomini",
    "size": 19,
    "nameSize": 19,
    "nameColor": "#A0522D",
    "textColor": "#3A2418",
    "nameMode": "hidden"
   },
   "pf": {
    "show": true,
    "size": 80,
    "side": "left",
    "gap": 2
   },
   "frame": {
    "img": "img/frames/frame-shop.png",
    "hole": {
     "x": 11.8,
     "y": 31.5,
     "w": 77.6,
     "h": 58.1,
     "r": 50
    },
    "bg": "#4FAE4A"
   },
   "width": 460,
   "anim": "up",
   "life": 25,
   "max": 6,
   "align": "bottom",
   "hAlign": "left",
   "gapY": 4,
   "idle": "float"
  }
 ]
};
