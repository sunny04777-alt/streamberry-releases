/* 손님, 어디 계세요?! — 채팅 말풍선 · 프로필 프레임 그리기
   오버레이(채팅 화면)와 스킨 작업실이 같이 쓴다. 스킨 모양은 skin.js 에 있다. */
(function () {
'use strict';
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
/* 🔒 그림 주소는 http(s)·같은 서버(/…)·익스텐션 안(img/…)·스킨 작업실이 넣은 data:image 만 받는다.
   따옴표·괄호·공백 같은 글자는 모두 %인코딩 — style="" 속성이나 CSS url() 밖으로 못 나간다 */
function safeUrl(u) {
  u = String(u == null ? '' : u).trim();
  if (!/^(https?:\/\/|\/|img\/|data:image\/(png|jpeg|gif|webp);base64,)/i.test(u)) return '';
  return u.replace(/[\s"'()<>\\`]/g, function (c) { return '%' + c.charCodeAt(0).toString(16).toUpperCase().padStart(2, '0'); });
}
function url(u) { var s = safeUrl(u); return s ? "url('" + s + "')" : 'none'; }
var FONTS = { 'Soomini':"'Soomini','Jua',sans-serif", 'Jua':"'Jua',sans-serif", 'Gaegu':"'Gaegu',cursive", 'Do Hyeon':"'Do Hyeon',sans-serif", 'Gowun Dodum':"'Gowun Dodum',sans-serif", 'Noto Sans KR':"'Noto Sans KR',sans-serif", 'Dongle':"'Dongle',sans-serif", 'Hi Melody':"'Hi Melody',cursive" };
var FONT_LINK = 'https://fonts.googleapis.com/css2?family=Jua&family=Gaegu:wght@400;700&family=Do+Hyeon&family=Gowun+Dodum&family=Noto+Sans+KR:wght@400;700&family=Dongle:wght@400;700&family=Hi+Melody&display=swap';

var DEF_FRAME = { img:'img/frame-pizza.png', hole:{ x:17, y:17, w:66, h:66, r:50 }, bg:'#E85B8A', initial:'#ffffff' };
var DEF_BUBBLE = { img:'', slice:32, bw:24, repeat:'stretch', pixel:false, bg:'#FFFDF6', borderColor:'#C8372D', borderW:3, radius:16, shadow:0, shadowColor:'#3A2418', padX:14, padY:8 };

function frameOf(skin) { var f = (skin && skin.frame) || {}; return { img:f.img != null ? f.img : DEF_FRAME.img, hole:Object.assign({}, DEF_FRAME.hole, f.hole || {}), bg:f.bg || DEF_FRAME.bg, initial:f.initial || DEF_FRAME.initial }; }

/* 프로필 프레임 — 사진이 구멍 자리에 들어가고 프레임 그림이 그 위에 덮인다 */
function frame(skin, who, size) {
  var f = frameOf(skin), h = f.hole; who = who || {};
  var pic = '<span class="pzc-pic" style="position:absolute;left:' + h.x + '%;top:' + h.y + '%;width:' + h.w + '%;height:' + h.h + '%;border-radius:' + h.r + '%;overflow:hidden;' +
    'background:' + f.bg + (safeUrl(who.pfp) ? ' ' + url(who.pfp) + ' center/cover no-repeat' : '') + ';display:flex;align-items:center;justify-content:center;color:' + f.initial + ';font-family:' + FONTS.Soomini + ';font-size:' + Math.round(size * h.w / 100 * 0.5) + 'px">' +
    (who.pfp ? '' : esc(String(who.user || '?').charAt(0))) + '</span>';
  return '<span class="pzc-frame" style="position:relative;display:inline-block;flex-shrink:0;width:' + size + 'px;height:' + size + 'px">' + pic +
    (f.img ? '<img src="' + esc(f.img) + '" alt="" style="position:absolute;inset:0;width:100%;height:100%;pointer-events:none">' : '') + '</span>';
}

function four(v, d) { if (Array.isArray(v)) return [0, 1, 2, 3].map(function (i) { return +v[i] || 0; }); var n = v != null ? +v : d; return [n, n, n, n]; }
/* 9조각 그림 정보 — 캔버스로 한 장에 그린다 (border-image 는 OBS 배율에서 조각 사이가 격자처럼 벌어져서) */
function nineAttr(b) {
  b = Object.assign({}, DEF_BUBBLE, b || {});
  if (!b.img || !safeUrl(b.img)) return '';
  var sl = four(b.slice, 32), d;
  if (b.scale) { var k = b.scale / 100, ins = four(b.inset, 0); d = sl.map(function (v) { return Math.round(v * k); }); return ' data-nine="' + esc(JSON.stringify({ img:safeUrl(b.img), sl:sl, d:d, ins:ins.map(function (v) { return Math.round(v * k); }), px:!!b.pixel, rp:String(b.repeat || '').split(' ')[0], k:k })) + '"'; }
  d = [b.bw, b.bw, b.bw, b.bw]; return ' data-nine="' + esc(JSON.stringify({ img:safeUrl(b.img), sl:sl, d:d, ins:d, px:!!b.pixel, rp:String(b.repeat || '').split(' ')[0], k:sl[3] ? b.bw / sl[3] : 1 })) + '"';
}
var IMGS = {};
function loadImg(src, cb) {
  var e = IMGS[src];
  if (e && e.ok) { cb(e.im); return; }
  if (!e) { e = IMGS[src] = { im:new Image(), ok:false, q:[] }; e.im.onload = function () { e.ok = true; e.q.forEach(function (f) { f(e.im); }); e.q = []; }; e.im.src = src; }
  e.q.push(cb);
}
function paintOne(el) {
  var info; try { info = JSON.parse(el.getAttribute('data-nine')); } catch (x) { return; }
  loadImg(info.img, function (im) {
    var W = el.offsetWidth, H = el.offsetHeight; if (!W || !H) return;
    var r = el.getBoundingClientRect(), sc = Math.max(1, Math.min(4, (window.devicePixelRatio || 1) * Math.max(r.width / W, r.height / H, 1)));
    sc = Math.ceil(sc * 2) / 2;
    var cv = el.querySelector(':scope>canvas.pzc-nine');
    if (!cv) { cv = document.createElement('canvas'); cv.className = 'pzc-nine'; cv.setAttribute('aria-hidden', 'true'); el.insertBefore(cv, el.firstChild); }
    var key = W + 'x' + H + '@' + sc; if (cv._k === key) return; cv._k = key;
    cv.width = Math.round(W * sc); cv.height = Math.round(H * sc);
    cv.style.cssText = 'position:absolute;left:' + (-info.ins[3]) + 'px;top:' + (-info.ins[0]) + 'px;width:' + W + 'px;height:' + H + 'px;z-index:-1;pointer-events:none;' + (info.px ? 'image-rendering:pixelated;' : '');
    var c = cv.getContext('2d'); c.imageSmoothingEnabled = !info.px; c.clearRect(0, 0, cv.width, cv.height);
    var iw = im.naturalWidth, ih = im.naturalHeight, s = info.sl, d = info.d;
    var sx = [0, s[3], iw - s[1], iw], sy = [0, s[0], ih - s[2], ih];
    /* 그릴 자리는 기기 픽셀 단위 정수로 — 조각끼리 딱 맞붙어 틈이 안 생긴다 */
    var dx = [0, Math.round(d[3] * sc), Math.round((W - d[1]) * sc), cv.width], dy = [0, Math.round(d[0] * sc), Math.round((H - d[2]) * sc), cv.height];
    for (var y = 0; y < 3; y++) for (var x = 0; x < 3; x++) {
      var sw = sx[x + 1] - sx[x], sh = sy[y + 1] - sy[y], w = dx[x + 1] - dx[x], h = dy[y + 1] - dy[y];
      if (!(sw > 0 && sh > 0 && w > 0 && h > 0)) continue;
      if (x === 1 && info.rp === 'mirror') {
        /* 가운데는 늘리지 않고, 무늬 조각을 거울처럼 번갈아 이어 붙인다 (홀수 개 → 양 끝이 좌우 조각과 딱 맞는다) */
        var tw = sw * (info.k || 1) * sc, n = Math.max(1, Math.round(w / tw)); if (n % 2 === 0) n += (w / tw > n ? 1 : -1); if (n < 1) n = 1;
        for (var i = 0; i < n; i++) {
          var a = dx[1] + Math.round(i * w / n), b2 = dx[1] + Math.round((i + 1) * w / n);
          if (i % 2) { c.save(); c.translate(a + b2, 0); c.scale(-1, 1); c.drawImage(im, sx[x], sy[y], sw, sh, a, dy[y], b2 - a, h); c.restore(); }
          else c.drawImage(im, sx[x], sy[y], sw, sh, a, dy[y], b2 - a, h);
        }
      } else c.drawImage(im, sx[x], sy[y], sw, sh, dx[x], dy[y], w, h);
    }
  });
}
var RO = window.ResizeObserver ? new ResizeObserver(function (es) { es.forEach(function (e) { paintOne(e.target); }); }) : null;
function paint(root) {
  (root || document).querySelectorAll('.pzc-bub[data-nine]').forEach(function (el) { if (!el._nine) { el._nine = 1; if (RO) RO.observe(el); } paintOne(el); });
}
/* 새 말풍선이 붙으면 알아서 그린다 — 부르는 쪽은 신경 쓸 필요 없음 */
if (window.MutationObserver) {
  var pend = false, mo = new MutationObserver(function () { if (pend) return; pend = true; requestAnimationFrame(function () { pend = false; paint(document); }); });
  var startMO = function () { mo.observe(document.body, { childList:true, subtree:true }); paint(document); };
  if (document.body) startMO(); else document.addEventListener('DOMContentLoaded', startMO);
}
if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { paint(document); });
function bubbleCss(b) {
  b = Object.assign({}, DEF_BUBBLE, b || {});
  var s = 'box-sizing:border-box;display:flex;flex-direction:column;justify-content:center;';
  if (b.img && b.scale) {
    /* 큰 그림 말풍선: 그림은 배율대로 그리고, 글자는 안쪽 크림색 자리(inset)에만 */
    var k = b.scale / 100, sl = four(b.slice, 32), ins = four(b.inset, 0), px = function (a) { return a.map(function (v) { return Math.round(v * k) + 'px'; }).join(' '); };
    s += 'border-style:solid;border-color:transparent;border-width:' + px(ins) + ';position:relative;isolation:isolate;' +
      'min-width:' + Math.round((sl[1] + sl[3] + (String(b.repeat || '').split(' ')[0] === 'mirror' ? (+b.mid || 0) : 0)) * k) + 'px;' + (b.fixedH ? 'height:' + (Math.round(sl[0] * k) + Math.round(sl[2] * k)) : 'min-height:' + Math.round((sl[0] + sl[2]) * k)) + 'px;image-rendering:' + (b.pixel ? 'pixelated' : 'auto') + ';background:none;padding:' + b.padY + 'px ' + b.padX + 'px;';
  } else if (b.img) {
    s += 'padding:' + b.padY + 'px ' + b.padX + 'px;border-style:solid;border-color:transparent;border-width:' + b.bw + 'px;position:relative;isolation:isolate;background:none;';
  } else s += 'padding:' + b.padY + 'px ' + b.padX + 'px;background:' + b.bg + ';border:' + b.borderW + 'px solid ' + b.borderColor + ';border-radius:' + b.radius + 'px;';
  if (b.shadow) s += 'filter:drop-shadow(' + b.shadow + 'px ' + b.shadow + 'px 0 ' + b.shadowColor + ');';
  return s;
}

/* 말풍선 한 줄 — kind: '' 보통 · 'gift' 후원·부스트 · 'sys' 게임 알림 */
function line(skin, who, html, kind) {
  skin = skin || {};
  var t = skin.text || {}, pf = skin.pf || {}, kb = kind && skin[kind] && skin[kind].use ? skin[kind] : null;
  var b = kb || skin.bubble, font = FONTS[t.font] || FONTS.Soomini, nameColor = (kb && kb.nameColor) || t.nameColor || '#C8372D', textColor = (kb && kb.textColor) || t.textColor || '#3A2418';
  var nameMode = t.nameMode || 'inside', showPf = who && pf.show !== false && kind !== 'sys', side = pf.side === 'right' ? 'right' : 'left';
  var name = who && nameMode !== 'hidden' ? esc(who.user) : '';
  var clamp = b && b.fixedH ? 'display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:' + (b.lines || 2) + ';overflow:hidden;' : '';
  var nm = '<b style="font-weight:400;font-size:' + (t.nameSize || 16) + 'px;color:' + nameColor + ';font-family:' + font + '">' + name + '</b>';
  var inner = (name && nameMode === 'inside' ? nm.replace('<b style="', '<b style="display:block;') : '') +
    '<span style="font-size:' + (t.size || 20) + 'px;color:' + textColor + ';line-height:1.3;' + clamp + '">' + (name && nameMode === 'inline' ? nm + ' ' : '') + html + '</span>';
  /* 그림 말풍선은 양옆 장식 폭이 스킨마다 달라서, 글자 자리가 너무 좁아지지 않게 장식이 두꺼운 만큼 최대 폭을 늘려 준다 */
  var extra = 0; if (b && b.img && b.scale) { var bi = four(b.inset, 0); extra = Math.max(0, Math.round((bi[1] + bi[3]) * b.scale / 100) - 120); }
  var bub = '<div class="pzc-bub"' + nineAttr(b) + ' style="' + bubbleCss(b) + 'max-width:' + ((skin.width || 420) + extra) + 'px;word-break:break-all;font-family:' + font + ';text-align:' + (kind === 'sys' ? 'center' : 'left') + '">' + inner + '</div>';
  var col = '<div style="display:flex;flex-direction:column;align-items:' + (side === 'right' ? 'flex-end' : 'flex-start') + ';gap:2px;min-width:0">' +
    (name && nameMode === 'above' ? '<span style="font-family:' + font + ';font-size:' + (t.nameSize || 16) + 'px;color:' + (t.tagText || '#fff') + ';background:' + (t.tagBg || nameColor) + ';padding:1px 10px;border-radius:999px;margin-' + side + ':6px">' + name + '</span>' : '') + bub + '</div>';
  return '<div class="pzc-line pzc-' + (kind || 'chat') + '" style="display:flex;align-items:' + (pf.valign === 'top' ? 'flex-start' : 'center') + ';gap:' + (pf.gap != null ? pf.gap : 8) + 'px;flex-direction:' + (side === 'right' ? 'row-reverse' : 'row') + (kind === 'sys' ? ';justify-content:center' : '') + '">' +
    (showPf ? frame(skin, who, pf.size || 58) : '') + col + '</div>';
}

/* 등장 움직임 */
var ANIM = {
  up:'@keyframes pzcIn{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:none}}',
  pop:'@keyframes pzcIn{0%{opacity:0;transform:scale(.4)}65%{opacity:1;transform:scale(1.08)}100%{transform:scale(1)}}',
  left:'@keyframes pzcIn{from{opacity:0;transform:translateX(-60px)}to{opacity:1;transform:none}}',
  right:'@keyframes pzcIn{from{opacity:0;transform:translateX(60px)}to{opacity:1;transform:none}}',
  fade:'@keyframes pzcIn{from{opacity:0}to{opacity:1}}',
  bounce:'@keyframes pzcIn{0%{opacity:0;transform:translateY(-30px)}50%{opacity:1;transform:translateY(6px)}75%{transform:translateY(-3px)}100%{transform:none}}'
};
/* 떠 있는 동안 움직임 — 말풍선은 살랑살랑, 프로필은 살짝 따라 움직인다. 줄마다 박자를 어긋나게 */
var IDLE = {
  float:'@keyframes pzcIdle{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}@keyframes pzcPf{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-3px) rotate(-4deg)}}',
  wobble:'@keyframes pzcIdle{0%,100%{transform:rotate(0)}25%{transform:rotate(-1.6deg)}75%{transform:rotate(1.6deg)}}@keyframes pzcPf{0%,100%{transform:rotate(0)}25%{transform:rotate(6deg)}75%{transform:rotate(-6deg)}}',
  bounce:'@keyframes pzcIdle{0%,60%,100%{transform:translateY(0) scale(1)}70%{transform:translateY(-8px) scale(1.03,.97)}80%{transform:translateY(0) scale(.98,1.02)}}@keyframes pzcPf{0%,60%,100%{transform:translateY(0)}72%{transform:translateY(-10px)}}',
  breathe:'@keyframes pzcIdle{0%,100%{transform:scale(1)}50%{transform:scale(1.035)}}@keyframes pzcPf{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}'
};
var IDLE_SEC = { float:2.6, wobble:2.2, bounce:2.4, breathe:3 };
function animCss(skin) {
  var idle = (skin && skin.idle) || 'float', css = (ANIM[(skin && skin.anim) || 'up'] || ANIM.up) + '.pzc-line{animation:pzcIn .4s ease-out both}.pzc-line.out{transition:opacity .6s,transform .6s;opacity:0;transform:translateY(-10px)}';
  if (IDLE[idle]) {
    var s = IDLE_SEC[idle];
    css += IDLE[idle] + '.pzc-bub{animation:pzcIdle ' + s + 's ease-in-out .5s infinite;transform-origin:20% 60%}.pzc-frame{animation:pzcPf ' + s + 's ease-in-out .5s infinite}';
    for (var i = 1; i <= 6; i++) css += '.pzc-line:nth-child(6n+' + i + ') .pzc-bub,.pzc-line:nth-child(6n+' + i + ') .pzc-frame{animation-delay:' + (0.5 + i * 0.37).toFixed(2) + 's}';
  }
  return css;
}

/* 방송자가 제어판에서 고른 값(글꼴·크기·줄 수·너비·유지 시간)을 스킨 위에 덮는다.
   글자 크기를 바꾸면 말풍선 그림·프로필도 같은 비율로 커져서 장식과 글자가 안 어긋난다. */
function applyOpts(skin, o) {
  var s = JSON.parse(JSON.stringify(skin || {})); o = o || {};
  s.text = s.text || {}; s.pf = s.pf || {};
  if (o.chatFont && FONTS[o.chatFont]) s.text.font = o.chatFont;
  if (+o.chatSize > 0) {
    var base = +s.text.size || 20, k = +o.chatSize / base;
    s.text.size = +o.chatSize; s.text.nameSize = Math.round((+s.text.nameSize || 16) * k);
    ['bubble', 'gift', 'sys'].forEach(function (n) {
      var b = s[n]; if (!b) return;
      if (b.img && b.scale) b.scale = b.scale * k;
      else { if (b.padX != null) b.padX = Math.round(b.padX * k); if (b.padY != null) b.padY = Math.round(b.padY * k); }
    });
    s.pf.size = Math.round((+s.pf.size || 58) * k);
  }
  if (+o.chatMax > 0) s.max = +o.chatMax;
  if (+o.chatWidth > 0) s.width = +o.chatWidth;
  if (o.chatLife != null && o.chatLife !== '') s.life = +o.chatLife;
  if (o.chatIdle) s.idle = o.chatIdle;
  return s;
}

window.PizzaChat = { safeUrl:safeUrl, applyOpts:applyOpts, four:four, esc:esc, frame:frame, line:line, animCss:animCss, frameOf:frameOf, paint:paint, nineAttr:nineAttr, FONTS:FONTS, FONT_LINK:FONT_LINK, DEF_BUBBLE:DEF_BUBBLE, DEF_FRAME:DEF_FRAME };
})();
