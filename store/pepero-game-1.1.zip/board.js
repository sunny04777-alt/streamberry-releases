/* ================================================================
   빼빼로 게임 — 기록 계산 (게임 화면·랭킹 화면·제어판이 함께 쓴다)
   ================================================================
   세 화면이 따로 계산하면 순위가 서로 어긋난다. 여기 하나만 고친다.
   입력은 ZepetoExt.records.list({all:true}) 가 주는 배열 그대로.
   ================================================================ */
(function (global) {
    'use strict';

    /* 길이 표기 — 멀면 cm, 가까우면 mm·μm·nm 까지 */
    function fmtLen(cm) {
        cm = Math.max(0, +cm || 0);
        if (cm === 0) return '0cm';            // 한 입도 안 먹었다 ("0.000nm" 으로 보이던 것)
        var v, u;
        if (cm >= 1) { v = cm; u = 'cm'; }
        else if (cm >= 0.1) { v = cm * 10; u = 'mm'; }
        else if (cm >= 0.0001) { v = cm * 1e4; u = 'μm'; }
        else { v = cm * 1e7; u = 'nm'; }
        return (v >= 100 ? v.toFixed(1) : v >= 10 ? v.toFixed(2) : v.toFixed(3)) + u;
    }

    /* 마지막 '새로 시작' 표시 이후의 판 결과만 (지난 기록은 지우지 않는다) */
    function matchesSince(recs, resetType) {
        var since = 0;
        (recs || []).forEach(function (r) {
            if ((r.data || {}).t === resetType) since = Math.max(since, r.ts || 0);
        });
        return (recs || []).filter(function (r) {
            return (r.data || {}).t === 'match' && (r.ts || 0) >= since;
        }).sort(function (a, b) { return (a.ts || 0) - (b.ts || 0); });
    }

    /* 🏆 명예의 전당 — 쪽! 없이 끝난 판 중 남은 빼빼로가 짧은 순 */
    function hall(recs, limit) {
        return matchesSince(recs, 'hallreset')
            .map(function (r) { return r.data; })
            .filter(function (d) { return d.how === 'stop'; })
            .sort(function (a, b) { return a.remain - b.remain; })
            .slice(0, limit || 10);
    }

    /* 👑 우승 랭킹 — 많이 이긴 순. 사람은 sender_id(기록의 id)로 센다 — 닉을 바꿔도 한 사람.
       같은 승수면 판을 적게 한 사람(승률 높은 쪽), 그것도 같으면 먼저 그 승수에 닿은 사람이 위. */
    function ranking(recs, limit) {
        var by = {};
        matchesSince(recs, 'rankreset').forEach(function (r) {
            var d = r.data, sides = { a: d.a, b: d.b };
            ['a', 'b'].forEach(function (s) {
                var p = sides[s];
                if (!p || !p.id) return;
                var x = by[p.id] || (by[p.id] = { id: p.id, name: p.name || '시청자', wins: 0, games: 0, at: 0 });
                if (p.name) x.name = p.name;              // 가장 최근 닉네임으로 보여 준다
                x.games++;
                if (d.winner === s) { x.wins++; x.at = r.ts || 0; }
            });
        });
        return Object.keys(by).map(function (k) { return by[k]; })
            .filter(function (x) { return x.wins > 0; })
            .sort(function (a, b) { return b.wins - a.wins || a.games - b.games || a.at - b.at; })
            .slice(0, limit || 10);
    }

    global.PeperoBoard = { fmtLen: fmtLen, hall: hall, ranking: ranking };
})(window);
