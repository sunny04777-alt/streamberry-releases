/* ═══════════════════════════════════════════════════════════════════════
   피피 공용 코어 — 제어판과 오버레이가 함께 씁니다.
   테마 · 글꼴 · 캐릭터 그림 · 카드 디자인 CSS · 효과음 · 대사 문법
   (SDK 를 부르지 않습니다. SDK 호출은 전부 각 화면의 ZepetoExt.ready() 안에 있습니다.)
   ═══════════════════════════════════════════════════════════════════════ */
(function (root) {
'use strict';
var P = root.PIPI = root.PIPI || {};

P.VERSION = '3.1';
P.FRIENDLY = root.PIPI_MODE === 'friendly';   // 배포판: 단계 0 고정, 효과 없음
P.STAGES = [{ name: '다정함', desc: '' }, { name: '-', desc: '' }, { name: '-', desc: '' }, { name: '-', desc: '' }, { name: '-', desc: '' }];

/* 제어판과 오버레이가 같은 기본값을 쓰도록 여기 한 곳에만 둡니다 */
P.DEFAULT_CFG = {
    streamer: '', weather: 'sunny', season: 'auto',
    idleSec: 80, talkCmd: '!피피', joinCmd: '!참가', patCmd: '!쓰담', replyCooldown: 15, greetNew: true,
    patDelay: false, quietMin: 4, milestones: true, hourly: true,
    horrorStart: 30, horrorSpeed: 1, ambient: true,
    donMode: 'threshold', donMin: 100, donItems: ['하트팝'], boostReact: true,
    theme: 'retro', font: '', fontSize: 24,
    layout: { pp: { x: 36, y: 150, s: 1 }, gm: { x: 36, y: 430, s: 1 }, gd: { x: 200, y: 640, s: 1 } },
    merged: false, hideChar: false, hideTitle: false, hideMood: false, idleMode: 'show',
    zone: { x: 190, y: 560, w: 700, h: 1360, show: false },
    vol: { master: 0.7, type: 0.55, sfx: 0.7, amb: 0.5, music: 0.6 }, voice: 'click', sfxSet: 'cute',
    cardW: 520, cardHfix: false, cardH: 180, charSize: 132, gmW: 520, gdW: 680,
    cuteFreq: 2, cuteEvents: true, extraCmds: true, costumeCmd: true, costumeOff: [], customCostumes: [], doodleCmd: true, doodleAuto: true, holidays: true, holidayCostume: true, forgiveCmd: true, streamerChat: true, celebCmd: true, toyCmd: true, tagCmd: true, gossipCmd: true, friendCmd: true, contestVote: true, foodCmd: true, badgeGreet: true, viewerMs: true, scoldKind: 'random', scoldSec: 60,
    face: { on: false, x: 540, y: 1300, w: 340, h: 420, el: { x: 478, y: 1270 }, er: { x: 602, y: 1270 }, eye: 24, nose: { x: 540, y: 1335 }, mouth: { x: 540, y: 1400, w: 110 } },
    faceCmd: true, faceAuto: true, faceOff: [], cuteOff: [], fxOff: [], musicCmd: true, tickleCmd: true, replyShow: true, cuteFull: true,
    fx: { level: 2, full: true, safe: false },
    guide: { show: false, auto: true, sec: 8 },
    useImg: false, charImgs: { base: '', talk: '', uneasy: '', broken: '' },
    joinSec: 0, gameLen: 1, careCmds: true, quietMin: 4,
    modpacks: []
};
/* 얼굴 낙서 종류 (오버레이 그림과 제어판 목록이 함께 씀) */
P.FACE_DOODLE_LIST = [['glasses', '👓 동그란 안경'], ['mustache', '🥸 콧수염'], ['cat', '🐱 고양이 변신'], ['clown', '🔴 빨간 코'], ['blush', '☺️ 볼터치'], ['brows', '😠 진한 눈썹'],
    ['stareyes', '🤩 별 눈'], ['crown', '👑 왕관'], ['horns', '😈 꼬마 악마 뿔'], ['tears', '😭 눈물 콸콸'], ['mask', '🦸 히어로 가면'], ['bunny', '🐰 토끼 변신'],
    ['puppy', '🐶 강아지 변신'], ['swirl', '😵 빙글빙글 눈'], ['beard', '🧙 산신령 수염'], ['forehead', '✍️ 이마에 이름'],
    ['freckles', '🟤 주근깨'], ['hearteyes', '😍 하트 눈'], ['sunglasses', '😎 선글라스'], ['bow', '🎀 리본 핀'], ['flowercrown', '🌼 꽃 화관'], ['halo', '😇 천사 링'], ['pirate', '🏴‍☠️ 해적 안대'],
    ['monocle', '🧐 신사 외알 안경'], ['fangs', '🧛 드라큘라 송곳니'], ['sleepy', '😪 졸린 눈'], ['pignose', '🐷 돼지코'], ['alien', '👽 외계인 더듬이'], ['bandage', '🩹 반창고'], ['sweat', '😅 식은땀']];
P.OBJ_KEYS = ['layout', 'zone', 'vol', 'fx', 'guide', 'charImgs', 'face'];
P.mergeCfg = function (cfg, c) {
    if (!c || typeof c !== 'object') return cfg;
    Object.keys(P.DEFAULT_CFG).forEach(function (k) {
        if (c[k] === undefined || c[k] === null) return;
        if (P.OBJ_KEYS.indexOf(k) >= 0 && typeof c[k] === 'object') {
            if (k === 'layout') ['pp', 'gm', 'gd'].forEach(function (w) { if (c.layout[w]) cfg.layout[w] = Object.assign({}, cfg.layout[w], c.layout[w]); });
            else cfg[k] = Object.assign({}, cfg[k], c[k]);
        } else cfg[k] = c[k];
    });
    return cfg;
};
P.freshCfg = function () { return JSON.parse(JSON.stringify(P.DEFAULT_CFG)); };

P.WEATHERS = [
    { id: 'sunny', name: '맑음', icon: '☀️' }, { id: 'cloudy', name: '흐림', icon: '☁️' },
    { id: 'rain', name: '비', icon: '🌧️' }, { id: 'snow', name: '눈', icon: '❄️' },
    { id: 'wind', name: '바람', icon: '🍃' }, { id: 'fog', name: '안개', icon: '🌫️' },
    { id: 'hot', name: '무더위', icon: '🥵' }, { id: 'cold', name: '한파', icon: '🧊' },
    { id: 'storm', name: '천둥번개', icon: '⛈️' }
];
P.SEASONS = [
    { id: 'spring', name: '봄' }, { id: 'summer', name: '여름' },
    { id: 'autumn', name: '가을' }, { id: 'winter', name: '겨울' }
];
/* 미니게임 — join:true 는 참가자를 먼저 모으는 게임, false 는 열리자마자 아무나 명령어로 참여 */
P.GAMES = [
    { id: 'tug',      name: '줄다리기',        icon: '🪢', join: false, min: 0, cmd: '!당겨',       how: '<b>!당겨</b> 연타! (ㄷ 도 돼요) 자동으로 팀이 나뉘어요',          desc: '빨강팀 대 파랑팀. 많이 당긴 팀이 이겨요' },
    { id: 'rps',      name: '피피와 가위바위보', icon: '✌️', join: false, min: 0, cmd: '!가위·!바위·!보', how: '<b>!가위 · !바위 · !보</b> 중 하나! 3판 동안 점수를 모아요', desc: '모두가 피피와 겨뤄요. 이기면 2점, 비기면 1점' },
    { id: 'updown',   name: '업다운 숫자',     icon: '🔢', join: false, min: 0, cmd: '숫자',        how: '<b>1~100 숫자</b>만 채팅! 피피가 업·다운을 알려 줘요',         desc: '피피가 생각한 숫자를 제일 먼저 맞히면 승리' },
    { id: 'typing',   name: '빨리 따라 치기',  icon: '⌨️', join: false, min: 0, cmd: '제시어',      how: '화면의 <b>제시어를 그대로</b> 제일 먼저 채팅!',                desc: '세 판. 제일 빨리 친 사람이 1점' },
    { id: 'ox',       name: 'OX 퀴즈',         icon: '⭕', join: false, min: 0, cmd: '!O · !X',     how: '<b>!O</b> 또는 <b>!X</b> (ㅇ·ㅌ 도 돼요)',                     desc: '다섯 문제. 많이 맞힌 사람이 승리' },
    { id: 'dice',     name: '주사위 대결',     icon: '🎲', join: true,  min: 2, cmd: '!굴려',       how: '뽑힌 사람은 <b>!굴려</b>! (ㄱ 도 돼요)',                      desc: '참가자가 직접 주사위를 굴려 높은 수가 이겨요' },
    { id: 'bomb',     name: '폭탄 돌리기',     icon: '💣', join: true,  min: 3, cmd: '!넘겨',       how: '폭탄을 든 사람은 <b>!넘겨</b>! (ㄴ 도 돼요) 마지막 생존자 승리', desc: '최대 8명. 터질 때 든 사람이 탈락' },
    { id: 'roulette', name: '운명의 룰렛',     icon: '🎡', join: true,  min: 1, cmd: '',            how: '참가만 하면 피피가 골라요',                                      desc: '참가자 중 한 명을 피피가 고릅니다' }
];

/* ─────────────────────────── 글꼴 ─────────────────────────── */
P.FONTS = [
    { id: 'Galmuri11',       name: '갈무리 (픽셀)',  url: 'https://cdn.jsdelivr.net/npm/galmuri@latest/dist/galmuri.css' },
    { id: 'Jua',             name: '주아',           g: 'Jua' },
    { id: 'Gaegu',           name: '개구 (손글씨)',  g: 'Gaegu:wght@400;700' },
    { id: 'Gowun Dodum',     name: '고운돋움',       g: 'Gowun+Dodum' },
    { id: 'Do Hyeon',        name: '도현',           g: 'Do+Hyeon' },
    { id: 'Nanum Pen Script',name: '나눔펜',         g: 'Nanum+Pen+Script' },
    { id: 'Hi Melody',       name: '하이멜로디',     g: 'Hi+Melody' },
    { id: 'Dongle',          name: '동글',           g: 'Dongle:wght@400;700' },
    { id: 'Gamja Flower',    name: '감자꽃',         g: 'Gamja+Flower' },
    { id: 'Poor Story',      name: '푸어스토리',     g: 'Poor+Story' },
    { id: 'Yeon Sung',       name: '연성',           g: 'Yeon+Sung' },
    { id: 'Sunflower',       name: '해바라기',       g: 'Sunflower:wght@500' },
    { id: 'Black Han Sans',  name: '검은고딕',       g: 'Black+Han+Sans' },
    { id: 'Noto Sans KR',    name: '본고딕',         g: 'Noto+Sans+KR:wght@400;700' },
    { id: 'Nanum Myeongjo',  name: '나눔명조',       g: 'Nanum+Myeongjo:wght@400;700' }
];
var loadedFonts = {};
P.loadFont = function (id) {
    if (!id || loadedFonts[id]) return;
    var f = P.FONTS.filter(function (x) { return x.id === id; })[0];
    if (!f) return;
    loadedFonts[id] = 1;
    var l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = f.url || ('https://fonts.googleapis.com/css2?family=' + f.g + '&display=swap');
    document.head.appendChild(l);
};
P.fontStack = function (id) {
    return "'" + (id || 'Jua') + "', 'Jua', 'Malgun Gothic', 'Apple SD Gothic Neo', sans-serif";
};

/* ─────────────────────────── 테마 ───────────────────────────
   card  : 카드 모양 (아래 CSS 의 .cs-<card>)
   vars  : 색 (bg fg bd tbg tfg bub bubfg acc sub)
   char  : 기본 캐릭터 그림 (body: blob|cat|bunny|bear|ghost|robot,
           acc: antenna|bow|leaf|star|heart|headphones|scarf|crown|none)
   title : 창 제목 · font : 추천 글꼴                                          */
P.BASE_THEMES = [
    { id: 'retro', name: '레트로 메신저', card: 'win', title: 'pipi.exe', font: 'Galmuri11',
      vars: { bg: '#c0c0c0', fg: '#111111', bd: '#808080', tbg: 'linear-gradient(90deg,#000080,#1084d0)', tfg: '#ffffff', bub: '#ffffff', bubfg: '#111111', acc: '#000080', sub: '#555555' },
      char: { body: 'blob', color: '#ffd34d', color2: '#c99a12', cheek: '#ff8fb1', acc: 'antenna', accColor: '#ff5a7a' } },
    { id: 'strawberry', name: '딸기 우유', card: 'soft', title: '피피의 딸기우유', font: 'Jua',
      vars: { bg: '#fff0f6', fg: '#6b3a4f', bd: '#ff9ec4', tbg: '#ffb8d4', tfg: '#ffffff', bub: '#ffffff', bubfg: '#6b3a4f', acc: '#ff6fa5', sub: '#b07790' },
      char: { body: 'bunny', color: '#ffc4d8', color2: '#e48aab', cheek: '#ff6f9c', acc: 'bow', accColor: '#ff4f86' } },
    { id: 'crt', name: '한밤의 CRT', card: 'crt', title: 'PIPI://TERMINAL', font: 'Galmuri11',
      vars: { bg: '#03140a', fg: '#4dff9a', bd: '#1aff7a', tbg: '#0a2e17', tfg: '#4dff9a', bub: '#04200f', bubfg: '#7dffb5', acc: '#1aff7a', sub: '#2fae66' },
      char: { body: 'robot', color: '#1d6b3f', color2: '#4dff9a', cheek: '#4dff9a', eye: '#b8ffd6', acc: 'antenna', accColor: '#4dff9a' } },
    { id: 'paper', name: '구겨진 쪽지', card: 'paper', title: '피피의 쪽지', font: 'Nanum Pen Script',
      vars: { bg: '#fbf6e9', fg: '#3b3024', bd: '#d8ccb0', tbg: 'transparent', tfg: '#8a7656', bub: 'transparent', bubfg: '#3b3024', acc: '#d9534f', sub: '#9b8a6c' },
      char: { body: 'ghost', color: '#ffffff', color2: '#3b3024', cheek: '#f4a9a0', acc: 'none' } },
    { id: 'bubble', name: '비눗방울', card: 'glass', title: '방울방울 피피', font: 'Gowun Dodum',
      vars: { bg: 'linear-gradient(135deg,rgba(214,232,255,.88),rgba(250,220,255,.88))', fg: '#4a4870', bd: 'rgba(255,255,255,.9)', tbg: 'rgba(255,255,255,.55)', tfg: '#6a5f9a', bub: 'rgba(255,255,255,.75)', bubfg: '#4a4870', acc: '#9b8cff', sub: '#8d88b5' },
      char: { body: 'blob', color: '#d9ccff', color2: '#9b8cff', cheek: '#ffaad4', acc: 'star', accColor: '#ffd75e' } },
    { id: 'pixel', name: '픽셀 포켓', card: 'pixel', title: 'PIPI.GB', font: 'Galmuri11',
      vars: { bg: '#9bbc0f', fg: '#0f380f', bd: '#0f380f', tbg: '#306230', tfg: '#9bbc0f', bub: '#8bac0f', bubfg: '#0f380f', acc: '#0f380f', sub: '#306230' },
      char: { body: 'cat', color: '#8bac0f', color2: '#0f380f', cheek: '#306230', eye: '#0f380f', acc: 'none' } },
    { id: 'starry', name: '별빛 일기장', card: 'star', title: '별빛 일기 · 피피', font: 'Gowun Dodum',
      vars: { bg: '#1b1f4a', fg: '#f3ecd2', bd: '#e8c66a', tbg: '#121538', tfg: '#e8c66a', bub: 'rgba(255,255,255,.08)', bubfg: '#f3ecd2', acc: '#e8c66a', sub: '#a9a5c9' },
      char: { body: 'ghost', color: '#cfe3ff', color2: '#7f9ad6', cheek: '#ffb3c8', acc: 'star', accColor: '#e8c66a' } },
    { id: 'candy', name: '사탕 가게', card: 'candy', title: '피피 캔디샵', font: 'Dongle',
      vars: { bg: '#f2fff9', fg: '#3e5b54', bd: '#ff8fb8', tbg: '#7fe0c4', tfg: '#ffffff', bub: '#ffffff', bubfg: '#3e5b54', acc: '#ff6fa5', sub: '#7aa69b' },
      char: { body: 'bear', color: '#a9f0d8', color2: '#4fbf9c', cheek: '#ff8fb8', acc: 'heart', accColor: '#ff4f86' } },
    { id: 'vhs', name: '낡은 비디오', card: 'vhs', title: '▶ PLAY  PIPI_1998.VHS', font: 'Do Hyeon',
      vars: { bg: '#0d0d0f', fg: '#f2f2f2', bd: '#3a3a3a', tbg: '#0d0d0f', tfg: '#f2f2f2', bub: 'transparent', bubfg: '#f2f2f2', acc: '#ff3b3b', sub: '#9a9a9a' },
      char: { body: 'blob', color: '#bdbdbd', color2: '#6b6b6b', cheek: '#e08a8a', acc: 'antenna', accColor: '#ff3b3b' } },
    { id: 'forest', name: '고요한 숲', card: 'leaf', title: '숲속의 피피', font: 'Gaegu',
      vars: { bg: '#eef3df', fg: '#3c4a2c', bd: '#8b5e3c', tbg: '#6b8f4e', tfg: '#f5f1dc', bub: '#fbfaf1', bubfg: '#3c4a2c', acc: '#6b8f4e', sub: '#7d8a6a' },
      char: { body: 'bunny', color: '#d8e6bf', color2: '#7f9b5c', cheek: '#f2a7a0', acc: 'leaf', accColor: '#6fb35a' } },
    { id: 'mono', name: '모노 미니멀', card: 'mono', title: 'pipi', font: 'Noto Sans KR',
      vars: { bg: '#ffffff', fg: '#111111', bd: '#111111', tbg: '#ffffff', tfg: '#111111', bub: '#ffffff', bubfg: '#111111', acc: '#111111', sub: '#777777' },
      char: { body: 'blob', color: '#ffffff', color2: '#111111', cheek: '#dddddd', acc: 'none' } },
    { id: 'neon', name: '사이버 네온', card: 'neon', title: 'PIPI//NEON', font: 'Do Hyeon',
      vars: { bg: 'rgba(12,6,28,.92)', fg: '#e9e3ff', bd: '#ff3df0', tbg: 'rgba(30,10,60,.95)', tfg: '#39f3ff', bub: 'rgba(57,243,255,.08)', bubfg: '#e9e3ff', acc: '#39f3ff', sub: '#a38fd6' },
      char: { body: 'robot', color: '#2a1550', color2: '#ff3df0', cheek: '#39f3ff', eye: '#39f3ff', acc: 'headphones', accColor: '#39f3ff' } },
    { id: 'pumpkin', name: '호박 등불', card: 'soft', title: '피피의 등불', font: 'Jua',
      vars: { bg: '#2b1838', fg: '#ffe7c2', bd: '#ff9a3c', tbg: '#ff9a3c', tfg: '#2b1838', bub: '#3c2350', bubfg: '#ffe7c2', acc: '#ff9a3c', sub: '#c9a2d6' },
      char: { body: 'ghost', color: '#fff4e2', color2: '#ff9a3c', cheek: '#ffb36b', acc: 'crown', accColor: '#ff9a3c' }, fx: { glow: true } },
    { id: 'sakura', name: '벚꽃 엽서', card: 'paper', title: '벚꽃 엽서 · 피피', font: 'Hi Melody',
      vars: { bg: '#fff7f9', fg: '#5b3f48', bd: '#f5c6d3', tbg: 'transparent', tfg: '#c27a90', bub: 'transparent', bubfg: '#5b3f48', acc: '#e58aa5', sub: '#b4929c' },
      char: { body: 'cat', color: '#ffe3ea', color2: '#d98aa1', cheek: '#ff9ab5', acc: 'scarf', accColor: '#e58aa5' }, fx: { petal: true } }
];

/* 효과 디자인 계열 — 테마마다 하나. 귀여운 연출과 화면 효과가 이 계열에 맞춰 그려집니다 */
P.FX_STYLES = ['win', 'soft', 'crt', 'paper', 'glass', 'pixel', 'star', 'candy', 'vhs', 'leaf', 'mono', 'neon'];

/* 모드팩 테마도 같은 모양으로 들어옵니다. 빠진 값은 기본 테마로 채웁니다. */
P.normTheme = function (t, prefix) {
    var base = P.BASE_THEMES[0];
    var cards = ['win', 'soft', 'crt', 'paper', 'glass', 'pixel', 'star', 'candy', 'vhs', 'leaf', 'mono', 'neon'];
    var out = {
        id: (prefix || '') + String(t.id || ('t' + Math.random().toString(36).slice(2, 7))),
        name: String(t.name || t.id || '이름 없는 테마'),
        card: cards.indexOf(t.card) >= 0 ? t.card : 'win',
        title: String(t.title || '피피'),
        titles: Array.isArray(t.titles) ? t.titles.slice(0, 5).map(String) : null,
        font: t.font || null,
        vars: {}, char: {}, css: typeof t.css === 'string' ? t.css : '',
        mod: t.mod || null,
        fxStyle: P.FX_STYLES.indexOf(t.fxStyle) >= 0 ? t.fxStyle : null,
        fx: t.fx && typeof t.fx === 'object' ? t.fx : {}
    };
    if (!out.fxStyle) out.fxStyle = out.card;
    Object.keys(base.vars).forEach(function (k) { out.vars[k] = (t.vars && t.vars[k]) || base.vars[k]; });
    var ch = t.char || {};
    out.char = { body: ch.body || 'blob', color: ch.color || '#ffd34d', color2: ch.color2 || null, cheek: ch.cheek || '#ff8fb1',
                 eye: ch.eye || null, acc: ch.acc || 'none', accColor: ch.accColor || null };
    return out;
};
P.themeTitle = function (th, stage) {
    if (th.titles && th.titles[stage]) return th.titles[stage];
    var t = th.title;
    return t;
};

/* ─────────────────────────── 색 도우미 ─────────────────────────── */
function hex2rgb(h) {
    h = String(h || '').replace('#', '');
    if (h.length === 3) h = h.split('').map(function (c) { return c + c; }).join('');
    var n = parseInt(h, 16);
    if (isNaN(n) || h.length !== 6) return null;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
P.shade = function (h, amt) {
    var c = hex2rgb(h); if (!c) return h;
    return '#' + c.map(function (v) {
        v = amt < 0 ? v * (1 + amt) : v + (255 - v) * amt;
        v = Math.max(0, Math.min(255, Math.round(v)));
        return ('0' + v.toString(16)).slice(-2);
    }).join('');
};

/* ─────────────────────────── 캐릭터 그림 (SVG) ───────────────────────────
   mood: base | uneasy | broken.  입은 닫힘/열림을 둘 다 그려 두고
   CSS(.talking) 가 번갈아 보여 줍니다.                                     */
P.charSVG = function (ch, mood, cos) {
    var C = cos ? (typeof cos === 'object' ? cos : P.costumeById && P.costumeById(cos)) : null;
    ch = ch || {};
    var c1 = ch.color || '#ffd34d', c2 = ch.color2 || P.shade(c1, -0.35), ck = ch.cheek || '#ff8fb1';
    var ey = ch.eye || '#2a2238', ac = ch.accColor || ck, body = ch.body || 'blob', acc = ch.acc || 'none';
    if (C && !C.keepAcc) acc = 'none';   /* 모자를 쓰면 테마 장식(리본·별·안테나)은 잠깐 벗는다 */
    var st = ' stroke="' + c2 + '" stroke-width="4" stroke-linejoin="round"';
    var s = '<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" class="pp-svg m-' + mood + '">';
    s += '<ellipse cx="100" cy="190" rx="56" ry="6" fill="rgba(0,0,0,.18)"/>';
    s += '<g class="pp-bob">';
    if (C && C.back) s += '<g class="pp-cos pp-cos-back">' + C.back + '</g>';
    /* 귀 (몸 뒤) */
    if (body === 'cat') {
        s += '<path d="M50 84 L42 24 L92 56Z" fill="' + c1 + '"' + st + '/><path d="M150 84 L158 24 L108 56Z" fill="' + c1 + '"' + st + '/>';
        s += '<path d="M54 70 L50 40 L78 58Z" fill="' + ck + '" opacity=".6"/><path d="M146 70 L150 40 L122 58Z" fill="' + ck + '" opacity=".6"/>';
    } else if (body === 'bunny') {
        s += '<ellipse cx="72" cy="40" rx="15" ry="38" transform="rotate(-12 72 40)" fill="' + c1 + '"' + st + '/><ellipse cx="128" cy="40" rx="15" ry="38" transform="rotate(12 128 40)" fill="' + c1 + '"' + st + '/>';
        s += '<ellipse cx="72" cy="42" rx="6" ry="24" transform="rotate(-12 72 42)" fill="' + ck + '" opacity=".55"/><ellipse cx="128" cy="42" rx="6" ry="24" transform="rotate(12 128 42)" fill="' + ck + '" opacity=".55"/>';
    } else if (body === 'bear') {
        s += '<circle cx="54" cy="58" r="22" fill="' + c1 + '"' + st + '/><circle cx="146" cy="58" r="22" fill="' + c1 + '"' + st + '/>';
        s += '<circle cx="54" cy="58" r="10" fill="' + ck + '" opacity=".55"/><circle cx="146" cy="58" r="10" fill="' + ck + '" opacity=".55"/>';
    }
    if (acc === 'headphones') s += '<path d="M34 112 C34 30 166 30 166 112" fill="none" stroke="' + ac + '" stroke-width="9" stroke-linecap="round"/>';
    /* 몸 */
    if (body === 'robot') {
        s += '<rect x="30" y="52" width="140" height="130" rx="30" fill="' + c1 + '"' + st + '/>';
        s += '<rect x="46" y="82" width="108" height="76" rx="18" fill="rgba(0,0,0,.28)"/>';
    } else if (body === 'ghost') {
        s += '<path d="M38 112C38 62 66 36 100 36C134 36 162 62 162 112L162 182Q152 170 142 182Q132 194 121 182Q110 170 100 182Q90 194 79 182Q68 170 58 182Q48 194 38 182Z" fill="' + c1 + '"' + st + '/>';
    } else {
        s += '<path d="M100 44C150 44 176 84 176 124C176 166 146 184 100 184C54 184 24 166 24 124C24 84 50 44 100 44Z" fill="' + c1 + '"' + st + '/>';
    }
    if (body !== 'robot') s += '<ellipse cx="76" cy="76" rx="18" ry="10" fill="rgba(255,255,255,.35)" transform="rotate(-20 76 76)"/>';
    /* 금 (붕괴) */
    if (mood === 'broken') {
        s += '<path d="M58 60 L70 84 L62 98 L78 120" fill="none" stroke="' + c2 + '" stroke-width="3"/>';
        s += '<path d="M150 140 L138 152 L146 166" fill="none" stroke="' + c2 + '" stroke-width="3"/>';
    }
    /* 볼 */
    if (mood !== 'broken') {
        var op = mood === 'uneasy' ? '.3' : '.6';
        s += '<ellipse cx="62" cy="134" rx="11" ry="7" fill="' + ck + '" opacity="' + op + '"/><ellipse cx="138" cy="134" rx="11" ry="7" fill="' + ck + '" opacity="' + op + '"/>';
    }
    /* 눈 */
    s += '<g class="pp-eyes">';
    if (mood === 'base') {
        s += '<ellipse cx="76" cy="114" rx="9" ry="13" fill="' + ey + '"/><ellipse cx="124" cy="114" rx="9" ry="13" fill="' + ey + '"/>';
        s += '<circle cx="79" cy="108" r="3.5" fill="#fff"/><circle cx="127" cy="108" r="3.5" fill="#fff"/>';
    } else if (mood === 'uneasy') {
        s += '<ellipse cx="76" cy="116" rx="7" ry="10" fill="' + ey + '"/><ellipse cx="124" cy="118" rx="7" ry="9" fill="' + ey + '"/>';
        s += '<circle cx="73" cy="113" r="2.4" fill="#fff"/><circle cx="121" cy="115" r="2.4" fill="#fff"/>';
        s += '<path d="M62 96 L88 102" stroke="' + c2 + '" stroke-width="4" stroke-linecap="round"/><path d="M138 96 L112 102" stroke="' + c2 + '" stroke-width="4" stroke-linecap="round"/>';
        s += '<path d="M156 78 Q150 92 156 96 Q162 92 156 78Z" fill="#8fd3ff" opacity=".9"/>';
    } else {
        s += '<ellipse cx="76" cy="114" rx="13" ry="16" fill="#08070c"/><ellipse cx="124" cy="114" rx="13" ry="16" fill="#08070c"/>';
        s += '<circle class="pp-pupil" cx="79" cy="117" r="2.2" fill="#ff3b3b"/><circle class="pp-pupil" cx="121" cy="111" r="2.2" fill="#ff3b3b"/>';
        s += '<path d="M64 102 L74 112 L68 122" fill="none" stroke="' + c2 + '" stroke-width="2.5"/>';
        s += '<path d="M126 130 Q123 144 127 156" fill="none" stroke="#120a14" stroke-width="4" stroke-linecap="round" opacity=".75"/>';
    }
    s += '</g>';
    /* 입 */
    if (mood === 'base') {
        s += '<path class="pp-mc" d="M88 138 Q100 149 112 138" fill="none" stroke="' + ey + '" stroke-width="4" stroke-linecap="round"/>';
        s += '<g class="pp-mo"><ellipse cx="100" cy="142" rx="10" ry="9" fill="#5a2236"/><ellipse cx="100" cy="147" rx="6" ry="3.5" fill="#ff8aa6"/></g>';
    } else if (mood === 'uneasy') {
        s += '<path class="pp-mc" d="M86 142 Q93 136 100 142 Q107 148 114 142" fill="none" stroke="' + ey + '" stroke-width="4" stroke-linecap="round"/>';
        s += '<g class="pp-mo"><ellipse cx="100" cy="143" rx="7" ry="6" fill="#3a1624"/></g>';
    } else {
        s += '<g class="pp-mc"><path d="M80 142 L120 142" stroke="#08070c" stroke-width="3"/>';
        [86, 94, 102, 110].forEach(function (x) { s += '<path d="M' + x + ' 136 L' + (x + 2) + ' 148" stroke="#08070c" stroke-width="2.5"/>'; });
        s += '</g><g class="pp-mo"><ellipse cx="100" cy="146" rx="10" ry="15" fill="#050505"/></g>';
    }
    /* 장식 */
    if (acc === 'antenna') s += '<path d="M100 46 L100 18" stroke="' + c2 + '" stroke-width="4"/><circle class="pp-ant" cx="100" cy="14" r="7" fill="' + ac + '"/>';
    else if (acc === 'bow') s += '<path d="M62 52 L40 38 L42 66Z M62 52 L84 38 L82 66Z" fill="' + ac + '"' + st.replace(c2, P.shade(ac, -.3)) + '/><circle cx="62" cy="52" r="6" fill="' + P.shade(ac, -.2) + '"/>';
    else if (acc === 'leaf') s += '<path d="M100 46 C92 24 110 12 126 16 C124 34 112 44 100 46Z" fill="' + ac + '"/><path d="M100 46 Q110 30 122 20" stroke="' + P.shade(ac, -.35) + '" stroke-width="2" fill="none"/>';
    else if (acc === 'star') s += '<path d="M150 30 L155 44 L170 44 L158 53 L162 67 L150 58 L138 67 L142 53 L130 44 L145 44Z" fill="' + ac + '" stroke="' + P.shade(ac, -.3) + '" stroke-width="2"/>';
    else if (acc === 'heart') s += '<path d="M150 70 C130 56 136 38 150 46 C164 38 170 56 150 70Z" fill="' + ac + '"/>';
    else if (acc === 'headphones') s += '<rect x="22" y="100" width="22" height="40" rx="9" fill="' + ac + '"/><rect x="156" y="100" width="22" height="40" rx="9" fill="' + ac + '"/>';
    else if (acc === 'scarf') s += '<path d="M42 160 Q100 180 158 160 L160 172 Q100 194 40 172Z" fill="' + ac + '"/><path d="M128 172 L136 196 L148 192 L142 170Z" fill="' + P.shade(ac, -.15) + '"/>';
    else if (acc === 'crown') s += '<path d="M74 50 L78 24 L90 40 L100 20 L110 40 L122 24 L126 50Z" fill="' + ac + '" stroke="' + P.shade(ac, -.3) + '" stroke-width="2"/>';
    if (body === 'robot' && acc !== 'antenna') s += '<rect x="94" y="36" width="12" height="16" rx="3" fill="' + c2 + '"/>';
    if (C && C.front) s += '<g class="pp-cos">' + C.front + '</g>';
    s += '</g></svg>';
    return s;
};
P.moodOf = function (stage) { return stage >= 3 ? 'broken' : stage >= 2 ? 'uneasy' : 'base'; };

/* ─────────────────────────── 카드 디자인 CSS ─────────────────────────── */
P.CSS = [
'.pp-card{position:relative;width:var(--cw,520px);color:var(--fg);font-family:var(--font);font-size:var(--fs,24px);line-height:1.45;transition:opacity .45s,transform .45s,filter 1.2s}',
'.pp-title{display:flex;align-items:center;gap:8px;padding:6px 10px;background:var(--tbg);color:var(--tfg);font-size:max(14px,.62em);letter-spacing:.02em;white-space:nowrap;overflow:hidden}',
'.pp-title .pp-tt{flex:1;overflow:hidden;text-overflow:ellipsis}',
'.pp-title .pp-mood{font-size:.9em;opacity:.9}',
'.pp-body{position:relative;display:flex;gap:12px;align-items:flex-end;padding:12px;background:var(--bg)}',
'.pp-char{position:relative;width:var(--chs,132px);height:var(--chs,132px);flex:none}',
'.pp-char .pp-svg,.pp-char img{width:100%;height:100%;display:block;object-fit:contain}',
'.pp-svg{overflow:visible}',
'.pp-char .pp-cos-img{position:absolute;inset:0;width:100%;height:100%;overflow:visible;pointer-events:none}',
'.pp-bubble{position:relative;flex:1;min-width:0;min-height:var(--bh,104px);background:var(--bub);color:var(--bubfg);padding:10px 14px 12px;word-break:keep-all;overflow-wrap:anywhere;transition:opacity .35s}',
'.pp-name{font-size:max(12px,.56em);color:var(--sub);margin-bottom:2px;letter-spacing:.04em}',
'.pp-text{min-height:1.45em;white-space:pre-wrap;word-break:keep-all;overflow-wrap:anywhere}',
'.pp-card.fixh .pp-bubble{height:var(--bh,180px);overflow:hidden}',
'.pp-card.fixh .pp-body{align-items:stretch}',
'.pp-text .cur{display:inline-block;width:.5em;height:1em;vertical-align:-.12em;background:currentColor;opacity:.7;animation:ppBlink .8s steps(1) infinite;margin-left:2px}',
'.pp-text b,.pp-text .big{font-size:1.35em;font-weight:900}',
'.pp-text .sm{font-size:.72em;opacity:.75;letter-spacing:.05em}',
'.pp-game-slot:empty{display:none}',
'.pp-game-slot{background:var(--bg);padding:0 12px 12px}',
/* 캐릭터 움직임 */
'.pp-bob{animation:ppBob 3.2s ease-in-out infinite;transform-origin:100px 190px}',
'.pp-eyes{animation:ppEye 5.5s infinite;transform-box:fill-box;transform-origin:center}',
'.pp-mo{opacity:0}',
'.talking .pp-mo{animation:ppTalkO .22s steps(1) infinite}',
'.talking .pp-mc{animation:ppTalkC .22s steps(1) infinite}',
'.talking .pp-char img{animation:ppHop .3s ease-in-out infinite}',
'.pp-ant{animation:ppAnt 2s ease-in-out infinite}',
'.m-broken .pp-pupil{animation:ppPupil 4s steps(1) infinite}',
'@keyframes ppBob{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}',
'@keyframes ppEye{0%,46%,50%,100%{transform:scaleY(1)}48%{transform:scaleY(.1)}}',
'@keyframes ppTalkO{0%{opacity:1}50%{opacity:0}}',
'@keyframes ppTalkC{0%{opacity:0}50%{opacity:1}}',
'@keyframes ppHop{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}',
'@keyframes ppAnt{0%,100%{opacity:1}50%{opacity:.45}}',
'@keyframes ppPupil{0%{transform:translate(0,0)}30%{transform:translate(4px,-3px)}60%{transform:translate(-3px,2px)}}',
'@keyframes ppBlink{50%{opacity:0}}',
/* 글리치 글씨 */
'.gl{position:relative;display:inline;color:inherit;text-shadow:2px 0 rgba(255,0,60,.75),-2px 0 rgba(0,220,255,.75);animation:ppGl 1.1s steps(2) infinite}',
'@keyframes ppGl{0%{text-shadow:2px 0 rgba(255,0,60,.75),-2px 0 rgba(0,220,255,.75)}25%{text-shadow:-3px 1px rgba(255,0,60,.8),3px -1px rgba(0,220,255,.8)}50%{text-shadow:1px -1px rgba(255,0,60,.6),-1px 1px rgba(0,220,255,.6)}75%{text-shadow:4px 0 rgba(255,0,60,.85),-4px 0 rgba(0,220,255,.85)}}',
'.zl{letter-spacing:.06em}',

/* ── win : 레트로 메신저 ── */
'.cs-win{background:var(--bg);box-shadow:inset -2px -2px #404040,inset 2px 2px #fff,inset -4px -4px #808080,inset 4px 4px #dfdfdf;padding:4px}',
'.cs-win .pp-title{font-weight:700}',
'.cs-win .pp-title:before{content:"💬";font-size:14px;flex:none}',
'.cs-win .pp-btns{display:flex;gap:3px}',
'.cs-win .pp-btns i{display:block;width:18px;height:16px;background:#c0c0c0;box-shadow:inset -1px -1px #404040,inset 1px 1px #fff;font-style:normal;color:#000;font-size:11px;line-height:16px;text-align:center}',
'.cs-win .pp-bubble{box-shadow:inset 2px 2px #808080,inset -2px -2px #fff,inset 3px 3px #404040}',
'.cs-win .pp-body{background:transparent}',
'.cs-win .pp-game-slot{background:transparent}',
/* ── soft : 둥근 파스텔 ── */
'.cs-soft{background:var(--bg);border:5px solid var(--bd);border-radius:30px;box-shadow:0 10px 0 rgba(0,0,0,.08),0 14px 30px rgba(0,0,0,.18);overflow:hidden;background-image:radial-gradient(var(--bd) 1.4px,transparent 1.6px);background-size:22px 22px}',
'.cs-soft .pp-title{justify-content:center;border-radius:0 0 18px 18px;margin:0 auto;width:fit-content;max-width:86%;padding:4px 22px 6px;font-weight:700}',
'.cs-soft .pp-body{background:transparent}',
'.cs-soft .pp-bubble{border-radius:22px;border:3px solid var(--bd);box-shadow:0 4px 0 var(--bd)}',
'.cs-soft .pp-bubble:before{content:"";position:absolute;left:-14px;bottom:22px;border:9px solid transparent;border-right:12px solid var(--bd)}',
'.cs-soft .pp-game-slot{background:transparent}',
'.cs-soft .pp-btns{display:none}',
/* ── crt : 초록 단말기 ── */
'.cs-crt{background:var(--bg);border:3px solid var(--bd);border-radius:14px;box-shadow:0 0 18px rgba(26,255,122,.45),inset 0 0 40px rgba(0,0,0,.8);overflow:hidden;text-shadow:0 0 6px currentColor}',
'.cs-crt:after{content:"";position:absolute;inset:0;pointer-events:none;background:repeating-linear-gradient(0deg,rgba(0,0,0,.28) 0 2px,transparent 2px 4px);animation:ppRoll 6s linear infinite}',
'@keyframes ppRoll{to{background-position:0 40px}}',
'.cs-crt .pp-title{border-bottom:2px solid var(--bd)}',
'.cs-crt .pp-title:before{content:"> ";}',
'.cs-crt .pp-bubble{border:1px dashed var(--bd)}',
'.cs-crt .pp-btns{display:none}',
/* ── paper : 쪽지 ── */
'.cs-paper{background:var(--bg);background-image:repeating-linear-gradient(0deg,transparent 0 33px,var(--bd) 33px 35px);padding:14px 10px 8px;transform:rotate(-1.2deg);box-shadow:3px 6px 14px rgba(0,0,0,.25)}',
'.cs-paper:before{content:"";position:absolute;top:-14px;left:50%;width:120px;height:30px;margin-left:-60px;background:rgba(255,236,170,.75);transform:rotate(2deg);box-shadow:0 1px 3px rgba(0,0,0,.15)}',
'.cs-paper .pp-title{font-size:max(16px,.7em);padding:4px 10px}',
'.cs-paper .pp-body,.cs-paper .pp-game-slot{background:transparent}',
'.cs-paper .pp-btns{display:none}',
/* ── glass : 비눗방울 ── */
'.cs-glass{background:var(--bg);border:3px solid var(--bd);border-radius:34px;box-shadow:0 8px 30px rgba(120,100,200,.3),inset 0 0 0 1px rgba(255,255,255,.6);overflow:hidden}',
'.cs-glass:before{content:"";position:absolute;top:44px;left:22px;width:90px;height:22px;z-index:2;pointer-events:none;border-radius:50%;background:rgba(255,255,255,.7);transform:rotate(-8deg)}',
'.cs-glass .pp-title{background:var(--tbg);justify-content:flex-end;font-weight:700}',
'.cs-glass .pp-body,.cs-glass .pp-game-slot{background:transparent}',
'.cs-glass .pp-bubble{border-radius:26px;border:2px solid rgba(255,255,255,.95)}',
'.cs-glass .pp-btns{display:none}',
/* ── pixel : 휴대 게임기 ── */
'.cs-pixel{background:var(--bg);border:6px solid var(--bd);box-shadow:6px 6px 0 rgba(15,56,15,.55);image-rendering:pixelated}',
'.cs-pixel .pp-title{border-bottom:4px solid var(--bd)}',
'.cs-pixel .pp-bubble{border:4px solid var(--bd);box-shadow:4px 4px 0 var(--bd)}',
'.cs-pixel .pp-btns{display:none}',
/* ── star : 별빛 일기장 ── */
'.cs-star{background:var(--bg);border:2px solid var(--bd);border-radius:18px;box-shadow:0 0 0 6px rgba(232,198,106,.18),0 12px 30px rgba(0,0,20,.45);overflow:hidden;background-image:radial-gradient(1.5px 1.5px at 20% 30%,#fff,transparent),radial-gradient(1px 1px at 70% 20%,#fff,transparent),radial-gradient(1.5px 1.5px at 85% 70%,#ffe9a8,transparent),radial-gradient(1px 1px at 40% 80%,#fff,transparent),radial-gradient(1px 1px at 55% 50%,#cfe3ff,transparent)}',
'.cs-star .pp-title{border-bottom:1px solid var(--bd);justify-content:center;letter-spacing:.2em}',
'.cs-star .pp-title:before,.cs-star .pp-title:after{content:"✦";color:var(--acc)}',
'.cs-star .pp-body,.cs-star .pp-game-slot{background:transparent}',
'.cs-star .pp-bubble{border-radius:14px;border:1px solid rgba(232,198,106,.5)}',
'.cs-star .pp-btns{display:none}',
/* ── candy : 사탕 줄무늬 ── */
'.cs-candy{background:var(--bg);border:9px solid transparent;border-radius:26px;background-image:linear-gradient(var(--bg),var(--bg)),repeating-linear-gradient(45deg,#ff8fb8 0 12px,#fff 12px 24px,#7fe0c4 24px 36px,#fff 36px 48px);background-origin:border-box;background-clip:padding-box,border-box;box-shadow:0 10px 24px rgba(0,0,0,.18);overflow:hidden}',
'.cs-candy .pp-title{border-radius:0 0 16px 16px;width:fit-content;margin:0 auto;padding:2px 22px 4px;font-size:max(18px,.8em)}',
'.cs-candy .pp-body,.cs-candy .pp-game-slot{background:transparent}',
'.cs-candy .pp-bubble{border-radius:20px;border:3px dashed var(--bd)}',
'.cs-candy .pp-btns{display:none}',
/* ── vhs : 낡은 비디오 ── */
'.cs-vhs{background:var(--bg);border:2px solid var(--bd);overflow:hidden;text-shadow:1.5px 0 rgba(255,0,80,.6),-1.5px 0 rgba(0,200,255,.6)}',
'.cs-vhs:after{content:"";position:absolute;inset:0;pointer-events:none;background:repeating-linear-gradient(0deg,rgba(255,255,255,.04) 0 1px,transparent 1px 3px)}',
'.cs-vhs .pp-title:after{content:"● REC";color:var(--acc);animation:ppBlink 1.2s steps(1) infinite;margin-left:auto}',
'.cs-vhs .pp-btns{display:none}',
/* ── leaf : 숲 나무 액자 ── */
'.cs-leaf{background:var(--bg);border:10px solid var(--bd);border-radius:18px;box-shadow:inset 0 0 0 3px #b98a5f,0 10px 24px rgba(40,30,10,.3)}',
'.cs-leaf:before{content:"🍃";position:absolute;right:-16px;top:-22px;font-size:34px;transform:rotate(20deg)}',
'.cs-leaf .pp-title{border-radius:8px 8px 0 0}',
'.cs-leaf .pp-bubble{border-radius:16px 16px 16px 4px;border:2px solid #cfd9b4}',
'.cs-leaf .pp-btns{display:none}',
/* ── mono : 미니멀 ── */
'.cs-mono{background:var(--bg);border:2px solid var(--bd)}',
'.cs-mono .pp-title{border-bottom:2px solid var(--bd);font-weight:700;letter-spacing:.15em;text-transform:lowercase}',
'.cs-mono .pp-bubble{border-left:4px solid var(--bd)}',
'.cs-mono .pp-btns{display:none}',
/* ── neon : 사이버 네온 ── */
'.cs-neon{background:var(--bg);border:2px solid var(--bd);border-radius:12px;box-shadow:0 0 14px var(--bd),inset 0 0 14px rgba(255,61,240,.3);overflow:hidden}',
'.cs-neon .pp-title{text-shadow:0 0 8px var(--tfg);border-bottom:1px solid var(--bd);letter-spacing:.18em}',
'.cs-neon .pp-bubble{border:1px solid var(--acc);border-radius:8px;box-shadow:0 0 10px rgba(57,243,255,.35);text-shadow:0 0 6px rgba(233,227,255,.5)}',
'.cs-neon .pp-btns{display:none}',

/* ── 단계별 변화 (카드) ── */
'.stg-2 .pp-card{filter:saturate(.8)}',
'.stg-3 .pp-card{filter:saturate(.45) contrast(1.12)}',
'.stg-4 .pp-card{filter:grayscale(.85) contrast(1.3);animation:ppJit 5s steps(1) infinite}',
'.stg-3 .pp-char,.stg-4 .pp-char{filter:drop-shadow(0 0 6px rgba(255,0,40,.45))}',
'.pp-crack{position:absolute;inset:0;pointer-events:none;opacity:0;transition:opacity 2s;z-index:3}',
'.stg-3 .pp-crack{opacity:.45}.stg-4 .pp-crack{opacity:.85}',
'.pp-vein{position:absolute;inset:0;pointer-events:none;opacity:0;transition:opacity 2s;background:radial-gradient(ellipse at center,transparent 55%,rgba(120,0,15,.45));z-index:2}',
'.stg-3 .pp-vein{opacity:.6}.stg-4 .pp-vein{opacity:1}',
'.pp-char > *{transform-origin:50% 92%}',
'.stg-2 .pp-char > *{animation:ppTwitch 7s steps(1) infinite}',
'.stg-3 .pp-char > *{animation:ppTilt 6s ease-in-out infinite}',
'.stg-4 .pp-char > *{animation:ppTwitch 2.6s steps(1) infinite}',
'@keyframes ppTwitch{0%,60%,64%,100%{transform:none}61%{transform:rotate(-9deg) translateX(-4px)}62%{transform:rotate(6deg)}63%{transform:rotate(-3deg) translateY(2px)}}',
'@keyframes ppTilt{0%,100%{transform:rotate(0)}35%,65%{transform:rotate(-16deg)}}',
'.pp-char.stare > *{animation:none !important;transform:scale(1.22) !important;transition:transform 1.8s ease-in}',
'.pp-char.stare .pp-bob,.pp-char.stare .pp-eyes{animation:none}',
'.pp-char.petted > *{animation:ppPet .5s ease-in-out 2 !important}',
'@keyframes ppPet{0%,100%{transform:scale(1)}30%{transform:scale(1.12,.9)}60%{transform:scale(.95,1.08)}}',
'.pp-char.munch .pp-mo{animation:ppTalkO .15s steps(1) infinite}.pp-char.munch .pp-mc{animation:ppTalkC .15s steps(1) infinite}',
'.pp-ptc{position:absolute;left:50%;top:30%;pointer-events:none;font-size:26px;animation:ppPtc 1.6s ease-out forwards;z-index:5}',
'@keyframes ppPtc{from{opacity:1;transform:translate(0,0) scale(.6)}to{opacity:0;transform:translate(var(--dx),-90px) scale(1.2)}}',
'@keyframes ppJit{0%,100%{transform:translate(0,0)}31%{transform:translate(1px,0)}32%{transform:translate(-2px,1px)}33%{transform:translate(0,0)}71%{transform:translate(0,-1px)}72%{transform:translate(2px,0)}73%{transform:translate(0,0)}}'
].join('\n');

P.injectCSS = function () {
    if (document.getElementById('pipi-core-css')) return;
    var st = document.createElement('style');
    st.id = 'pipi-core-css';
    st.textContent = P.CSS;
    document.head.appendChild(st);
};
P.CRACK_SVG = '<svg class="pp-crack" viewBox="0 0 520 260" preserveAspectRatio="none"><g fill="none" stroke="rgba(10,0,6,.85)" stroke-width="2"><path d="M520 20 L470 46 L482 70 L430 96 L446 122"/><path d="M470 46 L452 30"/><path d="M0 210 L40 196 L52 222 L96 214"/><path d="M40 196 L30 170"/><path d="M300 0 L292 24 L310 40"/></g></svg>';

/* 카드 하나를 그리는 HTML (오버레이·제어판 미리보기 공용) */
P.cardHTML = function () {
    return '<div class="pp-title"><span class="pp-tt"></span><span class="pp-mood"></span><span class="pp-btns"><i>_</i><i>□</i><i>×</i></span></div>' +
        '<div class="pp-body"><div class="pp-char"></div><div class="pp-bubble"><div class="pp-name">피피</div><div class="pp-text"></div></div></div>' +
        '<div class="pp-game-slot"></div>' + P.CRACK_SVG + '<div class="pp-vein"></div>';
};
P.applyThemeVars = function (el, th, font, fs) {
    Object.keys(th.vars).forEach(function (k) { el.style.setProperty('--' + k, th.vars[k]); });
    el.style.setProperty('--font', P.fontStack(font || th.font));
    if (fs) el.style.setProperty('--fs', fs + 'px');
};
P.moodMeter = function (stage) {
    return '♥♥♥♥♥';
};

/* ─────────────────────────── 글자 도우미 ─────────────────────────── */
P.glitchStr = function (s, p) {
    var pool = '▓▒░█■□◆◇#%&@$?!¿ㅇㅁㄴ口ꉂ';
    return String(s).split('').map(function (c) {
        return (c !== ' ' && Math.random() < p) ? pool[Math.floor(Math.random() * pool.length)] : c;
    }).join('');
};
P.zalgo = function (c, n) {
    var out = c;
    for (var i = 0; i < n; i++) out += String.fromCharCode(0x0300 + Math.floor(Math.random() * 0x6f));
    return out;
};
/* 받침: true / false / 'r'(ㄹ) / null(모름) */
P.jong = function (w) {
    w = String(w || '');
    for (var i = w.length - 1; i >= 0; i--) {
        var c = w.charCodeAt(i);
        if (c >= 0xAC00 && c <= 0xD7A3) { var j = (c - 0xAC00) % 28; return j === 0 ? false : (j === 8 ? 'r' : true); }
        if (c >= 48 && c <= 57) return ({ 0: true, 1: 'r', 3: true, 6: true, 7: 'r', 8: 'r' })[c - 48] || false;
        if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122)) return /[lmnLMN]/.test(w[i]) ? true : false;
    }
    return null;
};
P.josa = function (w, pair) {
    var map = { '이가': ['이', '가'], '은는': ['은', '는'], '을를': ['을', '를'], '과와': ['과', '와'], '아야': ['아', '야'],
                '이랑': ['이랑', '랑'], '이야': ['이야', '야'], '으로': ['으로', '로'], '이여': ['이여', '여'], '이나': ['이나', '나'] };
    var p = map[pair];
    if (!p) return pair;
    var j = P.jong(w);
    if (pair === '으로') return (j === true) ? p[0] : p[1];
    if (j === null) return pair === '아야' ? '' : p[1];
    return j ? p[0] : p[1];
};
/* 닉네임 안의 꺾쇠·대괄호가 대사 문법으로 읽히지 않게 */
P.safe = function (v) {
    return String(v).replace(/</g, '‹').replace(/>/g, '›').replace(/\[/g, '［').replace(/\]/g, '］').replace(/\{/g, '｛').replace(/\}/g, '｝');
};
/* 변수 채우기. 없는 변수가 하나라도 있으면 null (그 대사는 건너뜀) */
P.fill = function (tpl, getVar) {
    var ok = true;
    var out = String(tpl).replace(/\{([a-zA-Z0-9]+)(?::([^}]+))?\}/g, function (m, name, js) {
        var v = getVar(name);
        if (v === undefined || v === null || v === '') { ok = false; return ''; }
        v = P.safe(v);
        if (v === '너' && js === '아야') return '저기';   // 이름을 안 정했을 때 「너야,」 대신
        if (v === '너' && js === '이가') return '네가';
        return js ? v + P.josa(v, js) : v;
    });
    return ok ? out : null;
};
/* 대사 → 타이핑 순서 목록 */
P.parse = function (text) {
    var ops = [], style = null, re = /\[(fx|cute|pause|slow|fast)(?::([^\]]*))?\]|<(g|z|b|s)>|<\/(g|z|b|s)>/g, last = 0, m;
    function pushText(t) { for (var i = 0; i < t.length; i++) ops.push({ t: 'ch', c: t[i], st: style }); }
    while ((m = re.exec(text))) {
        pushText(text.slice(last, m.index));
        if (m[1]) ops.push({ t: 'cmd', n: m[1], a: m[2] || '' });
        else if (m[3]) style = m[3];
        else if (m[4]) style = null;
        last = re.lastIndex;
    }
    pushText(text.slice(last));
    return ops;
};
P.plain = function (text) {
    return String(text).replace(/\[(fx|cute|pause|slow|fast)(?::[^\]]*)?\]|<\/?(g|z|b|s)>/g, '');
};

/* ─────────────────────────── 대사집 합치기 (기본 + 모드팩) ─────────────────────────── */
function st5(a) {           /* [단계0..4] 배열로 정리 */
    var out = [[], [], [], [], []];
    if (!Array.isArray(a)) return out;
    for (var i = 0; i < 5; i++) if (Array.isArray(a[i])) out[i] = a[i].filter(function (x) { return typeof x === 'string' && x.trim(); });
    return out;
}
function addSt(dst, src) { src = st5(src); for (var i = 0; i < 5; i++) dst[i] = dst[i].concat(src[i]); }
function addMap(dst, src) {
    if (!src || typeof src !== 'object') return;
    Object.keys(src).forEach(function (k) { if (!dst[k]) dst[k] = st5([]); addSt(dst[k], src[k]); });
}
P.STAGE_KEYS = ['idle', 'stat', 'donation', 'boost', 'greet', 'pat', 'snack', 'mood', 'rank', 'rankNone', 'quiet', 'busy', 'back', 'hourly', 'midnight', 'words', 'ox', 'tickle', 'play', 'peekSay', 'ballSorry', 'costumeOn', 'costumeOff', 'costumeSelf', 'hugCmd', 'heartCmd', 'photoCmd', 'letterCmd', 'letterText', 'actSay', 'doodleCmd', 'doodleSelf', 'faceCmd', 'faceSelf', 'holidaySoon', 'holidayAsk', 'pipiBdayAsk', 'scoldSorry', 'scoldStart', 'scoldMurmur', 'scoldBusy', 'scoldEnd', 'scoldForgiven', 'celebAgain', 'viewMs', 'toyGive', 'foodGive', 'foodGiveVeg', 'tagHello', 'tagEnd', 'tagCall', 'tagNo', 'gossipStart', 'gossipEnd', 'gossipCall', 'friendCall', 'friendBallEnd', 'ensembleEnd', 'longRopeEnd', 'groupPhotoEnd', 'trainEnd', 'contestClaim', 'contestTease', 'contestRebut', 'contestMediate', 'contestWin', 'contestLose', 'contestEnd', 'mStart', 'mInvade', 'mInvadeReply', 'mWitness', 'mTease', 'mTeaseReply', 'mLaugh', 'mCollab', 'mCollabReply', 'mHype', 'mBrag', 'mLook', 'mLook2', 'mLook3', 'messEnd'];
P.LIST_KEYS = ['menuLunch', 'menuDinner', 'songs', 'luck'];
P.GAME_KEYS = ['open', 'join', 'start', 'win', 'tie', 'nobody', 'rps', 'rpsEye', 'tugYank', 'bombBoom', 'typeWord', 'typeHit', 'updownHit', 'updownMiss', 'oxQ', 'oxReveal'];
P.mergeLines = function (base, mods) {
    var L = { time: {}, weather: {}, season: {}, milestone: {}, holiday: {}, stalk: {}, celeb: {}, badge: {}, gossip: [], story: [[], [], [], [], []], reply: { generic: st5([]), keywords: [] }, game: {}, transition: st5([]) };
    P.STAGE_KEYS.forEach(function (k) { L[k] = st5([]); });
    P.LIST_KEYS.forEach(function (k) { L[k] = []; });
    P.GAME_KEYS.forEach(function (k) { L.game[k] = st5([]); });
    [base].concat(mods || []).forEach(function (src) {
        if (!src) return;
        P.STAGE_KEYS.forEach(function (k) { addSt(L[k], src[k]); });
        P.LIST_KEYS.forEach(function (k) { if (Array.isArray(src[k])) src[k].forEach(function (x) { if (typeof x === 'string' && x.trim() && L[k].indexOf(x) < 0) L[k].push(x); }); });
        ['time', 'weather', 'season', 'milestone', 'holiday', 'stalk', 'celeb', 'badge'].forEach(function (k) { addMap(L[k], src[k]); });
        /* 연속 이야기: [단계][이야기][줄] */
        if (Array.isArray(src.story)) for (var si = 0; si < 5; si++) (src.story[si] || []).forEach(function (seq) {
            if (Array.isArray(seq)) { var q = seq.filter(function (x) { return typeof x === 'string' && x.trim(); }); if (q.length) L.story[si].push(q); }
        });
        if (src.reply) {
            addSt(L.reply.generic, src.reply.generic);
            (src.reply.keywords || []).forEach(function (g) {
                if (!g || !Array.isArray(g.k)) return;
                var same = g.id && L.reply.keywords.filter(function (x) { return x.id === g.id; })[0];
                if (same) { same.k = same.k.concat(g.k.map(String)); addSt(same.lines, g.lines); if (g.pri !== undefined) same.pri = Number(g.pri) || 0; }
                else { var ng = { id: g.id || ('kw' + L.reply.keywords.length), pri: Number(g.pri) || 0, k: g.k.map(String), lines: st5([]) }; if (g.on) ng.on = String(g.on); if (g.hol) ng.hol = String(g.hol); addSt(ng.lines, g.lines); L.reply.keywords.push(ng); }
            });
        }
        if (src.game) P.GAME_KEYS.forEach(function (k) { addSt(L.game[k], src.game[k]); });
        /* 친구 수다: 대화 묶음 목록 */
        if (Array.isArray(src.gossip)) src.gossip.forEach(function (sc) { if (Array.isArray(sc)) { var q = sc.filter(function (x) { return typeof x === 'string' && x.indexOf('|') > 0; }); if (q.length) L.gossip.push(q); } });
        /* 단계 전환 대사는 모드팩이 있으면 그쪽으로 바꿔 끼움 (이어 붙이면 너무 길어짐) */
        if (src !== base && src.transition) { var t = st5(src.transition); for (var i = 1; i < 5; i++) if (t[i].length) L.transition[i] = t[i]; }
        else if (src === base) addSt(L.transition, src.transition);
    });
    return L;
};
P.countLines = function (L) {
    var n = 0;
    function c5(a) { a.forEach(function (x) { n += x.length; }); }
    P.STAGE_KEYS.forEach(function (k) { c5(L[k]); });
    ['time', 'weather', 'season', 'milestone', 'holiday', 'stalk', 'celeb', 'badge'].forEach(function (k) { Object.keys(L[k] || {}).forEach(function (q) { c5(L[k][q]); }); });
    L.story.forEach(function (st) { st.forEach(function (q) { n += q.length; }); });
    (L.gossip || []).forEach(function (q) { n += q.length; });
    c5(L.reply.generic); L.reply.keywords.forEach(function (g) { c5(g.lines); });
    Object.keys(L.game).forEach(function (k) { c5(L.game[k]); });
    ['quiet', 'busy', 'pat', 'hourly', 'midnight'].forEach(function (k) { c5(L[k]); });
    Object.keys(L.milestone).forEach(function (k) { c5(L.milestone[k]); });
    L.story.forEach(function (a) { a.forEach(function (st) { n += st.length; }); });
    return n;
};
/* 모드팩 검사 — 오류 문장 배열을 돌려줌 (비면 정상) */
P.checkMod = function (m) {
    var err = [];
    if (!m || typeof m !== 'object') return ['JSON 객체가 아닙니다'];
    if (m.format !== 'pipi-modpack') err.push('format 이 "pipi-modpack" 이 아닙니다');
    if (!m.id || !/^[a-z0-9_-]{2,32}$/.test(String(m.id))) err.push('id 는 영문 소문자·숫자·_- 2~32자여야 합니다');
    if (!m.name) err.push('name 이 없습니다');
    if (!m.themes && !m.lines && !m.costumes) err.push('themes · lines · costumes 중 하나는 있어야 합니다');
    if (m.themes && !Array.isArray(m.themes)) err.push('themes 는 배열이어야 합니다');
    return err;
};

/* ─────────────────────────── 효과음 (WebAudio 합성 — 파일 없음) ─────────────────────────── */
P.TYPE_VOICES = [
    { id: 'click', name: '딸깍 (기본)' }, { id: 'soft', name: '보들보들' }, { id: 'retro', name: '8비트' },
    { id: 'type', name: '타자기' }, { id: 'bubble', name: '뽀글뽀글' }, { id: 'voice', name: '옹알이' }, { id: 'off', name: '끄기' }
];
P.SFX_SETS = [{ id: 'cute', name: '말랑 (기본)' }, { id: 'chip', name: '칩튠' }, { id: 'calm', name: '잔잔' }];

function Sound() { this.ctx = null; this.vol = { master: .7, type: .55, sfx: .7, amb: .5 }; this.voice = 'click'; this.set = 'cute'; this.stage = 0; this._drone = null; this._nb = null; this._last = 0; }
Sound.prototype.c = function () {
    if (!this.ctx) {
        var AC = root.AudioContext || root.webkitAudioContext;
        if (!AC) return null;
        try { this.ctx = new AC(); } catch (e) { return null; }
        this.out = this.ctx.createGain();
        this.out.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') { try { this.ctx.resume(); } catch (e) {} }
    this.out.gain.value = this.vol.master;
    return this.ctx;
};
Sound.prototype.nb = function () {
    if (this._nb) return this._nb;
    var c = this.c(); if (!c) return null;
    var b = c.createBuffer(1, c.sampleRate * 2, c.sampleRate), d = b.getChannelData(0);
    for (var i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return (this._nb = b);
};
Sound.prototype.tone = function (f, dur, type, g, delay, f2, bus) {
    var c = this.c(); if (!c) return;
    var bv = this.vol[bus || 'sfx']; if (!bv) return;
    var t = c.currentTime + (delay || 0), o = c.createOscillator(), gn = c.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(Math.max(20, f), t);
    if (f2) o.frequency.exponentialRampToValueAtTime(Math.max(20, f2), t + dur);
    gn.gain.setValueAtTime(0.0001, t);
    gn.gain.exponentialRampToValueAtTime(Math.max(0.0002, g * bv), t + Math.min(.012, dur / 3));
    gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(gn); gn.connect(this.out);
    o.start(t); o.stop(t + dur + .02);
};
Sound.prototype.noise = function (dur, g, freq, delay, type, bus, q) {
    var c = this.c(), b = this.nb(); if (!c || !b) return;
    var bv = this.vol[bus || 'sfx']; if (!bv) return;
    var t = c.currentTime + (delay || 0), s = c.createBufferSource(), f = c.createBiquadFilter(), gn = c.createGain();
    s.buffer = b; f.type = type || 'bandpass'; f.frequency.value = freq || 2000; f.Q.value = q || 1;
    gn.gain.setValueAtTime(0.0001, t);
    gn.gain.exponentialRampToValueAtTime(Math.max(0.0002, g * bv), t + .01);
    gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(gn); gn.connect(this.out);
    s.start(t, Math.random()); s.stop(t + dur + .02);
};
/* 타이핑 한 글자 */
Sound.prototype.key = function (ch) {
    var v = this.voice; if (v === 'off' || !ch || /\s/.test(ch)) return;
    var now = Date.now(); if (now - this._last < 28) return; this._last = now;
    var st = this.stage, det = st >= 2 ? (Math.random() - .5) * st * 60 : 0, low = st >= 4 ? .62 : 1;
    var code = ch.charCodeAt(0);
    if (st >= 3 && Math.random() < .12 * (st - 2)) { this.tone(80 + Math.random() * 60, .07, 'sawtooth', .07, 0, 50, 'type'); return; }
    if (v === 'click') { this.tone((1700 + Math.random() * 250 + det) * low, .02, 'square', .045, 0, null, 'type'); this.noise(.015, .05, 4000, 0, 'highpass', 'type'); }
    else if (v === 'soft') this.tone((720 + Math.random() * 160 + det) * low, .05, 'sine', .14, 0, null, 'type');
    else if (v === 'retro') this.tone((300 + (code % 12) * 28 + det) * low, .04, 'square', .05, 0, null, 'type');
    else if (v === 'type') { this.noise(.028, .14, 3200, 0, 'highpass', 'type'); this.tone(140 * low, .03, 'triangle', .06, 0, null, 'type'); }
    else if (v === 'bubble') this.tone((420 + Math.random() * 120 + det) * low, .06, 'sine', .13, 0, 900 * low, 'type');
    else if (v === 'voice') this.tone((340 + (code % 9) * 22 + det) * low, .055, 'triangle', .12, 0, (300 + (code % 7) * 18) * low, 'type');
};
/* 효과음 */
Sound.prototype.sfx = function (name) {
    var S = this, set = this.set, w = set === 'chip' ? 'square' : set === 'calm' ? 'sine' : 'triangle', k = set === 'calm' ? .7 : 1;
    switch (name) {
        case 'pop': S.tone(500, .09, 'sine', .18 * k, 0, 1100); break;
        case 'chime': [784, 988, 1175, 1568].forEach(function (f, i) { S.tone(f, .35, w, .12 * k, i * .07); }); break;
        case 'sparkle': for (var i = 0; i < 6; i++) S.tone(1400 + Math.random() * 1400, .12, 'sine', .07 * k, i * .045); break;
        case 'join': S.tone(660, .08, w, .12 * k); S.tone(990, .12, w, .12 * k, .07); break;
        case 'open': [523, 659, 784, 1047].forEach(function (f, i) { S.tone(f, .2, w, .11 * k, i * .09); }); break;
        case 'tick': S.tone(1200, .03, 'square', .05 * k); break;
        case 'drum': for (var j = 0; j < 14; j++) S.noise(.06, .12 * k, 180, j * .06, 'lowpass'); break;
        case 'win': [523, 659, 784, 1047, 784, 1047].forEach(function (f, i) { S.tone(f, .22, w, .13 * k, i * .11); }); break;
        case 'lose': [392, 330, 262, 196].forEach(function (f, i) { S.tone(f, .3, w, .12 * k, i * .14); }); break;
        case 'dice': for (var d = 0; d < 9; d++) S.noise(.04, .16, 2400 + Math.random() * 1600, d * .05, 'bandpass', 'sfx', 3); break;
        case 'boom': S.noise(.9, .5, 400, 0, 'lowpass'); S.tone(120, .8, 'sine', .4, 0, 30); break;
        case 'rope': S.noise(.12, .12, 900, 0, 'bandpass', 'sfx', 2); break;
        case 'page': S.noise(.18, .1, 2500, 0, 'bandpass'); break;
        case 'static': S.noise(.9, .26, 3000, 0, 'bandpass', 'amb', .5); break;
        case 'glitch': for (var g = 0; g < 8; g++) S.tone(100 + Math.random() * 2400, .04, 'square', .07, g * .045); break;
        case 'recal': S.tone(1000, 1.6, 'sine', .14, 0, null, 'amb'); S.noise(.3, .2, 2500, 1.6, 'bandpass', 'amb'); break;
        case 'heart': S.tone(62, .16, 'sine', .55, 0, 40, 'amb'); S.tone(58, .18, 'sine', .45, .24, 38, 'amb'); break;
        case 'whisper': S.noise(1.6, .14, 1600, 0, 'bandpass', 'amb', 6); break;
        case 'thud': S.tone(70, .5, 'sine', .5, 0, 34, 'amb'); S.noise(.2, .2, 200, 0, 'lowpass', 'amb'); break;
        case 'ding': S.tone(980 + (S.stage >= 3 ? -300 * Math.random() : 0), .09, 'triangle', .1, 0); S.tone(740, .16, 'triangle', .09, .07, S.stage >= 4 ? 300 : null); break;
        case 'creak': S.tone(140, .9, 'sawtooth', .05, 0, 90, 'amb'); S.noise(.9, .08, 600, 0, 'bandpass', 'amb', 8); break;
        case 'crack': S.noise(.25, .45, 3000, 0, 'highpass', 'amb'); S.noise(.4, .25, 900, .05, 'bandpass', 'amb', 2); S.tone(90, .3, 'sine', .3, 0, 40, 'amb'); break;
        case 'blip': S.tone(1320, .05, 'square', .05, 0); break;
        case 'shriek': S.tone(1800, .5, 'sawtooth', .06, 0, 2600, 'amb'); S.tone(1900, .5, 'sawtooth', .05, 0, 2300, 'amb'); break;
    }
};
/* 붕괴 단계부터 낮게 깔리는 웅웅 소리 */
Sound.prototype.drone = function (on) {
    var c = this.c(); if (!c) return;
    if (on && !this._drone && this.vol.amb > 0) {
        var g = c.createGain(), f = c.createBiquadFilter(), a = c.createOscillator(), b = c.createOscillator();
        a.type = b.type = 'sawtooth'; a.frequency.value = 48; b.frequency.value = 48.7;
        f.type = 'lowpass'; f.frequency.value = 180;
        g.gain.value = 0.0001; g.gain.exponentialRampToValueAtTime(.05 * this.vol.amb, c.currentTime + 4);
        a.connect(f); b.connect(f); f.connect(g); g.connect(this.out); a.start(); b.start();
        this._drone = { g: g, a: a, b: b };
    } else if (!on && this._drone) {
        var d = this._drone; this._drone = null;
        try { d.g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + 1.5); d.a.stop(c.currentTime + 1.6); d.b.stop(c.currentTime + 1.6); } catch (e) {}
    }
};
P.Sound = Sound;

})(typeof window !== 'undefined' ? window : this);

/* ═══════════════════════════════════════════════════════════════════════
   1.4 — 귀여운 연출용 그림 · 악기 · 동요
   테마의 효과 계열(fxStyle)마다 같은 하트라도 다르게 그려집니다.
   win 굵은 검은 테두리 아이콘 · soft 말랑한 광택 · crt 초록 글자 · paper 연필 낙서 · glass 비눗방울 유리
   pixel 게임보이 도트 · star 금빛 반짝 · candy 줄무늬 사탕 · vhs 색 번짐 · leaf 잎맥 · mono 흑백 선 · neon 네온 선
   ═══════════════════════════════════════════════════════════════════════ */
(function (root) {
'use strict';
var P = root.PIPI;

var PATHS = {
    heart: 'M12 21.2s-7.6-4.6-9.7-9.3C.8 8.3 3 4.4 6.6 4.4c2.1 0 3.6 1.2 5.4 3.3 1.8-2.1 3.3-3.3 5.4-3.3 3.6 0 5.8 3.9 4.3 7.5-2.1 4.7-9.7 9.3-9.7 9.3z',
    star: 'M12 2.4l2.95 6.2 6.75.85-4.95 4.65 1.3 6.7L12 17.5l-6.05 3.3 1.3-6.7L2.3 9.45l6.75-.85z',
    sparkle: 'M12 1.5c.9 5.7 3.8 8.6 9.5 10.5-5.7 1.9-8.6 4.8-9.5 10.5-.9-5.7-3.8-8.6-9.5-10.5 5.7-1.9 8.6-4.8 9.5-10.5z',
    note: 'M9.5 17.6a3.2 3.2 0 1 1-2-3V4.2l12-2.6v13.6a3.2 3.2 0 1 1-2-3V6.3l-8 1.8z',
    drop: 'M12 2.2C9 7 5.6 10.6 5.6 14.6a6.4 6.4 0 0 0 12.8 0C18.4 10.6 15 7 12 2.2z',
    leaf: 'M4.5 19.5C4.5 9.5 11 3.5 20.5 3.5c0 9.5-6 16-16 16z',
    petal: 'M12 21c-3.6-1.8-6.2-5-6.2-8.6C5.8 8.3 8.4 5 10.6 3.4L12 6l1.4-2.6c2.2 1.6 4.8 4.9 4.8 9 0 3.6-2.6 6.8-6.2 8.6z',
    cloud: 'M7 18.5a4.5 4.5 0 0 1-.6-9 5.6 5.6 0 0 1 10.9 1.2A3.9 3.9 0 0 1 17 18.5z',
    butterfly: 'M12 8c-1.5-3.5-5.5-6-8-4.5S2.5 10 6 12c-3 1.5-3.5 5.5-1 6.5s5.5-1.5 7-5c1.5 3.5 4.5 6 7 5s2-5-1-6.5c3.5-2 4.5-7 2-8.5S13.5 4.5 12 8z',
    plane: 'M2.5 11.5L21.5 3l-5.5 18-4.5-7.5z',
    balloon: 'M12 2.5c4 0 7 3.2 7 7.4 0 4.5-3.4 8.1-7 8.1s-7-3.6-7-8.1c0-4.2 3-7.4 7-7.4zM11 18h2l-1 1.8z',
    bubble: 'M12 3a9 9 0 1 1 0 18 9 9 0 1 1 0-18z',
    snow: 'M12 2v20M3.3 7l17.4 10M3.3 17L20.7 7',
    flower: (function () {
        var d = '';
        for (var i = 0; i < 5; i++) {
            var a = -Math.PI / 2 + i * Math.PI * 2 / 5, x = 12 + Math.cos(a) * 5.4, y = 12 + Math.sin(a) * 5.4;
            d += 'M' + (x - 4).toFixed(2) + ' ' + y.toFixed(2) + 'a4 4 0 1 0 8 0a4 4 0 1 0-8 0z';
        }
        return d;
    })()
};
var LINE_KINDS = { snow: 1 };
var BITS = {
    heart: ['.XX.XX.', 'XXXXXXX', 'XXXXXXX', 'XXXXXXX', '.XXXXX.', '..XXX..', '...X...'],
    star: ['...X...', '..XXX..', 'XXXXXXX', '.XXXXX.', '..XXX..', '.XX.XX.', 'XX...XX'],
    sparkle: ['...X...', '...X...', '..XXX..', 'XXXXXXX', '..XXX..', '...X...', '...X...'],
    note: ['...XXXX', '...X..X', '...X..X', '...X..X', '.XXX.XX', 'XXXX.XX', '.XX....'],
    drop: ['...X...', '..XXX..', '.XXXXX.', '.XXXXX.', 'XXXXXXX', 'XXXXXXX', '.XXXXX.'],
    flower: ['.X...X.', 'XXX.XXX', '.XX.XX.', '...O...', '.XX.XX.', 'XXX.XXX', '.X...X.'],
    bubble: ['.XXXXX.', 'X.....X', 'X.O...X', 'X.....X', 'X.....X', 'X.....X', '.XXXXX.'],
    leaf: ['....XXX', '...XXXX', '..XXXXX', '.XXXXX.', 'XXXXX..', 'XXXX...', 'X......'],
    petal: ['..X.X..', '.XXXXX.', '.XXXXX.', 'XXXXXXX', '.XXXXX.', '..XXX..', '...X...'],
    cloud: ['.......', '..XXX..', '.XXXXX.', 'XXXXXXX', 'XXXXXXX', '.......', '.......'],
    snow: ['X..X..X', '.X.X.X.', '..XXX..', 'XXXXXXX', '..XXX..', '.X.X.X.', 'X..X..X'],
    balloon: ['.XXXXX.', 'XXXXXXX', 'XXXXXXX', 'XXXXXXX', '.XXXXX.', '..XXX..', '...X...'],
    butterfly: ['XX...XX', 'XXX.XXX', 'XXXXXXX', '..XXX..', 'XXXXXXX', 'XXX.XXX', 'XX...XX'],
    plane: ['X......', 'XXX....', 'XXXXX..', 'XXXXXXX', 'XXXXX..', 'XXX....', 'X......']
};
var GLYPHS = { heart: '<3', star: '*', sparkle: '+', note: '♪', drop: "'", leaf: '~', petal: '*', cloud: '()', snow: '*', bubble: 'o', balloon: 'O', butterfly: '}{', plane: '>', flower: '@' };
var uid = 0;

function isHex(c) { return /^#[0-9a-f]{6}$/i.test(String(c || '')); }
/* 테마에서 연출에 쓸 색 다섯 가지를 뽑는다 */
P.fxPal = function (th) {
    var v = th.vars || {}, ch = th.char || {};
    var c = [v.acc, ch.cheek, ch.accColor, ch.color, v.bd, v.tfg, ch.color2].filter(isHex);
    var uniq = [];
    c.forEach(function (x) { x = x.toLowerCase(); if (uniq.indexOf(x) < 0 && x !== '#ffffff' && x !== '#000000') uniq.push(x); });
    var st = th.fxStyle;
    if (st === 'mono') return ['#111111', '#555555', '#999999'];
    if (st === 'crt') return ['#4dff9a', '#1aff7a', '#b8ffd6'];
    if (st === 'pixel') return ['#0f380f', '#306230', '#8bac0f'];
    if (st === 'vhs') return ['#ff3b3b', '#39d0ff', '#f2f2f2', '#ffd23b'];
    if (st === 'star') uniq = ['#ffd75e', '#e8c66a', '#cfe3ff'].concat(uniq);
    if (st === 'neon') uniq = ['#ff3df0', '#39f3ff', '#b46bff'].concat(uniq);
    if (uniq.length < 3) uniq = uniq.concat(['#ff7eb6', '#ffd34d', '#7ec8ff']);
    return uniq.slice(0, 6);
};
function bitmap(kind, color, color2) {
    var b = BITS[kind] || BITS.heart, s = '<svg viewBox="0 0 7 7" shape-rendering="crispEdges">';
    for (var y = 0; y < 7; y++) for (var x = 0; x < 7; x++) {
        var ch = b[y][x];
        if (ch === 'X') s += '<rect x="' + x + '" y="' + y + '" width="1.02" height="1.02" fill="' + color + '"/>';
        else if (ch === 'O') s += '<rect x="' + x + '" y="' + y + '" width="1.02" height="1.02" fill="' + color2 + '"/>';
    }
    return s + '</svg>';
}
/* 하나의 작은 그림 (하트·별·음표…) — 계열에 맞춰 */
P.particle = function (kind, style, color, opt) {
    opt = opt || {};
    var d = PATHS[kind] || PATHS.heart, id = 'pp' + (uid++), dark = P.shade(color, -0.4), line = !!LINE_KINDS[kind];
    if (style === 'crt') return '<span class="cp-txt">' + (GLYPHS[kind] || '*') + '</span>';
    if (style === 'pixel') return bitmap(kind, color, '#9bbc0f');
    if (style === 'win' && Math.random() < .5) return bitmap(kind, color, '#ffffff').replace('<svg', '<svg class="win-bit"');
    var s = '<svg viewBox="0 0 24 24">', body;
    if (line) {
        var w = style === 'neon' ? 1.6 : style === 'paper' ? 1.4 : 2.2;
        var col = style === 'mono' ? '#111' : style === 'paper' ? '#3b3024' : color;
        return s + '<path d="' + d + '" fill="none" stroke="' + col + '" stroke-width="' + w + '" stroke-linecap="round"/></svg>';
    }
    switch (style) {
        case 'soft':
            body = '<path d="' + d + '" fill="' + color + '" stroke="' + dark + '" stroke-width="1.1" stroke-linejoin="round"/><ellipse cx="8.4" cy="8.6" rx="2.6" ry="1.7" fill="#fff" opacity=".65" transform="rotate(-30 8.4 8.6)"/>';
            break;
        case 'win':
            body = '<path d="' + d + '" fill="' + color + '" stroke="#000" stroke-width="1.6" stroke-linejoin="miter"/><path d="' + d + '" fill="none" stroke="#fff" stroke-width=".7" opacity=".7" transform="translate(-.7 -.7) scale(1.0)"/>';
            break;
        case 'paper':
            body = '<path d="' + d + '" fill="' + color + '" opacity=".38" transform="translate(1 1.2)"/><path d="' + d + '" fill="none" stroke="#3b3024" stroke-width="1.25" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="40 2 9 1.5"/>';
            break;
        case 'glass':
            s += '<defs><radialGradient id="' + id + '" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="#fff" stop-opacity=".95"/><stop offset=".45" stop-color="' + color + '" stop-opacity=".35"/><stop offset="1" stop-color="' + color + '" stop-opacity=".75"/></radialGradient></defs>';
            body = '<path d="' + d + '" fill="url(#' + id + ')" stroke="#fff" stroke-width="1" stroke-opacity=".95"/><path d="M7 6.5q2-2 4.5-1.6" stroke="#fff" stroke-width="1.2" fill="none" stroke-linecap="round"/>';
            break;
        case 'star':
            s += '<defs><linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff8d6"/><stop offset="1" stop-color="' + color + '"/></linearGradient></defs>';
            body = '<path d="' + d + '" fill="url(#' + id + ')" stroke="' + P.shade(color, -.25) + '" stroke-width=".7"/>';
            break;
        case 'candy':
            s += '<defs><pattern id="' + id + '" width="4" height="4" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="4" height="4" fill="' + color + '"/><rect width="1.5" height="4" fill="#fff" opacity=".55"/></pattern></defs>';
            body = '<path d="' + d + '" fill="url(#' + id + ')" stroke="#fff" stroke-width="2.4" paint-order="stroke" stroke-linejoin="round"/><path d="' + d + '" fill="none" stroke="' + dark + '" stroke-width=".6"/>';
            break;
        case 'vhs':
            body = '<g style="mix-blend-mode:screen"><path d="' + d + '" fill="#ff2050" transform="translate(-1.6 0)" opacity=".85"/><path d="' + d + '" fill="#20d0ff" transform="translate(1.6 0)" opacity=".85"/><path d="' + d + '" fill="' + color + '" opacity=".9"/></g>';
            break;
        case 'leaf':
            body = '<path d="' + d + '" fill="' + color + '" stroke="' + P.shade(color, -.5) + '" stroke-width="1.3" stroke-linejoin="round"/><path d="M8 17 L16 7" stroke="' + P.shade(color, -.5) + '" stroke-width=".8" opacity=".55"/>';
            break;
        case 'mono':
            body = '<path d="' + d + '" fill="#fff" stroke="#111" stroke-width="1.7" stroke-linejoin="round"/>';
            break;
        case 'neon':
            body = '<path d="' + d + '" fill="' + color + '" fill-opacity=".12" stroke="' + color + '" stroke-width="1.7" stroke-linejoin="round"/><path d="' + d + '" fill="none" stroke="#fff" stroke-width=".5" opacity=".9"/>';
            break;
        default:
            body = '<path d="' + d + '" fill="' + color + '"/>';
    }
    if (kind === 'flower') body += '<circle cx="12" cy="12" r="3" fill="' + (style === 'mono' ? '#111' : '#ffd84a') + '"/>';
    if (kind === 'balloon') body += '<path d="M12 19.8q-1.5 2 0 4.2" stroke="' + (style === 'mono' ? '#111' : '#777') + '" stroke-width=".7" fill="none"/>';
    return s + body + '</svg>';
};

/* 공 — 계열마다 다른 공 */
P.ballSVG = function (style, pal) {
    var c1 = pal[0], c2 = pal[1] || pal[0], c3 = pal[2] || '#fff', id = 'bl' + (uid++);
    var o = '<svg viewBox="0 0 40 40">';
    switch (style) {
        case 'win': return o + '<circle cx="20" cy="20" r="17" fill="#fff" stroke="#000" stroke-width="2"/><path d="M20 3a17 17 0 0 1 14.7 8.5L20 20z" fill="#e53935"/><path d="M34.7 28.5A17 17 0 0 1 20 37L20 20z" fill="#1e63d6"/><path d="M5.3 28.5A17 17 0 0 1 5.3 11.5L20 20z" fill="#ffd21f"/><circle cx="20" cy="20" r="17" fill="none" stroke="#000" stroke-width="2"/><circle cx="20" cy="20" r="3" fill="#fff" stroke="#000" stroke-width="1.5"/></svg>';
        case 'crt': return o + '<circle cx="20" cy="20" r="16" fill="rgba(0,40,15,.7)" stroke="#4dff9a" stroke-width="2.4"/><path d="M6 20h28M20 4v32M9 10q11 10 22 0M9 30q11-10 22 0" stroke="#4dff9a" stroke-width="1.2" fill="none" opacity=".8"/></svg>';
        case 'paper': return o + '<path d="M20 4l7 3 6 6 2 8-3 8-7 6-8 1-7-4-4-8 1-8 5-7z" fill="#f4efe1" stroke="#3b3024" stroke-width="1.4" stroke-linejoin="round"/><path d="M11 12l8 5 9-4M14 27l6-10 4 12M8 21l12-4 11 6" stroke="#8a7656" stroke-width=".9" fill="none"/></svg>';
        case 'glass': return o + '<defs><radialGradient id="' + id + '" cx=".35" cy=".3" r=".9"><stop offset="0" stop-color="#fff"/><stop offset=".5" stop-color="' + c1 + '" stop-opacity=".35"/><stop offset="1" stop-color="' + c2 + '" stop-opacity=".7"/></radialGradient></defs><circle cx="20" cy="20" r="17" fill="url(#' + id + ')" stroke="#fff" stroke-width="1.5"/><path d="M10 13q4-6 11-6" stroke="#fff" stroke-width="2.4" fill="none" stroke-linecap="round"/></svg>';
        case 'pixel': return bitmap('bubble', '#0f380f', '#8bac0f').replace('<svg', '<svg style="background:radial-gradient(circle,#8bac0f 55%,transparent 56%)"');
        case 'star': return o + '<circle cx="20" cy="20" r="12" fill="' + c1 + '" stroke="#fff3c4" stroke-width="1.2"/><ellipse cx="20" cy="20" rx="19" ry="6" fill="none" stroke="#fff3c4" stroke-width="1.8" transform="rotate(-18 20 20)"/><circle cx="15" cy="16" r="2.2" fill="#fff" opacity=".7"/></svg>';
        case 'candy': return o + '<circle cx="20" cy="20" r="16" fill="' + c1 + '" stroke="#fff" stroke-width="3"/><path d="M20 20m-10 0a10 10 0 0 1 20 0a7 7 0 0 1-14 0a4 4 0 0 1 8 0" stroke="#fff" stroke-width="2.4" fill="none"/><circle cx="13" cy="12" r="3" fill="#fff" opacity=".8"/></svg>';
        case 'vhs': return o + '<g style="mix-blend-mode:screen"><circle cx="18" cy="20" r="15" fill="#ff2050" opacity=".8"/><circle cx="22" cy="20" r="15" fill="#20d0ff" opacity=".8"/><circle cx="20" cy="20" r="15" fill="#eee" opacity=".55"/></g></svg>';
        case 'leaf': return o + '<path d="M20 12c8 0 12 6 12 13s-5 12-12 12-12-5-12-12 4-13 12-13z" fill="#b5803f" stroke="#5c3d1a" stroke-width="1.5"/><path d="M8 16q12-10 24 0q-12 4-24 0z" fill="#7a5226" stroke="#5c3d1a" stroke-width="1.5"/><path d="M20 8v-5" stroke="#5c3d1a" stroke-width="2" stroke-linecap="round"/><path d="M20 5q5-3 8 0" stroke="#6fb35a" stroke-width="2" fill="none"/></svg>';
        case 'mono': return o + '<circle cx="20" cy="20" r="16" fill="#fff" stroke="#111" stroke-width="2"/><path d="M9 9q6 11 0 22M31 9q-6 11 0 22" stroke="#111" stroke-width="1.4" fill="none" stroke-dasharray="2 2"/></svg>';
        case 'neon': return o + '<circle cx="20" cy="20" r="15" fill="rgba(57,243,255,.12)" stroke="' + c2 + '" stroke-width="2.4"/><circle cx="20" cy="20" r="9" fill="none" stroke="' + c1 + '" stroke-width="1.6"/></svg>';
        default: return o + '<circle cx="20" cy="20" r="16" fill="' + c1 + '" stroke="' + P.shade(c1, -.35) + '" stroke-width="1.6"/><path d="M5 17q15 8 30 0M7 27q13-8 26 0" stroke="' + c3 + '" stroke-width="2.6" fill="none" opacity=".85"/><ellipse cx="14" cy="12" rx="4" ry="2.6" fill="#fff" opacity=".6" transform="rotate(-30 14 12)"/></svg>';
    }
};

/* ── 악기 ── */
P.INSTRUMENTS = [
    { id: 'piano', name: '피아노', k: ['피아노'] },
    { id: 'xylo', name: '실로폰', k: ['실로폰', '철금'] },
    { id: 'uke', name: '우쿨렐레', k: ['우쿨렐레', '기타', '우쿨'] },
    { id: 'recorder', name: '리코더', k: ['리코더', '피리', '플루트'] },
    { id: 'musicbox', name: '오르골', k: ['오르골'] },
    { id: 'drum', name: '작은 북', k: ['북', '드럼', '탬버린', '작은 북'] }
];
P.instById = function (id) { return P.INSTRUMENTS.filter(function (x) { return x.id === id; })[0] || null; };
P.instFromText = function (t) {
    t = String(t || '');
    for (var i = 0; i < P.INSTRUMENTS.length; i++) if (P.INSTRUMENTS[i].k.some(function (w) { return t.indexOf(w) >= 0; })) return P.INSTRUMENTS[i].id;
    return null;
};
P.instSVG = function (id, pal) {
    var a = pal[0], b = pal[1] || pal[0], c = pal[2] || '#ffd34d', o = '<svg viewBox="0 0 80 60">';
    switch (id) {
        case 'piano':
            var k = '';
            for (var i = 0; i < 8; i++) k += '<rect class="ik ik' + i + '" x="' + (6 + i * 8.5) + '" y="22" width="8" height="30" rx="1.5" fill="#fff" stroke="#333" stroke-width="1"/>';
            [0, 1, 3, 4, 5].forEach(function (i) { k += '<rect x="' + (11.5 + i * 8.5) + '" y="22" width="5" height="18" rx="1" fill="#222"/>'; });
            return o + '<rect x="2" y="10" width="76" height="46" rx="6" fill="' + a + '" stroke="' + P.shade(a, -.4) + '" stroke-width="2"/>' + k + '</svg>';
        case 'xylo':
            var bars = '', cols = ['#ff6b6b', '#ffa94d', '#ffd43b', '#69db7c', '#4dabf7', '#9775fa', '#f783ac'];
            cols.forEach(function (col, i) { var h = 40 - i * 3.5; bars += '<rect class="ik ik' + i + '" x="' + (6 + i * 10) + '" y="' + (30 - h / 2) + '" width="8" height="' + h + '" rx="2" fill="' + col + '" stroke="#0003"/><circle cx="' + (10 + i * 10) + '" cy="' + (30 - h / 2 + 4) + '" r="1.2" fill="#fff8"/>'; });
            return o + '<path d="M3 16 L77 22 M3 46 L77 40" stroke="#8b5e3c" stroke-width="3"/>' + bars + '<path d="M60 4 l14 14" stroke="#8b5e3c" stroke-width="2.5"/><circle cx="58" cy="3" r="4" fill="' + a + '"/></svg>';
        case 'uke':
            return o + '<g transform="rotate(-20 40 30)"><rect x="40" y="26" width="36" height="7" rx="2" fill="#8b5e3c"/><rect x="72" y="24" width="7" height="11" rx="2" fill="#5c3d1a"/><ellipse cx="22" cy="24" rx="12" ry="10" fill="' + a + '"/><ellipse cx="30" cy="36" rx="16" ry="13" fill="' + a + '"/><ellipse cx="26" cy="30" rx="20" ry="17" fill="' + a + '" stroke="' + P.shade(a, -.45) + '" stroke-width="2"/><circle class="ik ik0" cx="30" cy="30" r="5" fill="#3a2414"/><path d="M14 28 L76 28 M14 31 L76 31" stroke="#fff" stroke-width=".7" opacity=".85"/></g></svg>';
        case 'recorder':
            var holes = '';
            for (var h = 0; h < 6; h++) holes += '<circle class="ik ik' + h + '" cx="' + (26 + h * 8) + '" cy="30" r="2" fill="#5c3d1a"/>';
            return o + '<g transform="rotate(-12 40 30)"><rect x="8" y="25" width="68" height="10" rx="5" fill="' + c + '" stroke="' + P.shade(c, -.45) + '" stroke-width="1.5"/><path d="M4 26 h10 v8 h-10 z" fill="' + b + '"/>' + holes + '</g></svg>';
        case 'musicbox':
            return o + '<rect x="8" y="22" width="56" height="32" rx="4" fill="' + a + '" stroke="' + P.shade(a, -.45) + '" stroke-width="2"/><path d="M8 22 L16 8 H72 L64 22 Z" fill="' + P.shade(a, .25) + '" stroke="' + P.shade(a, -.45) + '" stroke-width="2"/><circle class="ik ik0" cx="36" cy="38" r="6" fill="' + c + '"/><path class="crank" d="M64 38 h10 v-8" stroke="#666" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M20 30 l4 4 l4-4 l4 4" stroke="#fff" stroke-width="1.3" fill="none" opacity=".7"/></svg>';
        case 'drum':
            return o + '<ellipse cx="40" cy="22" rx="28" ry="8" fill="#f3efe6" stroke="#555" stroke-width="2"/><path d="M12 22 V44 Q40 56 68 44 V22" fill="' + a + '" stroke="#555" stroke-width="2"/><path d="M12 30 L26 46 L40 30 L54 46 L68 30" stroke="#fff" stroke-width="2" fill="none"/><g class="ik ik0"><path d="M20 4 L36 18" stroke="#8b5e3c" stroke-width="3" stroke-linecap="round"/><circle cx="37" cy="19" r="3" fill="' + c + '"/></g><g class="ik ik1"><path d="M62 4 L46 18" stroke="#8b5e3c" stroke-width="3" stroke-linecap="round"/><circle cx="45" cy="19" r="3" fill="' + c + '"/></g></svg>';
    }
    return '';
};

/* ── 동요 악보 (작자 미상 민요·옛 곡만) — 음이름옥타브:박자 ── */
P.SONGBOOK = {
    '반짝반짝 작은 별': { bpm: 132, n: 'C4 C4 G4 G4 A4 A4 G4:2 F4 F4 E4 E4 D4 D4 C4:2 G4 G4 F4 F4 E4 E4 D4:2 G4 G4 F4 F4 E4 E4 D4:2 C4 C4 G4 G4 A4 A4 G4:2 F4 F4 E4 E4 D4 D4 C4:2' },
    '나비야': { bpm: 140, n: 'G4 E4 E4:2 F4 D4 D4:2 C4 D4 E4 F4 G4 G4 G4:2 G4 E4 E4:2 F4 D4 D4:2 C4 E4 G4 G4 E4 E4 E4:2 D4 D4 D4 D4 D4 E4 F4:2 E4 E4 E4 E4 E4 F4 G4:2 G4 E4 E4:2 F4 D4 D4:2 C4 E4 G4 G4 C4:3' },
    '비행기': { bpm: 140, n: 'E4 D4 C4 D4 E4 E4 E4:2 D4 D4 D4:2 E4 G4 G4:2 E4 D4 C4 D4 E4 E4 E4 E4 D4 D4 E4 D4 C4:3' },
    '런던 다리': { bpm: 132, n: 'G4:1.5 A4:.5 G4 F4 E4 F4 G4:2 D4 E4 F4:2 E4 F4 G4:2 G4:1.5 A4:.5 G4 F4 E4 F4 G4:2 D4:2 G4 E4 C4:3' },
    '자장가': { bpm: 100, n: 'E4:.5 E4:.5 G4:2 E4:.5 E4:.5 G4:2 E4:.5 G4:.5 C5 B4:1.5 A4:.5 A4 G4:2 D4:.5 E4:.5 F4 D4 D4:.5 E4:.5 F4:2 D4:.5 F4:.5 B4 A4 G4 B4 C5:3' },
    '맥도날드 할아버지': { bpm: 150, n: 'G4 G4 G4 D4 E4 E4 D4:2 B4 B4 A4 A4 G4:3 D4 G4 G4 G4 D4 E4 E4 D4:2 B4 B4 A4 A4 G4:3' }
};
P.SONG_TITLES = Object.keys(P.SONGBOOK);
var NOTE_IDX = { C: 0, 'C#': 1, D: 2, 'D#': 3, E: 4, F: 5, 'F#': 6, G: 7, 'G#': 8, A: 9, 'A#': 10, B: 11 };
P.parseNotes = function (str) {
    return String(str).trim().split(/\s+/).map(function (tok) {
        var p = tok.split(':'), m = p[0].match(/^([A-G]#?)(\d)$/), beats = Number(p[1] || 1);
        if (!m) return { f: 0, b: beats };
        var midi = 12 * (Number(m[2]) + 1) + NOTE_IDX[m[1]];
        return { f: 440 * Math.pow(2, (midi - 69) / 12), b: beats, midi: midi };
    });
};
/* 악보가 없는 노래는 피피가 흥얼거린다 (5음 음계 즉흥) */
P.humNotes = function (len) {
    var scale = [60, 62, 64, 67, 69, 72, 74], out = [], cur = 2;
    for (var i = 0; i < (len || 14); i++) {
        cur = Math.max(0, Math.min(scale.length - 1, cur + Math.floor(Math.random() * 5) - 2));
        out.push({ f: 440 * Math.pow(2, (scale[cur] - 69) / 12), b: Math.random() < .25 ? 2 : 1, midi: scale[cur] });
    }
    out[out.length - 1].b = 2;
    return out;
};

/* ── 소리: 악기 한 음 · 노래 · 새 효과음 ── */
var S = P.Sound.prototype;
S.inst = function (id, f, t, dur, g) {
    var c = this.c(); if (!c || !f) return;
    var bv = this.vol.music === undefined ? .6 : this.vol.music; if (!bv) return;
    g = (g || 1) * bv;
    var out = this.out, self = this;
    function osc(type, freq, gain, attack, decay, t0, detune) {
        var o = c.createOscillator(), gn = c.createGain();
        o.type = type; o.frequency.setValueAtTime(freq, t0); if (detune) o.detune.value = detune;
        gn.gain.setValueAtTime(0.0001, t0);
        gn.gain.exponentialRampToValueAtTime(Math.max(.0002, gain), t0 + attack);
        gn.gain.exponentialRampToValueAtTime(0.0001, t0 + attack + decay);
        o.connect(gn); gn.connect(out); o.start(t0); o.stop(t0 + attack + decay + .05);
        return o;
    }
    switch (id) {
        case 'piano':
            osc('triangle', f, .22 * g, .006, Math.max(.5, dur * 2.2), t);
            osc('sine', f * 2, .06 * g, .006, .5, t);
            osc('sine', f * 3, .02 * g, .004, .25, t);
            break;
        case 'xylo':
            osc('sine', f * 2, .26 * g, .002, .45, t);
            osc('sine', f * 8, .05 * g, .001, .08, t);
            this.noise(.02, .06 * g, 6000, t - c.currentTime, 'highpass', 'music');
            break;
        case 'musicbox':
            osc('sine', f * 2, .2 * g, .002, 1.4, t);
            osc('sine', f * 4.2, .05 * g, .002, .5, t);
            osc('triangle', f * 2, .05 * g, .002, .9, t, 6);
            break;
        case 'recorder':
            var o = osc('sine', f * 2, .17 * g, .05, Math.max(.25, dur * .95), t);
            var lfo = c.createOscillator(), lg = c.createGain();
            lfo.frequency.value = 5.5; lg.gain.value = 6; lfo.connect(lg); lg.connect(o.detune); lfo.start(t); lfo.stop(t + dur + .3);
            osc('triangle', f * 2, .03 * g, .05, Math.max(.25, dur * .95), t);
            this.noise(Math.min(.25, dur), .03 * g, f * 2, t - c.currentTime, 'bandpass', 'music', 3);
            break;
        case 'uke':
            var buf = self._ks(f, 1.2), src = c.createBufferSource(), gn = c.createGain();
            src.buffer = buf; gn.gain.value = .55 * g; src.connect(gn); gn.connect(out); src.start(t);
            break;
        case 'drum':
            var fr = 90 + (f % 60);
            osc('sine', fr * 1.6, .5 * g, .002, .22, t);
            this.noise(.12, .22 * g, 1800, t - c.currentTime, 'bandpass', 'music', .8);
            if (Math.random() < .5) this.noise(.05, .1 * g, 7000, t - c.currentTime + .01, 'highpass', 'music');
            break;
    }
};
/* 우쿨렐레: 카플러스-스트롱 현 뜯기 */
S._ks = function (f, sec) {
    this._ksCache = this._ksCache || {};
    var key = Math.round(f);
    if (this._ksCache[key]) return this._ksCache[key];
    var c = this.c(), sr = c.sampleRate, N = Math.max(2, Math.round(sr / f)), len = Math.floor(sr * sec);
    var buf = c.createBuffer(1, len, sr), d = buf.getChannelData(0), ring = new Float32Array(N);
    for (var i = 0; i < N; i++) ring[i] = Math.random() * 2 - 1;
    var p = 0;
    for (var j = 0; j < len; j++) {
        var nx = (p + 1) % N, v = (ring[p] + ring[nx]) * 0.4965;
        d[j] = ring[p]; ring[p] = v; p = nx;
    }
    return (this._ksCache[key] = buf);
};
/* 노래 한 곡 — 단계가 오를수록 음이 어긋나고 느려진다 */
S.playSong = function (id, notes, opt) {
    opt = opt || {};
    var c = this.c(); if (!c) return 0;
    var st = this.stage || 0, bpm = (opt.bpm || 132) * (st >= 2 ? 1 - .1 * (st - 1) : 1), beat = 60 / bpm;
    var t = c.currentTime + .08, timeline = [], self = this;
    notes.forEach(function (n, i) {
        var f = n.f, dur = n.b * beat;
        if (f && st >= 3 && Math.random() < .18 * (st - 2)) f *= Math.pow(2, -1 / 12);
        if (f && st >= 4 && Math.random() < .2) f /= 2;
        if (f) {
            var det = st >= 2 ? (Math.random() - .5) * st * 0.016 : 0;
            self.inst(id, f * (1 + det), t, dur, 1);
        }
        timeline.push({ at: (t - c.currentTime) * 1000, i: i, f: f, dur: dur });
        t += dur;
    });
    if (opt.onNote) timeline.forEach(function (e) { setTimeout(function () { opt.onNote(e.i, e.f, e.dur); }, e.at); });
    return (t - c.currentTime) * 1000;
};
var baseSfx = S.sfx;
S.sfx = function (name) {
    var self = this, k = this.set === 'calm' ? .7 : 1;
    switch (name) {
        case 'pyong': self.tone(520 + Math.random() * 200, .12, 'sine', .16 * k, 0, 1300); return;
        case 'bloop': self.tone(300 + Math.random() * 300, .08, 'sine', .14 * k, 0, 900); return;
        case 'boing': self.tone(180, .25, 'triangle', .2 * k, 0, 420); self.tone(420, .2, 'sine', .08 * k, .05, 260); return;
        case 'whoosh': self.noise(.55, .2 * k, 1200, 0, 'bandpass', 'sfx', .7); return;
        case 'bonk': self.tone(160, .25, 'sine', .4 * k, 0, 70); self.tone(1400, .06, 'square', .05 * k, 0); self.noise(.08, .2 * k, 2000, 0); return;
        case 'giggle': for (var i = 0; i < 6; i++) self.tone(700 + i * 70 + Math.random() * 60, .07, 'sine', .11 * k, i * .085, 900 + i * 80); return;
        case 'flutter': for (var j = 0; j < 4; j++) self.noise(.04, .05 * k, 3000, j * .07, 'highpass'); return;
        case 'twinkle': [1568, 2093, 2637, 3136].forEach(function (f, q) { self.tone(f, .25, 'sine', .06 * k, q * .06); }); return;
        case 'pop2': self.tone(900, .06, 'sine', .12 * k, 0, 1500); return;
        case 'snore': self.noise(.6, .06 * k, 400, 0, 'lowpass', 'sfx'); return;
    }
    return baseSfx.call(this, name);
};
})(typeof window !== 'undefined' ? window : this);

/* ═══════════════════════════════════════════════════════════════════════
   1.6 — 코스튬 (!코스튬)
   피피 그림(200×200) 위에 겹쳐 그리는 옷. back = 몸 뒤(날개·꼬리), front = 몸 앞
   ═══════════════════════════════════════════════════════════════════════ */
(function (root) {
'use strict';
var P = root.PIPI;
function flowers(pts, cols) {
    return pts.map(function (p, i) {
        var c = cols[i % cols.length], s = '';
        for (var k = 0; k < 5; k++) { var a = k / 5 * Math.PI * 2; s += '<circle cx="' + (p[0] + Math.cos(a) * 5.5).toFixed(1) + '" cy="' + (p[1] + Math.sin(a) * 5.5).toFixed(1) + '" r="4.6" fill="' + c + '"/>'; }
        return s + '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="3.4" fill="#ffd43b"/>';
    }).join('');
}
P.BASE_COSTUMES = [
    { id: 'crown', name: '왕관', front: '<path d="M68 52 L72 22 L86 38 L100 16 L114 38 L128 22 L132 52 Z" fill="#ffd34d" stroke="#b8860b" stroke-width="3" stroke-linejoin="round"/><circle cx="100" cy="40" r="5" fill="#ff4f86"/><circle cx="80" cy="44" r="3.5" fill="#4dabf7"/><circle cx="120" cy="44" r="3.5" fill="#69db7c"/>',
      say: ['짜잔! 오늘은 피피 여왕님이야! 다들 편하게 있어, 백성들아! 헤헤.', '왕관 쓰니까 어깨가 쭉 펴져! 오늘 방송은 내가 다스린다!'] },
    { id: 'wizard', name: '마법사 모자', front: '<path d="M60 58 Q100 66 140 58 L108 -6 Q104 -12 98 -4 Z" fill="#6c4ab6" stroke="#3b2370" stroke-width="3" stroke-linejoin="round"/><ellipse cx="100" cy="58" rx="50" ry="9" fill="#5a3aa0" stroke="#3b2370" stroke-width="3"/><path d="M92 30 l3 6 6 1 -5 4 1 6 -5-3 -5 3 1-6 -5-4 6-1z" fill="#ffd34d"/><circle cx="112" cy="16" r="3" fill="#ffd34d"/>',
      say: ['수리수리 마수리! 피피 마법사 등장! 그림이 술술 그려지는 마법을 걸어 줄게!', '마법사 모자 장착! 다들 소원 하나씩 말해 봐!'] },
    { id: 'santa', name: '산타 모자', front: '<path d="M62 56 Q100 40 138 56 Q130 20 98 18 Q70 20 62 56Z" fill="#e03131"/><path d="M98 18 Q130 10 146 40" fill="none" stroke="#e03131" stroke-width="14" stroke-linecap="round"/><circle cx="148" cy="44" r="10" fill="#fff"/><rect x="58" y="50" width="84" height="14" rx="7" fill="#fff"/>',
      say: ['호호호! 피피 산타가 왔어요! 착한 시청자한테 하트 선물!', '산타 모자 쓰니까 벌써 연말 기분이야! 선물 받고 싶은 사람?'] },
    { id: 'witch', name: '마녀 모자', front: '<ellipse cx="100" cy="56" rx="58" ry="10" fill="#2b2140"/><path d="M70 54 L96 -2 Q100 -6 104 2 L126 54 Z" fill="#2b2140"/><rect x="72" y="42" width="56" height="9" fill="#ff9a3c"/><path d="M96 -2 Q120 0 128 10" fill="none" stroke="#2b2140" stroke-width="7" stroke-linecap="round"/>',
      say: ['히히히! 꼬마 마녀 피피야! 사탕 안 주면 장난칠 거야!', '마녀 모자! 빗자루는 없지만 안테나로 날 수 있어! ...아마도.'] },
    { id: 'pirate', name: '해적', front: '<path d="M54 64 Q100 30 146 64 Q100 52 54 64Z" fill="#e03131"/><circle cx="72" cy="58" r="3.5" fill="#fff"/><circle cx="100" cy="50" r="3.5" fill="#fff"/><circle cx="128" cy="58" r="3.5" fill="#fff"/><path d="M146 62 l16 -6 -4 14z" fill="#e03131"/><path d="M52 100 L150 92" stroke="#222" stroke-width="3"/><ellipse cx="124" cy="114" rx="15" ry="15" fill="#222"/>',
      say: ['요호호! 해적 피피 출항! 보물은 바로… 너희 채팅이야!', '안대 썼더니 한쪽만 보여! 그래도 다 보고 있어, 선원들!'] },
    { id: 'chef', name: '요리사', front: '<rect x="70" y="40" width="60" height="20" rx="4" fill="#fff" stroke="#ccc" stroke-width="2"/><path d="M68 44 Q56 20 76 14 Q82 -2 100 4 Q118 -2 124 14 Q144 20 132 44Z" fill="#fff" stroke="#ccc" stroke-width="2"/><path d="M78 162 Q100 172 122 162 L110 182 L100 175 L90 182Z" fill="#e03131"/>',
      say: ['셰프 피피 출근! 오늘의 메뉴는 정성 가득 픽셀 수프!', '요리사 모자 썼으니까 점메추는 나한테 맡겨!'] },
    { id: 'flowercrown', name: '꽃 화관', front: '<path d="M58 58 Q100 38 142 58" fill="none" stroke="#69a64a" stroke-width="5" stroke-linecap="round"/>' + flowers([[64, 56], [82, 48], [100, 45], [118, 48], [136, 56]], ['#ff8fb8', '#ffd6e7', '#b197fc', '#ffffff', '#ff8fb8']),
      say: ['꽃 화관 썼어! 봄 요정 피피야! 향기 나는 것 같지?', '화관 쓰니까 기분까지 꽃밭이야! 다들 꽃 한 송이씩 받아!'] },
    { id: 'catears', name: '고양이 귀', front: '<path d="M58 70 Q100 36 142 70" fill="none" stroke="#333" stroke-width="5"/><path d="M62 62 L60 26 L86 46Z" fill="#333"/><path d="M66 56 L65 34 L80 46Z" fill="#ff9ab5"/><path d="M138 62 L140 26 L114 46Z" fill="#333"/><path d="M134 56 L135 34 L120 46Z" fill="#ff9ab5"/>',
      say: ['냥! 오늘은 고양이 피피다냥! 츄르는 어디 있냥?', '고양이 귀 장착 완료냥! 쓰다듬어 주면 골골송 불러 줄게냥!'] },
    { id: 'bunnyears', name: '토끼 귀', front: '<path d="M58 70 Q100 36 142 70" fill="none" stroke="#ff8fb8" stroke-width="5"/><ellipse cx="80" cy="16" rx="11" ry="32" transform="rotate(-12 80 16)" fill="#fff" stroke="#ff8fb8" stroke-width="3"/><ellipse cx="80" cy="18" rx="5" ry="20" transform="rotate(-12 80 18)" fill="#ffc4d8"/><ellipse cx="120" cy="16" rx="11" ry="32" transform="rotate(14 120 16)" fill="#fff" stroke="#ff8fb8" stroke-width="3"/><ellipse cx="120" cy="18" rx="5" ry="20" transform="rotate(14 120 18)" fill="#ffc4d8"/>',
      say: ['깡충깡충! 토끼 피피야! 당근 있으면 줘!', '토끼 귀 쫑긋! 이제 채팅 소리가 더 잘 들려!'] },
    { id: 'bow', name: '큰 리본', front: '<path d="M100 46 L66 26 L68 66Z M100 46 L134 26 L132 66Z" fill="#ff4f86" stroke="#c2185b" stroke-width="3" stroke-linejoin="round"/><circle cx="100" cy="46" r="9" fill="#e64980" stroke="#c2185b" stroke-width="3"/>',
      say: ['커다란 리본! 오늘의 피피는 선물 상자 같지 않아?', '리본 달았더니 기분이 몽글몽글! 예쁘지?'] },
    { id: 'sunglasses', name: '선글라스', keepAcc: true, front: '<path d="M58 106 H142" stroke="#111" stroke-width="4"/><rect x="58" y="100" width="34" height="24" rx="9" fill="#111"/><rect x="108" y="100" width="34" height="24" rx="9" fill="#111"/><path d="M64 106 h10" stroke="#fff" stroke-width="3" opacity=".6"/><path d="M114 106 h10" stroke="#fff" stroke-width="3" opacity=".6"/>',
      say: ['후훗. 선글라스 피피. 오늘은 좀 멋있어 보이지?', '선글라스 쓰니까 화면이 어둡… 아니, 멋있어! 멋있으니까 괜찮아!'] },
    { id: 'glasses', name: '박사 안경', keepAcc: true, front: '<circle cx="76" cy="114" r="18" fill="rgba(255,255,255,.15)" stroke="#5c3d1a" stroke-width="4"/><circle cx="124" cy="114" r="18" fill="rgba(255,255,255,.15)" stroke="#5c3d1a" stroke-width="4"/><path d="M94 112 Q100 106 106 112" fill="none" stroke="#5c3d1a" stroke-width="4"/><path d="M84 164 L100 170 L116 164 L116 176 L100 170 L84 176Z" fill="#1c7ed6"/>',
      say: ['에헴! 피피 박사야. OX 퀴즈 열면 다 맞힐 수 있어!', '안경 쓰니까 똑똑해진 것 같아! 질문 받습니다!'] },
    { id: 'gradcap', name: '학사모', front: '<path d="M100 22 L152 40 L100 58 L48 40Z" fill="#222" stroke="#000" stroke-width="2"/><path d="M72 48 V64 Q100 74 128 64 V48" fill="#222"/><path d="M100 40 L146 52 V70" fill="none" stroke="#ffd34d" stroke-width="3"/><circle cx="146" cy="72" r="5" fill="#ffd34d"/>',
      say: ['피피 졸업! 전공은 수다학이야! 헤헤.', '학사모 던지기는 안 할래. 화면 쪽으로 날아갈까 봐!'] },
    { id: 'partyhat', name: '파티 모자', front: '<path d="M78 56 L100 4 L122 56Z" fill="#4dabf7" stroke="#1971c2" stroke-width="3" stroke-linejoin="round"/><path d="M84 46 L116 46 M89 34 L111 34 M94 22 L106 22" stroke="#ffd34d" stroke-width="5"/><circle cx="100" cy="4" r="7" fill="#ff4f86"/>',
      say: ['파티 타임! 오늘은 그냥 방송한 날 기념 파티야!', '빵빠레~ 파티 모자 썼으니까 다들 축하해 줘!'] },
    { id: 'astronaut', name: '우주인 헬멧', front: '<circle cx="100" cy="112" r="82" fill="rgba(180,220,255,.2)" stroke="#dfe7ef" stroke-width="7"/><path d="M48 82 Q58 52 90 42" stroke="#fff" stroke-width="7" fill="none" stroke-linecap="round" opacity=".7"/><rect x="58" y="178" width="84" height="14" rx="6" fill="#dfe7ef" stroke="#9aa5b1" stroke-width="2"/><circle cx="100" cy="185" r="3" fill="#ff6b6b"/>',
      say: ['우주인 피피, 발사 준비 완료! 3, 2, 1… 슝!', '헬멧 안은 조용해. 너희 채팅만 들려!'] },
    { id: 'tiara', name: '티아라', front: '<path d="M72 54 Q100 40 128 54 L122 40 L112 46 L100 26 L88 46 L78 40Z" fill="#e8eef6" stroke="#9aa5b1" stroke-width="2.5" stroke-linejoin="round"/><circle cx="100" cy="35" r="5" fill="#ff8fb8"/><circle cx="84" cy="47" r="2.5" fill="#74c0fc"/><circle cx="116" cy="47" r="2.5" fill="#74c0fc"/>',
      say: ['피피 공주 등장! 오늘은 우아하게 수다 떨게! 호호.', '티아라 반짝반짝! 다들 공주님께 인사해!'] },
    { id: 'detective', name: '탐정', front: '<path d="M60 58 Q100 18 140 58Z" fill="#a0784f" stroke="#5c3d1a" stroke-width="3"/><path d="M70 50 H130 M66 42 H134 M80 32 H120 M84 24 V56 M100 18 V56 M116 24 V56" stroke="#5c3d1a" stroke-width="1.5" opacity=".5"/><path d="M58 58 Q100 66 142 58" fill="none" stroke="#5c3d1a" stroke-width="5"/><circle cx="160" cy="150" r="16" fill="rgba(200,230,255,.4)" stroke="#5c3d1a" stroke-width="5"/><path d="M148 162 L134 178" stroke="#5c3d1a" stroke-width="7" stroke-linecap="round"/>',
      say: ['명탐정 피피 등장! 오늘 제일 채팅 많이 한 범인을 찾아낼 거야!', '돋보기로 보니… 다들 오늘 기분이 좋구나! 추리 끝!'] },
    { id: 'beanie', name: '털모자와 목도리', front: '<path d="M60 64 Q60 22 100 22 Q140 22 140 64Z" fill="#e8590c"/><rect x="58" y="56" width="84" height="14" rx="6" fill="#d9480f"/><path d="M66 58 V68 M76 58 V68 M86 58 V68 M96 58 V68 M106 58 V68 M116 58 V68 M126 58 V68 M134 58 V68" stroke="#ffa94d" stroke-width="2"/><circle cx="100" cy="18" r="11" fill="#fff"/><path d="M44 160 Q100 182 156 160 L158 174 Q100 196 42 174Z" fill="#1c7ed6"/><path d="M128 172 L136 198 L150 194 L142 168Z" fill="#1971c2"/>',
      say: ['따뜻하게 털모자랑 목도리! 이제 하나도 안 추워!', '포근포근 겨울 피피! 다들 감기 조심해!'] },
    { id: 'strawhat', name: '밀짚모자', front: '<ellipse cx="100" cy="56" rx="66" ry="13" fill="#f2c94c" stroke="#b7882a" stroke-width="3"/><path d="M68 54 Q70 22 100 22 Q130 22 132 54Z" fill="#f2c94c" stroke="#b7882a" stroke-width="3"/><rect x="69" y="44" width="62" height="8" fill="#e03131"/><circle cx="124" cy="46" r="6" fill="#ff8fb8"/>',
      say: ['밀짚모자 쓰고 여름 소풍 가는 기분! 수박 먹고 싶다!', '햇빛 가리개 완료! 피피는 오늘 시골 소녀야!'] },
    { id: 'tophat', name: '신사 모자', front: '<rect x="76" y="2" width="48" height="48" rx="3" fill="#222"/><ellipse cx="100" cy="52" rx="40" ry="7" fill="#222"/><rect x="76" y="38" width="48" height="8" fill="#c92a2a"/><path d="M100 166 L82 156 V178Z M100 166 L118 156 V178Z" fill="#c92a2a"/><circle cx="100" cy="166" r="5" fill="#a61e1e"/>',
      say: ['에헴, 신사 피피라고 합니다. 오늘 방송에 와 주셔서 감사합니다.', '나비넥타이까지 완벽! 오늘은 점잖게… 헤헤, 못 하겠다!'] },
    { id: 'frog', name: '개구리 모자', front: '<path d="M42 110 Q40 40 100 38 Q160 40 158 110 Q150 70 100 68 Q50 70 42 110Z" fill="#69db7c" stroke="#2b8a3e" stroke-width="3"/><circle cx="74" cy="40" r="15" fill="#69db7c" stroke="#2b8a3e" stroke-width="3"/><circle cx="126" cy="40" r="15" fill="#69db7c" stroke="#2b8a3e" stroke-width="3"/><circle cx="74" cy="40" r="7" fill="#fff"/><circle cx="126" cy="40" r="7" fill="#fff"/><circle cx="75" cy="41" r="4" fill="#111"/><circle cx="127" cy="41" r="4" fill="#111"/>',
      say: ['개굴개굴! 개구리 피피야! 비 오면 신나게 뛰어다닐 거야!', '개구리 모자 귀엽지? 개굴! 개굴!'] },
    { id: 'strawberry', name: '딸기 모자', front: '<path d="M62 60 Q60 20 100 18 Q140 20 138 60 Q100 70 62 60Z" fill="#ff4d6d" stroke="#c9184a" stroke-width="3"/><g fill="#ffe066"><ellipse cx="80" cy="36" rx="2" ry="3"/><ellipse cx="100" cy="30" rx="2" ry="3"/><ellipse cx="120" cy="36" rx="2" ry="3"/><ellipse cx="88" cy="50" rx="2" ry="3"/><ellipse cx="112" cy="50" rx="2" ry="3"/><ellipse cx="72" cy="52" rx="2" ry="3"/><ellipse cx="128" cy="52" rx="2" ry="3"/></g><path d="M100 20 L84 8 L94 22 L80 22 L96 28 Z M100 20 L116 8 L106 22 L120 22 L104 28 Z" fill="#40c057"/><path d="M100 20 V6" stroke="#2b8a3e" stroke-width="3"/>',
      say: ['딸기 모자! 오늘은 딸기 피피야! 달콤한 냄새 나지?', '새콤달콤 딸기 피피 등장! 딸기 우유 마시고 싶다!'] },
    { id: 'dj', name: 'DJ 헤드폰', front: '<path d="M34 112 C34 30 166 30 166 112" fill="none" stroke="#222" stroke-width="10" stroke-linecap="round"/><rect x="20" y="96" width="26" height="46" rx="11" fill="#ff3df0"/><rect x="154" y="96" width="26" height="46" rx="11" fill="#39f3ff"/>',
      say: ['DJ 피피 입장! 오늘의 플레이리스트는… 전부 동요야! 헤헤.', '헤드폰 쓰니까 리듬이 몸에서 막 나와! 둠칫둠칫!'] },
    { id: 'angel', name: '천사', back: '<path d="M42 122 Q-2 104 6 66 Q24 88 46 96Z M158 122 Q202 104 194 66 Q176 88 154 96Z" fill="#fff" stroke="#c9d1e0" stroke-width="3" stroke-linejoin="round"/>', front: '<ellipse cx="100" cy="22" rx="32" ry="8" fill="none" stroke="#ffd34d" stroke-width="6"/>',
      say: ['천사 피피 강림! 오늘 착한 일 한 사람한테 축복을 줄게!', '날개 달았어! 아직 날 줄은 모르지만 연습 중이야!'] },
    { id: 'devil', name: '꼬마 악마', back: '<path d="M150 170 Q188 168 178 138" fill="none" stroke="#e03131" stroke-width="6" stroke-linecap="round"/><path d="M178 138 l-10 5 12 -17 5 18z" fill="#e03131"/>', front: '<path d="M66 54 Q58 30 70 18 Q72 38 82 48Z M134 54 Q142 30 130 18 Q128 38 118 48Z" fill="#e03131" stroke="#a61e1e" stroke-width="2.5" stroke-linejoin="round"/>',
      say: ['꼬마 악마 피피! 장난칠 거야! ...근데 무슨 장난 치지?', '뿔 달았다! 무섭지? 안 무섭다고? 히잉.'] },
    { id: 'sheet', name: '유령 이불', front: '<path d="M30 192 Q26 60 100 40 Q174 60 170 192 Q156 178 142 192 Q128 178 114 192 Q100 178 86 192 Q72 178 58 192 Q44 178 30 192Z" fill="#fff" opacity=".94" stroke="#ced4da" stroke-width="3"/><ellipse cx="80" cy="112" rx="9" ry="12" fill="#222"/><ellipse cx="120" cy="112" rx="9" ry="12" fill="#222"/><ellipse cx="100" cy="142" rx="7" ry="5" fill="#222"/>',
      say: ['우우~ 이불 유령이다! 놀랐지? 나야, 피피! 헤헤.', '이불 뒤집어썼더니 따뜻하고 포근해! 유령 놀이 중!'] },
    { id: 'nightcap', name: '수면 모자', front: '<path d="M64 60 Q70 20 112 18 Q150 24 160 70 Q140 44 124 50 Q110 58 64 60Z" fill="#748ffc"/><circle cx="162" cy="74" r="10" fill="#fff"/><rect x="60" y="54" width="80" height="12" rx="6" fill="#dbe4ff"/><circle cx="90" cy="38" r="3" fill="#ffd34d"/><circle cx="118" cy="30" r="2.5" fill="#ffd34d"/>',
      say: ['수면 모자 쓰니까 졸려… 하아암~ 아직 방송 중이지?', '잠옷 피피! 꿀잠 자는 기분으로 수다 떨게!'] }
];
P.COSTUMES = P.BASE_COSTUMES.slice();
P.costumeById = function (id) { return P.COSTUMES.filter(function (c) { return c.id === id; })[0] || null; };
/* 모드팩 옷 — 그림 속 스크립트·이벤트 속성은 지운다 */
function clean(svg) {
    return String(svg || '').replace(/<\s*(script|foreignObject|iframe|image|use)[\s\S]*?(<\/\s*\1\s*>|\/>)/gi, '').replace(/\son\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '').replace(/javascript:/gi, '');
}
P.resetCostumes = function () { P.COSTUMES = P.BASE_COSTUMES.slice(); };
P.addCostumes = function (list, prefix, modName) {
    (Array.isArray(list) ? list : []).forEach(function (c) {
        if (!c || !c.id || !(c.front || c.back)) return;
        var id = (prefix || '') + String(c.id);
        P.COSTUMES = P.COSTUMES.filter(function (x) { return x.id !== id; });
        P.COSTUMES.push({ id: id, name: String(c.name || c.id), keepAcc: !!c.keepAcc, front: clean(c.front), back: clean(c.back), say: Array.isArray(c.say) ? c.say.filter(function (x) { return typeof x === 'string'; }) : [], mod: modName || null });
    });
};
/* 직접 그린 PNG 위에 옷만 따로 겹칠 때 */
P.costumeLayer = function (cos, layer) {
    var C = typeof cos === 'object' ? cos : P.costumeById(cos);
    if (!C || !C[layer]) return '';
    return '<svg class="pp-cos-img" viewBox="0 0 200 200"><g class="pp-cos">' + C[layer] + '</g></svg>';
};
})(typeof window !== 'undefined' ? window : this);

/* ═══════════════════════════════════════════════════════════════════════
   1.7 — 옷 40벌 더 · 직접 그린 옷(PNG)
   ═══════════════════════════════════════════════════════════════════════ */
(function (root) {
'use strict';
var P = root.PIPI;
var HEART = 'M12 21s-7.6-4.6-9.7-9.3C.8 8.3 3 4.4 6.6 4.4c2.1 0 3.6 1.2 5.4 3.3 1.8-2.1 3.3-3.3 5.4-3.3 3.6 0 5.8 3.9 4.3 7.5-2.1 4.7-9.7 9.3-9.7 9.3z';
var STAR = 'M12 2.4l2.95 6.2 6.75.85-4.95 4.65 1.3 6.7L12 17.5l-6.05 3.3 1.3-6.7L2.3 9.45l6.75-.85z';
function petals() {
    var s = '';
    for (var i = 0; i < 16; i++) { var a = i * 22.5; s += '<ellipse cx="100" cy="30" rx="11" ry="24" transform="rotate(' + a + ' 100 112)" fill="#ffd43b" stroke="#e8a400" stroke-width="2.5"/>'; }
    return s;
}
var BAND = '<path d="M58 70 Q100 38 142 70" fill="none" stroke="COL" stroke-width="5" stroke-linecap="round"/>';
var MORE = [
    { id: 'bear', name: '곰돌이 모자', front: '<circle cx="62" cy="44" r="16" fill="#a9744f" stroke="#6b4226" stroke-width="3"/><circle cx="62" cy="44" r="7" fill="#e7b48f"/><circle cx="138" cy="44" r="16" fill="#a9744f" stroke="#6b4226" stroke-width="3"/><circle cx="138" cy="44" r="7" fill="#e7b48f"/><path d="M38 112 Q34 40 100 38 Q166 40 162 112 Q154 72 100 70 Q46 72 38 112Z" fill="#a9744f" stroke="#6b4226" stroke-width="3"/>',
      say: ['곰돌이 피피! 꿀 좋아해! 꿀 있으면 줘!', '포근포근 곰돌이 모자! 안아 주고 싶지? !안아줘!'] },
    { id: 'penguin', name: '펭귄 모자', front: '<path d="M36 116 Q32 36 100 34 Q168 36 164 116 Q156 74 100 72 Q44 74 36 116Z" fill="#2b2d42"/><path d="M90 64 L100 78 L110 64Z" fill="#ffb703"/><circle cx="86" cy="52" r="4.5" fill="#fff"/><circle cx="114" cy="52" r="4.5" fill="#fff"/><circle cx="86" cy="52" r="2.2" fill="#111"/><circle cx="114" cy="52" r="2.2" fill="#111"/>',
      say: ['뒤뚱뒤뚱 펭귄 피피! 추운 거 하나도 안 무서워!', '펭귄 모자 썼으니까 오늘은 빙판 위를 미끄러질 거야! 슝~'] },
    { id: 'eggshell', name: '달걀 껍데기', front: '<path d="M60 62 L62 30 Q100 2 138 30 L140 62 L128 52 L116 64 L104 52 L92 64 L80 52 L70 64Z" fill="#fffdf5" stroke="#d8cfb8" stroke-width="3" stroke-linejoin="round"/>',
      say: ['삐약! 방금 알에서 나왔어! 처음 본 너희가 엄마야! ...아니, 엄마는 우소우소지!', '달걀 껍데기 모자! 아직 덜 깨어났어. 삐약삐약.'] },
    { id: 'mushroom', name: '버섯 모자', front: '<path d="M44 64 Q44 10 100 8 Q156 10 156 64 Q100 54 44 64Z" fill="#e5383b" stroke="#a4161a" stroke-width="3"/><circle cx="78" cy="34" r="8" fill="#fff"/><circle cx="112" cy="24" r="6" fill="#fff"/><circle cx="132" cy="44" r="7" fill="#fff"/><circle cx="62" cy="52" r="5" fill="#fff"/><circle cx="100" cy="48" r="5" fill="#fff"/>',
      say: ['버섯 피피! 비 오는 날 쑥쑥 자랄 거야!', '빨간 버섯 모자! 먹으면 안 돼, 내 모자니까!'] },
    { id: 'sunflower', name: '해바라기', back: petals(), front: '',
      say: ['해바라기 피피! 해 대신 {streamer}만 바라볼 거야!', '꽃잎 활짝! 오늘 방송 햇살 가득!'] },
    { id: 'rainbowband', name: '무지개 머리띠', front: '<path d="M52 68 Q100 4 148 68" fill="none" stroke="#ff6b6b" stroke-width="6"/><path d="M58 68 Q100 14 142 68" fill="none" stroke="#ffa94d" stroke-width="6"/><path d="M64 68 Q100 24 136 68" fill="none" stroke="#ffe066" stroke-width="6"/><path d="M70 68 Q100 34 130 68" fill="none" stroke="#69db7c" stroke-width="6"/><circle cx="50" cy="68" r="9" fill="#fff"/><circle cx="58" cy="72" r="7" fill="#fff"/><circle cx="150" cy="68" r="9" fill="#fff"/><circle cx="142" cy="72" r="7" fill="#fff"/>',
      say: ['무지개 머리띠! 오늘 행운이 올 것 같아!', '머리 위에 무지개 떴다! 소원 빌어!'] },
    { id: 'cloud', name: '구름 모자', front: '<g fill="#c5d3e8"><circle cx="76" cy="44" r="21"/><circle cx="100" cy="32" r="25"/><circle cx="126" cy="44" r="21"/><rect x="58" y="44" width="86" height="21" rx="10"/></g><g fill="#fff"><circle cx="76" cy="44" r="18"/><circle cx="100" cy="32" r="22"/><circle cx="126" cy="44" r="18"/><rect x="61" y="46" width="80" height="16" rx="8"/></g>',
      say: ['구름 모자! 몽글몽글 폭신폭신!', '머리 위에 구름이 있어! 오늘은 피피 날씨 맑음!'] },
    { id: 'moonstar', name: '달과 별 핀', front: '<path d="M134 30 a18 18 0 1 0 12 30 a14 14 0 1 1 -12 -30z" fill="#ffd43b" stroke="#e8a400" stroke-width="2"/><path transform="translate(146 10) scale(.7)" d="' + STAR + '" fill="#ffe066"/><path transform="translate(56 30) scale(.55)" d="' + STAR + '" fill="#ffe066"/>',
      say: ['달이랑 별 핀 꽂았어! 밤하늘 피피야!', '반짝반짝 별 핀! 밤 방송에 딱이지?'] },
    { id: 'cherry', name: '체리 핀', front: '<path d="M114 40 Q118 22 140 10 M138 40 Q140 24 140 10" fill="none" stroke="#2b8a3e" stroke-width="3"/><path d="M140 10 q8 -6 14 2 q-8 6 -14 -2z" fill="#40c057"/><circle cx="114" cy="50" r="11" fill="#e03131"/><circle cx="138" cy="50" r="11" fill="#e03131"/><circle cx="110" cy="46" r="3" fill="#fff" opacity=".7"/><circle cx="134" cy="46" r="3" fill="#fff" opacity=".7"/>',
      say: ['체리 핀! 새콤달콤 피피야!', '체리 두 알 콩! 오늘은 사랑스러움 두 배!'] },
    { id: 'police', name: '경찰 모자', front: '<path d="M60 52 Q100 18 140 52 L138 60 L62 60Z" fill="#1d3557"/><rect x="62" y="52" width="76" height="7" fill="#ffd43b"/><path d="M58 59 H142 Q144 70 100 72 Q56 70 58 59Z" fill="#111"/><path d="M100 28 l8 6 -3 10 h-10 l-3 -10z" fill="#ffd43b"/>',
      say: ['삐뽀삐뽀! 피피 경찰이야! 채팅 안 한 사람 잡으러 왔어!', '경찰 피피 출동! 오늘 방송 평화는 내가 지킨다!'] },
    { id: 'firefighter', name: '소방관 헬멧', front: '<path d="M44 62 Q100 54 156 62 L152 70 Q100 64 48 70Z" fill="#c92a2a"/><path d="M58 62 Q58 18 100 16 Q142 18 142 62Z" fill="#e03131" stroke="#a61e1e" stroke-width="3"/><path d="M100 16 V60" stroke="#a61e1e" stroke-width="4"/><path d="M88 30 h24 v16 h-24z" fill="#ffd43b"/>',
      say: ['소방관 피피! 불타는 열정은 내가 지켜 줄게!', '안전 제일! 다들 물 많이 마셔! 소방관 피피의 부탁이야!'] },
    { id: 'hardhat', name: '안전모', front: '<path d="M60 60 Q60 22 100 20 Q140 22 140 60Z" fill="#ffd43b" stroke="#e8a400" stroke-width="3"/><path d="M100 20 V58 M82 26 V58 M118 26 V58" stroke="#e8a400" stroke-width="3" opacity=".6"/><rect x="50" y="56" width="100" height="10" rx="5" fill="#fcc419" stroke="#e8a400" stroke-width="3"/>',
      say: ['공사 중! 피피가 오늘 방송을 튼튼하게 짓고 있어!', '안전모 착용 완료! 그림 작업 현장 점검 나왔습니다!'] },
    { id: 'cap', name: '야구 모자', front: '<path d="M60 60 Q60 22 100 20 Q140 22 140 60Z" fill="#4dabf7" stroke="#1971c2" stroke-width="3"/><path d="M136 56 Q170 52 176 66 Q150 70 132 64Z" fill="#1971c2"/><circle cx="100" cy="21" r="4" fill="#1971c2"/><path transform="translate(88 30) scale(.9)" d="' + STAR + '" fill="#fff"/>',
      say: ['모자 옆으로 쓰니까 힙하지? 요! 피피 스웨그!', '야구 모자 썼으니 공놀이도 프로처럼! 홈런!'] },
    { id: 'bucket', name: '벙거지 모자', front: '<path d="M66 52 Q70 22 100 22 Q130 22 134 52Z" fill="#94d82d" stroke="#5c940d" stroke-width="3"/><path d="M50 62 Q100 44 150 62 L144 52 Q100 42 56 52Z" fill="#82c91e" stroke="#5c940d" stroke-width="3"/><circle cx="122" cy="40" r="5" fill="#fff"/><circle cx="122" cy="40" r="2" fill="#ffd43b"/>',
      say: ['벙거지 모자 쓰고 캠핑 가자! 마시멜로 구워 먹자!', '소풍 피피! 오늘은 어디로 놀러 갈까?'] },
    { id: 'beret', name: '화가 베레모', front: '<path d="M54 52 Q50 22 98 20 Q150 20 148 48 Q130 60 100 56 Q70 60 54 52Z" fill="#c92a2a" stroke="#8f1d1d" stroke-width="3"/><path d="M98 20 l2 -8" stroke="#8f1d1d" stroke-width="4" stroke-linecap="round"/><g transform="rotate(28 160 80)"><rect x="156" y="40" width="7" height="50" rx="3" fill="#a0784f"/><path d="M156 40 Q159 24 163 40Z" fill="#4dabf7"/></g>',
      say: ['화가 피피 등장! {streamer}의 제자가 되겠습니다!', '베레모 쓰니까 그림 실력이 쑥 오른 기분! 슥슥!'] },
    { id: 'cowboy', name: '카우보이 모자', front: '<path d="M66 60 Q62 24 82 22 Q100 32 118 22 Q138 24 134 60Z" fill="#a0692f" stroke="#5c3d1a" stroke-width="3"/><rect x="66" y="50" width="68" height="7" fill="#5c3d1a"/><path d="M30 58 Q100 76 170 58 Q160 72 100 74 Q40 72 30 58Z" fill="#8d5524" stroke="#5c3d1a" stroke-width="3"/>',
      say: ['이랴! 카우보이 피피가 왔다! 채팅 말 타고 달려!', '하울! 오늘 방송 서부 개척 시작이야!'] },
    { id: 'viking', name: '바이킹 투구', front: '<path d="M60 46 Q36 40 34 14 Q46 30 62 34Z M140 46 Q164 40 166 14 Q154 30 138 34Z" fill="#fff8e1" stroke="#c9b28a" stroke-width="2.5"/><path d="M58 64 Q58 20 100 18 Q142 20 142 64Z" fill="#adb5bd" stroke="#495057" stroke-width="3"/><path d="M100 18 V64" stroke="#495057" stroke-width="5"/><rect x="56" y="58" width="88" height="10" rx="4" fill="#868e96" stroke="#495057" stroke-width="2"/>',
      say: ['바이킹 피피! 미니게임 줄다리기는 내가 이긴다!', '뿔 투구 썼다! 용감한 피피 원정대 출발!'] },
    { id: 'knight', name: '기사 투구', front: '<path d="M100 30 Q110 10 128 8 Q120 22 112 34Z" fill="#e03131"/><path d="M40 112 Q36 34 100 30 Q164 34 160 112 L148 112 Q148 72 100 70 Q52 72 52 112Z" fill="#ced4da" stroke="#495057" stroke-width="3"/><path d="M100 30 V70" stroke="#495057" stroke-width="3"/>',
      say: ['기사 피피! 이 방송은 내가 지킨다!', '투구 장착! 나쁜 기분은 다 물리칠 거야!'] },
    { id: 'ninja', name: '닌자 머리띠', front: '<path d="M44 84 Q100 70 156 84 L156 96 Q100 82 44 96Z" fill="#343a40"/><rect x="92" y="78" width="16" height="10" rx="2" fill="#adb5bd"/><path d="M156 88 Q176 82 184 94 M156 92 Q172 100 178 112" stroke="#343a40" stroke-width="6" fill="none" stroke-linecap="round"/>',
      say: ['닌자 피피! 슈슉! 언제 숨었는지 모르게 숨을 거야!', '쉿, 닌자는 조용히… 근데 피피는 수다쟁이 닌자야!'], keepAcc: true },
    { id: 'earmuffs', name: '귀마개', front: '<path d="M40 100 C40 34 160 34 160 100" fill="none" stroke="#ffc9de" stroke-width="7" stroke-linecap="round"/><circle cx="34" cy="110" r="18" fill="#fff0f6" stroke="#ff8fb8" stroke-width="3"/><circle cx="166" cy="110" r="18" fill="#fff0f6" stroke="#ff8fb8" stroke-width="3"/><circle cx="30" cy="106" r="4" fill="#ffd6e7"/><circle cx="170" cy="106" r="4" fill="#ffd6e7"/>',
      say: ['귀마개 따뜻해! ...어, 채팅이 안 들려! 아니야, 다 보여!', '말랑말랑 귀마개! 겨울 준비 끝!'], keepAcc: true },
    { id: 'pumpkin', name: '호박 모자', front: '<path d="M58 60 Q54 26 80 22 Q90 16 100 20 Q110 16 120 22 Q146 26 142 60 Q100 68 58 60Z" fill="#ff922b" stroke="#d9480f" stroke-width="3"/><path d="M84 22 Q80 44 86 62 M116 22 Q120 44 114 62 M100 20 V64" stroke="#d9480f" stroke-width="2.5" fill="none"/><path d="M100 20 Q100 8 108 4" stroke="#2b8a3e" stroke-width="5" fill="none" stroke-linecap="round"/>',
      say: ['호박 피피! 할로윈 아니어도 귀엽지?', '호박 모자! 마차로 변신하면 다 태워 줄게!'] },
    { id: 'snowman', name: '눈사람 변장', front: '<g transform="rotate(-12 100 40)"><rect x="80" y="12" width="40" height="34" rx="2" fill="#222"/><ellipse cx="100" cy="46" rx="30" ry="6" fill="#222"/></g><path d="M100 124 L128 130 L100 134Z" fill="#ff922b"/><path d="M44 160 Q100 182 156 160 L158 174 Q100 196 42 174Z" fill="#e03131"/>',
      say: ['눈사람 피피! 당근 코 어때? 녹기 전에 사진 찍어!', '겨울 왕국 피피! 나랑 눈사람 만들래?'] },
    { id: 'rudolph', name: '루돌프', front: '<path d="M70 52 Q60 30 64 12 M66 30 Q52 26 46 14 M64 20 Q72 12 80 12" stroke="#8d5524" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M130 52 Q140 30 136 12 M134 30 Q148 26 154 14 M136 20 Q128 12 120 12" stroke="#8d5524" stroke-width="6" fill="none" stroke-linecap="round"/><circle cx="100" cy="128" r="9" fill="#e03131"/><circle cx="97" cy="125" r="3" fill="#fff" opacity=".7"/>',
      say: ['루돌프 피피! 빨간 코로 방송을 밝혀 줄게!', '사슴뿔 쓰니까 썰매 끌 수 있을 것 같아! 다 타!'] },
    { id: 'bonnet', name: '아기 보닛', front: '<path d="M34 120 Q30 36 100 34 Q170 36 166 120 Q156 72 100 70 Q44 72 34 120Z" fill="#fff0f6" stroke="#f783ac" stroke-width="3"/><path d="M40 96 Q100 60 160 96" fill="none" stroke="#f783ac" stroke-width="2" stroke-dasharray="6 4"/><path d="M40 118 Q34 150 82 162 M160 118 Q166 150 118 162" stroke="#f783ac" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M100 164 L80 154 V174Z M100 164 L120 154 V174Z" fill="#f783ac"/>',
      say: ['아기 피피예요… 응애! 쓰담쓰담 해 주세요!', '보닛 쓰니까 아기가 된 기분! 우유 주세요!'] },
    { id: 'gat', name: '선비 갓', front: '<path d="M60 64 Q56 110 70 150 M140 64 Q144 110 130 150" stroke="#111" stroke-width="1.6" fill="none" stroke-dasharray="2 4"/><path d="M76 58 L80 22 Q100 16 120 22 L124 58" fill="rgba(20,20,20,.78)" stroke="#111" stroke-width="2.5"/><ellipse cx="100" cy="58" rx="72" ry="12" fill="rgba(20,20,20,.55)" stroke="#111" stroke-width="2.5"/>',
      say: ['에헴, 선비 피피라 하오. 오늘 그림은 참으로 훌륭하구려!', '갓 쓰니까 점잖아지는 기분이오. 허허.'] },
    { id: 'fox', name: '여우 귀', front: BAND.replace('COL', '#e8590c') + '<path d="M60 64 L52 18 L88 46Z" fill="#ff922b" stroke="#d9480f" stroke-width="2.5" stroke-linejoin="round"/><path d="M62 56 L58 30 L78 46Z" fill="#fff4e6"/><path d="M140 64 L148 18 L112 46Z" fill="#ff922b" stroke="#d9480f" stroke-width="2.5" stroke-linejoin="round"/><path d="M138 56 L142 30 L122 46Z" fill="#fff4e6"/>',
      say: ['여우 피피! 꼬리 아홉 개는 아직 없어! 헤헤.', '여우 귀 쫑긋! 영리한 피피가 됐어!'] },
    { id: 'puppy', name: '강아지 귀', front: BAND.replace('COL', '#a9744f') + '<path d="M62 56 Q30 56 30 96 Q36 120 52 110 Q60 90 70 62Z" fill="#a9744f" stroke="#6b4226" stroke-width="3"/><path d="M138 56 Q170 56 170 96 Q164 120 148 110 Q140 90 130 62Z" fill="#a9744f" stroke="#6b4226" stroke-width="3"/>',
      say: ['멍멍! 강아지 피피! 쓰담쓰담 해 주면 꼬리 흔들어!', '왈왈! 공 던져 줘! 내가 물어 올게!'] },
    { id: 'unicorn', name: '유니콘 뿔', front: '<path d="M110 52 Q132 40 140 56 Q150 60 148 76 Q160 84 152 100" fill="none" stroke="#b197fc" stroke-width="10" stroke-linecap="round"/><path d="M116 50 Q136 46 142 64" fill="none" stroke="#ff8fb8" stroke-width="8" stroke-linecap="round"/><path d="M90 50 L100 0 L110 50Z" fill="#ffe066" stroke="#e8a400" stroke-width="2.5" stroke-linejoin="round"/><path d="M93 38 L107 34 M95 26 L105 23 M97 14 L103 12" stroke="#e8a400" stroke-width="2"/>',
      say: ['유니콘 피피! 반짝반짝 마법 가루 뿌려 줄게!', '뿔에서 무지개가 나올 것 같아! 히힝!'] },
    { id: 'fairy', name: '요정 날개', back: '<path d="M44 110 Q0 60 20 40 Q44 50 52 96Z M44 120 Q8 150 20 170 Q40 160 52 126Z M156 110 Q200 60 180 40 Q156 50 148 96Z M156 120 Q192 150 180 170 Q160 160 148 126Z" fill="rgba(180,230,255,.55)" stroke="#91d5ff" stroke-width="2.5"/>',
      front: '<circle cx="82" cy="50" r="5" fill="#ffd6e7"/><circle cx="100" cy="46" r="6" fill="#d0bfff"/><circle cx="118" cy="50" r="5" fill="#ffd6e7"/>',
      say: ['요정 피피! 반짝이 가루 뿌리면 소원이 이루어져!', '팔랑팔랑 요정 날개! 꽃밭으로 날아갈래!'] },
    { id: 'vampire', name: '뱀파이어', back: '<path d="M30 190 L40 116 L72 158Z M170 190 L160 116 L128 158Z" fill="#c92a2a" stroke="#5c0a0a" stroke-width="3"/>',
      front: '<path d="M60 170 Q100 186 140 170 L130 160 Q100 172 70 160Z" fill="#222"/><path d="M91 142 l3 9 3-9Z M103 142 l3 9 3-9Z" fill="#fff" stroke="#999" stroke-width="1"/>',
      say: ['뱀파이어 피피! 피 대신 딸기 우유를 마실 거야!', '망토 휘날리며 등장! 무섭지? 귀엽다고? 히잉.'] },
    { id: 'bee', name: '꿀벌', back: '<ellipse cx="36" cy="96" rx="26" ry="16" transform="rotate(-30 36 96)" fill="rgba(220,240,255,.75)" stroke="#a5d8ff" stroke-width="2"/><ellipse cx="164" cy="96" rx="26" ry="16" transform="rotate(30 164 96)" fill="rgba(220,240,255,.75)" stroke="#a5d8ff" stroke-width="2"/>',
      front: BAND.replace('COL', '#222') + '<path d="M80 56 Q72 30 64 22 M120 56 Q128 30 136 22" stroke="#222" stroke-width="3" fill="none"/><circle cx="64" cy="20" r="7" fill="#ffd43b" stroke="#222" stroke-width="2.5"/><circle cx="136" cy="20" r="7" fill="#ffd43b" stroke="#222" stroke-width="2.5"/>',
      say: ['붕붕! 꿀벌 피피! 꿀처럼 달콤한 방송 만들자!', '부지런한 꿀벌 피피! 오늘도 열심히 수다 떨게! 붕붕!'] },
    { id: 'headset', name: '방송 헤드셋', front: '<path d="M36 108 C36 32 164 32 164 108" fill="none" stroke="#343a40" stroke-width="8" stroke-linecap="round"/><rect x="24" y="96" width="22" height="34" rx="9" fill="#ff8fb8" stroke="#343a40" stroke-width="3"/><rect x="154" y="96" width="22" height="34" rx="9" fill="#ff8fb8" stroke="#343a40" stroke-width="3"/><path d="M36 128 Q46 150 78 148" fill="none" stroke="#343a40" stroke-width="4" stroke-linecap="round"/><circle cx="82" cy="148" r="6" fill="#343a40"/>',
      say: ['방송인 피피! 아, 아, 마이크 테스트! 다들 잘 들려?', '헤드셋 썼다! 이제 나도 스트리머야! 구독… 아니, 팔로우 부탁해!'] },
    { id: 'cake', name: '케이크 모자', front: '<rect x="68" y="34" width="64" height="26" rx="4" fill="#ffe3ec" stroke="#f783ac" stroke-width="3"/><path d="M68 40 Q76 48 84 40 Q92 48 100 40 Q108 48 116 40 Q124 48 132 40" fill="none" stroke="#fff" stroke-width="5"/><circle cx="82" cy="32" r="4" fill="#e03131"/><circle cx="118" cy="32" r="4" fill="#e03131"/><rect x="97" y="12" width="6" height="22" fill="#74c0fc"/><path d="M100 2 Q106 8 100 12 Q94 8 100 2Z" fill="#ffa94d"/>',
      say: ['케이크 모자! 오늘 생일인 사람? 아니어도 축하해!', '촛불 켜졌어! 후~ 불어 줘! 소원 빌고!'] },
    { id: 'swim', name: '수영모와 물안경', front: '<path d="M52 82 Q50 26 100 24 Q150 26 148 82 Q100 70 52 82Z" fill="#4dabf7" stroke="#1971c2" stroke-width="3"/><circle cx="84" cy="66" r="11" fill="rgba(200,240,255,.85)" stroke="#e03131" stroke-width="4"/><circle cx="116" cy="66" r="11" fill="rgba(200,240,255,.85)" stroke="#e03131" stroke-width="4"/><path d="M95 66 h10" stroke="#e03131" stroke-width="4"/>',
      say: ['수영 피피! 첨벙첨벙! 화면 속 수영장 개장!', '물안경 썼으니 채팅 바다로 다이빙!'] },
    { id: 'catonhead', name: '머리 위 고양이', front: '<g transform="translate(100 32)"><path d="M20 10 Q34 6 30 -8" stroke="#d9480f" stroke-width="4" fill="none" stroke-linecap="round"/><ellipse cx="0" cy="8" rx="22" ry="14" fill="#ffa94d" stroke="#d9480f" stroke-width="2.5"/><path d="M-13 -18 L-12 -32 L-3 -22Z M13 -18 L12 -32 L3 -22Z" fill="#ffa94d" stroke="#d9480f" stroke-width="2.5" stroke-linejoin="round"/><circle cx="0" cy="-10" r="15" fill="#ffa94d" stroke="#d9480f" stroke-width="2.5"/><circle cx="-5" cy="-10" r="2" fill="#222"/><circle cx="5" cy="-10" r="2" fill="#222"/><path d="M-3 -4 Q0 -2 3 -4" stroke="#222" stroke-width="1.5" fill="none"/></g>',
      say: ['내 머리 위에 고양이가 앉았어! 움직이면 안 돼…!', '고양이 친구가 놀러 왔어! 냐옹~ 같이 인사해!'] },
    { id: 'chick', name: '머리 위 병아리', front: '<g transform="translate(100 32)"><ellipse cx="0" cy="2" rx="18" ry="16" fill="#ffe066" stroke="#e8a400" stroke-width="2.5"/><circle cx="-6" cy="-2" r="2.2" fill="#222"/><circle cx="6" cy="-2" r="2.2" fill="#222"/><path d="M-4 4 L0 10 L4 4Z" fill="#ff922b"/><path d="M-2 -14 Q0 -22 4 -16" stroke="#e8a400" stroke-width="2.5" fill="none"/></g>',
      say: ['삐약! 머리 위에 병아리가 올라왔어! 둥지인 줄 알았나 봐!', '병아리 친구랑 같이 방송해! 삐약삐약!'] },
    { id: 'prince', name: '왕자 망토', back: '<path d="M36 120 Q20 170 28 196 L172 196 Q180 170 164 120 Q100 150 36 120Z" fill="#7048e8" stroke="#4c2bb5" stroke-width="3"/><path d="M36 120 Q100 150 164 120" fill="none" stroke="#ffd43b" stroke-width="4"/>',
      front: '<path d="M80 50 L82 32 L92 42 L100 28 L108 42 L118 32 L120 50Z" fill="#ffd34d" stroke="#b8860b" stroke-width="2.5" stroke-linejoin="round"/>',
      say: ['왕자 피피! 망토 휘날리며 등장!', '오늘은 피피 왕자님이 백성들의 채팅을 듣겠노라!'] },
    { id: 'hero', name: '슈퍼히어로', back: '<path d="M40 120 Q16 172 26 198 L174 198 Q184 172 160 120 Q100 146 40 120Z" fill="#e03131" stroke="#a61e1e" stroke-width="3"/>',
      front: '<path fill-rule="evenodd" d="M52 108 Q60 96 76 98 Q92 100 100 108 Q108 100 124 98 Q140 96 148 108 Q144 128 124 128 Q108 126 100 118 Q92 126 76 128 Q56 128 52 108Z M67 114 a9 10 0 1 0 18 0 a9 10 0 1 0 -18 0Z M115 114 a9 10 0 1 0 18 0 a9 10 0 1 0 -18 0Z" fill="#1c7ed6"/>',
      say: ['슈퍼 피피 출동! 심심함을 물리치러 왔다!', '정의의 이름으로! 오늘 방송을 지키겠어!'] },
    { id: 'heartbop', name: '하트 머리띠', front: BAND.replace('COL', '#f06595') + '<path d="M78 56 Q74 36 70 28 M122 56 Q126 36 130 28" stroke="#f06595" stroke-width="3" fill="none"/><path transform="translate(58 6)" d="' + HEART + '" fill="#ff4f86" stroke="#c2185b" stroke-width="1.5"/><path transform="translate(118 6)" d="' + HEART + '" fill="#ff4f86" stroke="#c2185b" stroke-width="1.5"/>',
      say: ['하트 머리띠! 사랑이 퐁퐁 나와!', '머리 위에 하트 두 개! 하나는 너 거야!'] },
    { id: 'starbop', name: '별 머리띠', front: BAND.replace('COL', '#fab005') + '<path d="M78 56 Q74 36 70 28 M122 56 Q126 36 130 28" stroke="#fab005" stroke-width="3" fill="none"/><path transform="translate(58 6)" d="' + STAR + '" fill="#ffe066" stroke="#e8a400" stroke-width="1.5"/><path transform="translate(118 6)" d="' + STAR + '" fill="#ffe066" stroke="#e8a400" stroke-width="1.5"/>',
      say: ['별 머리띠! 오늘의 스타는 바로 너야!', '반짝반짝 별 머리띠! 피피도 스타 됐다!'] }
];
P.BASE_COSTUMES = P.BASE_COSTUMES.concat(MORE);
P.COSTUMES = P.BASE_COSTUMES.slice();

/* 직접 그린 옷 — 제어판에서 올린 PNG(600×600, 투명)를 피피 위에 그대로 겹친다 */
P.addImageCostumes = function (list, urlOf) {
    (Array.isArray(list) ? list : []).forEach(function (c) {
        if (!c || !c.id || !(c.front || c.back)) return;
        var img = function (f) { return f ? '<image href="' + String(urlOf(f)).replace(/"/g, '&quot;') + '" x="0" y="0" width="200" height="200" preserveAspectRatio="xMidYMid meet"/>' : ''; };
        P.COSTUMES = P.COSTUMES.filter(function (x) { return x.id !== c.id; });
        P.COSTUMES.push({ id: c.id, name: String(c.name || '내가 그린 옷'), front: img(c.front), back: img(c.back), keepAcc: !!c.keepAcc, say: Array.isArray(c.say) ? c.say : [], mine: true });
    });
};
})(typeof window !== 'undefined' ? window : this);

/* ═══════════════════════════════════════════════════════════════════════
   2.1 — 기념일 · 피피 생일(10월 31일)
   음력 기념일(설날·대보름·부처님 오신 날·칠석·추석)은 양력 날짜표를 씁니다.
   표에 없는 해는 브라우저 달력(Intl dangi)으로 계산해요.
   ═══════════════════════════════════════════════════════════════════════ */
(function (root) {
'use strict';
var P = root.PIPI;
P.LUNAR = {2024:'0210,0224,0515,0810,0917', 2025:'0129,0212,0505,0829,1006', 2026:'0217,0303,0524,0819,0925', 2027:'0207,0221,0513,0808,0915', 2028:'0127,0210,0502,0826,1003', 2029:'0213,0227,0520,0816,0922', 2030:'0203,0217,0509,0805,0912', 2031:'0123,0206,0528,0824,1001', 2032:'0211,0225,0516,0812,0919', 2033:'0131,0214,0506,0801,0908', 2034:'0219,0305,0525,0820,0927', 2035:'0208,0222,0515,0810,0916', 2036:'0128,0211,0503,0828,1004', 2037:'0215,0301,0522,0817,0924', 2038:'0204,0218,0511,0807,0913', 2039:'0124,0207,0430,0826,1002', 2040:'0212,0226,0518,0814,0921', 2041:'0201,0215,0507,0803,0910', 2042:'0122,0205,0526,0822,0928', 2043:'0210,0224,0516,0811,0917', 2044:'0130,0213,0505,0731,1005', 2045:'0217,0303,0524,0819,0925', 2046:'0206,0220,0513,0808,0915', 2047:'0126,0209,0502,0827,1004', 2048:'0214,0228,0520,0816,0922', 2049:'0202,0216,0509,0805,0911', 2050:'0123,0206,0528,0823,0930'};
P.PIPI_BIRTHDAY = '1031';
P.HOLIDAYS = [
    { id: 'newyear', name: '새해 첫날', md: '0101', cos: ['partyhat'], fx: ['firework', 'confetti:big'], doodle: 'hny', k: ['새해', '신정', '1월 1일'] },
    { id: 'seollal', name: '설날', lunar: 0, span: [1, 1], cos: ['gat'], fx: ['firework', 'sparkle'], doodle: 'hny', k: ['설날', '구정', '세배', '떡국'] },
    { id: 'boreum', name: '정월대보름', lunar: 1, cos: ['moonstar'], fx: ['sparkle'], doodle: 'fullmoon', k: ['대보름', '부럼'] },
    { id: 'valentine', name: '밸런타인데이', md: '0214', cos: ['heartbop'], fx: ['hearts', 'throwheart'], doodle: 'love', k: ['밸런타인', '발렌타인'] },
    { id: 'samil', name: '삼일절', md: '0301', calm: true, k: ['삼일절', '3.1절', '삼일 절'] },
    { id: 'whiteday', name: '화이트데이', md: '0314', cos: ['bow'], fx: ['hearts', 'sparkle'], doodle: 'love', k: ['화이트데이'] },
    { id: 'aprilfool', name: '만우절', md: '0401', cos: ['detective', 'sunglasses'], fx: ['giggle'], k: ['만우절'] },
    { id: 'arbor', name: '식목일', md: '0405', cos: ['strawhat'], fx: ['plant', 'flowers'], doodle: 'tree', k: ['식목일', '나무 심'] },
    { id: 'blackday', name: '블랙데이', md: '0414', cos: ['sunglasses'], fx: ['snack'], k: ['블랙데이', '짜장면'] },
    { id: 'buddha', name: '부처님 오신 날', lunar: 2, fx: ['sparkle'], k: ['부처님', '석가탄신일', '초파일', '연등'] },
    { id: 'children', name: '어린이날', md: '0505', cos: ['cap', 'partyhat'], fx: ['balloon', 'confetti'], doodle: 'balloon', k: ['어린이날'] },
    { id: 'parents', name: '어버이날', md: '0508', cos: ['flowercrown'], fx: ['flowers'], doodle: 'flower', k: ['어버이날', '카네이션'] },
    { id: 'teachers', name: '스승의 날', md: '0515', cos: ['gradcap'], fx: ['flowers'], k: ['스승의 날', '스승의날'] },
    { id: 'memorial', name: '현충일', md: '0606', calm: true, k: ['현충일'] },
    { id: 'chilseok', name: '칠석', lunar: 3, cos: ['moonstar'], fx: ['shootingstar'], k: ['칠석', '견우', '직녀', '오작교'] },
    { id: 'liberation', name: '광복절', md: '0815', calm: true, k: ['광복절'] },
    { id: 'chuseok', name: '추석', lunar: 4, span: [1, 1], cos: ['gat'], fx: ['sparkle'], doodle: 'fullmoon', k: ['추석', '한가위', '송편'] },
    { id: 'gaecheon', name: '개천절', md: '1003', calm: true, k: ['개천절'] },
    { id: 'hangul', name: '한글날', md: '1009', cos: ['gradcap', 'beret'], fx: ['sparkle'], doodle: 'hangul', k: ['한글날', '세종대왕'] },
    { id: 'pipibday', name: '피피 생일', md: P.PIPI_BIRTHDAY, cos: ['partyhat', 'cake', 'crown'], fx: ['confetti:big', 'firework'], doodle: 'cake', k: [] },
    { id: 'halloween', name: '할로윈', md: '1031', cos: ['witch', 'pumpkin', 'sheet', 'vampire'], fx: ['bubbles'], doodle: 'ghost', k: ['할로윈', '핼러윈', '트릭 오어 트릿', '트릭오어트릿'] },
    { id: 'pepero', name: '빼빼로데이', md: '1111', cos: ['heartbop'], fx: ['hearts'], doodle: 'pepero', k: ['빼빼로'] },
    { id: 'dongji', name: '동지', md: '1222', span: [1, 0], cos: ['beanie'], fx: ['snack'], k: ['동지', '팥죽'] },
    { id: 'xmaseve', name: '크리스마스이브', md: '1224', cos: ['santa', 'rudolph'], fx: ['sparkle'], doodle: 'tree', k: ['크리스마스이브', '크리스마스 이브'] },
    { id: 'xmas', name: '크리스마스', md: '1225', cos: ['santa', 'rudolph', 'snowman'], fx: ['firework', 'sparkle'], doodle: 'snowman', k: ['크리스마스', '성탄절', '메리 크리스마스', '메리크리스마스'] },
    { id: 'yearend', name: '한 해의 마지막 날', md: '1231', cos: ['partyhat', 'nightcap'], fx: ['sparkle', 'firework'], k: ['연말', '송년', '마지막 날', '12월 31일'] }
];
P.holidayById = function (id) { return P.HOLIDAYS.filter(function (h) { return h.id === id; })[0] || null; };
var dangi = null;
function lunarMd(year, idx) {
    var t = P.LUNAR[year];
    if (t) return t.split(',')[idx];
    try {   /* 표 밖의 해 — 브라우저 달력으로 계산 */
        if (!dangi) dangi = new Intl.DateTimeFormat('ko-KR-u-ca-dangi', { month: 'numeric', day: 'numeric' });
        var want = ['1/1', '1/15', '4/8', '7/7', '8/15'][idx];
        for (var d = new Date(year, 0, 1, 12); d.getFullYear() === year; d.setDate(d.getDate() + 1)) {
            var p = dangi.formatToParts(d), key = p.filter(function (x) { return x.type === 'month'; })[0].value + '/' + p.filter(function (x) { return x.type === 'day'; })[0].value;
            if (key === want) return ('0' + (d.getMonth() + 1)).slice(-2) + ('0' + d.getDate()).slice(-2);
        }
    } catch (e) {}
    return null;
}
P.holidayDate = function (h, year) {
    var md = h.lunar !== undefined ? lunarMd(year, h.lunar) : h.md;
    if (!md) return null;
    return new Date(year, Number(md.slice(0, 2)) - 1, Number(md.slice(2)), 12);
};
function dayNum(d) { return Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 864e5); }
/* 오늘 해당하는 기념일들 (설날·추석은 앞뒤 하루씩 연휴) */
P.holidaysOn = function (now) {
    now = now || new Date();
    var today = dayNum(now), out = [];
    P.HOLIDAYS.forEach(function (h) {
        [now.getFullYear() - 1, now.getFullYear(), now.getFullYear() + 1].forEach(function (y) {
            var d = P.holidayDate(h, y); if (!d) return;
            var diff = today - dayNum(d), sp = h.span || [0, 0];
            if (diff >= -sp[0] && diff <= sp[1] && out.indexOf(h) < 0) { out.push(h); h._off = diff; }
        });
    });
    return out;
};
/* 그 기념일까지 며칠 남았는지 (오늘이면 0) */
P.daysUntil = function (h, now) {
    now = now || new Date();
    var today = dayNum(now), best = null;
    [now.getFullYear(), now.getFullYear() + 1].forEach(function (y) {
        var d = P.holidayDate(h, y); if (!d) return;
        var n = dayNum(d) - today;
        if (n >= 0 && (best === null || n < best)) best = n;
    });
    return best;
};
/* 며칠 안에 다가오는 기념일 하나 */
P.holidaySoon = function (now, within) {
    var best = null;
    P.HOLIDAYS.forEach(function (h) { var n = P.daysUntil(h, now); if (n !== null && n >= 1 && n <= (within || 3) && (!best || n < best.days)) best = { h: h, days: n }; });
    return best;
};
P.whenWord = function (n) { return n === 0 ? '오늘' : n === 1 ? '내일' : n === 2 ? '모레' : n + '일 뒤'; };
})(typeof window !== 'undefined' ? window : this);

/* ═══════════════════════════════════════════════════════════════════════
   2.5 — 장난감 · 음식 (오버레이 연출과 제어판 목록이 함께 씀)
   장난감 mode: yoyo spin hug float roll shoot wave stack squish disco boomerang game puzzle hoop wobble shake toss pinwheel
   음식 react: yum love spicy hot cold bitter dislike sour big drink chewy
   ═══════════════════════════════════════════════════════════════════════ */
(function (root) {
'use strict';
var P = root.PIPI;
P.TOYS = [
    { id: 'yoyo', name: '요요', e: '🪀', mode: 'yoyo', k: ['요요'], say: ['요요 묘기! 슝~ 하고 쭉!', '요요가 돌아왔다! 착착!'] },
    { id: 'top', name: '팽이', svg: 'top', mode: 'spin', k: ['팽이'], say: ['팽이 돌리기! 누가 오래 도나 시합할래?', '빙글빙글… 아직 돈다! 아직!'] },
    { id: 'teddy', name: '곰인형', e: '🧸', mode: 'hug', k: ['곰인형', '인형', '곰돌이'], say: ['곰인형 꼬옥! 폭신폭신해!', '곰돌이랑 낮잠 자고 싶다…'] },
    { id: 'duck', name: '고무오리', e: '🦆', mode: 'float', k: ['고무오리', '오리', '러버덕'], say: ['꽥꽥! 고무오리 둥실둥실~', '오리야, 수영하자! 첨벙!'] },
    { id: 'car', name: '장난감 자동차', e: '🚗', mode: 'roll', k: ['자동차', '장난감차', '미니카', '차'], say: ['부릉부릉! 장난감 자동차 출발!', '빵빵! 비켜 주세요~'] },
    { id: 'dart', name: '다트', e: '🎯', mode: 'shoot', k: ['다트', '과녁'], say: ['다트 던지기! 한가운데 맞혀 볼게!', '슉! 과녁을 노려라!'] },
    { id: 'basket', name: '농구공', e: '🏀', mode: 'shoot', k: ['농구', '농구공'], say: ['슛! 들어가라!', '피피 3점 슛 도전!'] },
    { id: 'bowling', name: '볼링', e: '🎳', mode: 'shoot', k: ['볼링'], say: ['볼링 한 판! 스트라이크 가자!', '데굴데굴~ 다 쓰러져라!'] },
    { id: 'wand', name: '요술봉', e: '🪄', mode: 'wave', k: ['요술봉', '마법봉', '지팡이'], say: ['얍! 요술봉으로 반짝반짝 마법!', '뾰로롱~ 다들 행복해져라!'] },
    { id: 'blocks', name: '블록', svg: 'blocks', mode: 'stack', k: ['블록', '레고', '쌓기', '젠가'], say: ['블록 쌓기! 높이높이~', '하나, 둘, 셋… 조심조심…'] },
    { id: 'slime', name: '슬라임', svg: 'slime', mode: 'squish', k: ['슬라임', '액괴'], say: ['슬라임 말랑말랑~ 쭈욱!', '찰싹! 손에 붙었다!'] },
    { id: 'disco', name: '미러볼', e: '🪩', mode: 'disco', k: ['미러볼', '디스코'], say: ['미러볼 반짝! 파티 타임!', '불빛이 빙글빙글~ 춤추자!'] },
    { id: 'boomerang', name: '부메랑', e: '🪃', mode: 'boomerang', k: ['부메랑'], say: ['부메랑 던진다! 돌아와라~', '슝~ 어디까지 갔지?'] },
    { id: 'console', name: '게임기', e: '🎮', mode: 'game', k: ['게임기', '게임', '닌텐도'], say: ['게임 한 판만! 진짜 한 판만!', '보스전이다! 집중!'] },
    { id: 'puzzle', name: '퍼즐', e: '🧩', mode: 'puzzle', k: ['퍼즐', '조각'], say: ['퍼즐 맞추기! 이 조각은… 여기!', '마지막 한 조각! 딸깍!'] },
    { id: 'hoop', name: '훌라후프', svg: 'hoop', mode: 'hoop', k: ['훌라후프', '후프'], say: ['훌라후프 돌리기! 허리 운동!', '빙글빙글… 안 떨어뜨릴 거야!'] },
    { id: 'roly', name: '오뚝이', e: '🪆', mode: 'wobble', k: ['오뚝이', '마트료시카'], say: ['오뚝이야, 쓰러져도 다시 일어나!', '톡! 데굴… 벌떡! 대단해!'] },
    { id: 'maracas', name: '마라카스', e: '🪇', mode: 'shake', k: ['마라카스', '탬버린', '딸랑이'], say: ['차차차! 마라카스 흔들흔들!', '리듬 타자! 차카차카!'] },
    { id: 'yarn', name: '털실 공', e: '🧶', mode: 'roll', k: ['털실', '실타래'], say: ['털실 공 굴리기! 데굴데굴~', '앗, 털실이 엉켰다…!'] },
    { id: 'pinwheel', name: '바람개비', svg: 'pinwheel', mode: 'pinwheel', k: ['바람개비'], say: ['후~ 불면 바람개비가 빙글빙글!', '바람아 불어라~'] },
    { id: 'jacks', name: '공기', svg: 'jacks', mode: 'toss', k: ['공기', '공기놀이'], say: ['공기놀이! 하나 집고… 받고!', '꺾기까지 가 볼게!'] },
    { id: 'kite2', name: '종이학', e: '🕊️', mode: 'wave', k: ['종이학', '종이접기'], say: ['종이학 접었어! 날아라~', '천 마리 접으면 소원 이뤄진대!'] }
];
P.FOODS = [
    /* 달콤 */
    { id: 'strawberry', name: '딸기', e: '🍓', r: 'love', k: ['딸기'] }, { id: 'cake', name: '케이크', e: '🍰', r: 'love', k: ['케이크', '조각케이크'] },
    { id: 'icecream', name: '아이스크림', e: '🍦', r: 'cold', k: ['아이스크림', '소프트콘'] }, { id: 'donut', name: '도넛', e: '🍩', r: 'yum', k: ['도넛', '도너츠'] },
    { id: 'cookie', name: '쿠키', e: '🍪', r: 'yum', k: ['쿠키', '과자'] }, { id: 'candy', name: '사탕', e: '🍬', r: 'yum', k: ['사탕', '캔디'] },
    { id: 'choco', name: '초콜릿', e: '🍫', r: 'yum', k: ['초콜릿', '초코'] }, { id: 'cupcake', name: '컵케이크', e: '🧁', r: 'love', k: ['컵케이크', '머핀', '마카롱'] },
    { id: 'pudding', name: '푸딩', e: '🍮', r: 'yum', k: ['푸딩'] }, { id: 'bingsu', name: '빙수', e: '🍧', r: 'cold', k: ['빙수', '팥빙수'] },
    { id: 'lollipop', name: '막대사탕', e: '🍭', r: 'yum', k: ['막대사탕', '솜사탕'] }, { id: 'hotteok', name: '호떡', e: '🥞', r: 'hot', k: ['호떡', '팬케이크'] },
    { id: 'bungeo', name: '붕어빵', e: '🐟', r: 'hot', k: ['붕어빵', '잉어빵'] }, { id: 'tteok', name: '떡', e: '🍡', r: 'chewy', k: ['떡', '경단', '찹쌀떡'] },
    /* 식사 */
    { id: 'gimbap', hasVeg: true, name: '김밥', e: '🍙', r: 'yum', k: ['김밥', '주먹밥', '삼각김밥'] }, { id: 'ramen', name: '라면', e: '🍜', r: 'hot', k: ['라면', '국수', '우동'] },
    { id: 'tteokbokki', name: '떡볶이', e: '🌶️', r: 'spicy', k: ['떡볶이', '떡볶기'] }, { id: 'chicken', name: '치킨', e: '🍗', r: 'love', k: ['치킨', '통닭'] },
    { id: 'pizza', hasVeg: true, name: '피자', e: '🍕', r: 'yum', k: ['피자'] }, { id: 'burger', name: '햄버거', e: '🍔', r: 'big', k: ['햄버거', '버거'] },
    { id: 'hotdog', name: '핫도그', e: '🌭', r: 'yum', k: ['핫도그', '소시지'] }, { id: 'jjajang', hasVeg: true, name: '짜장면', e: '🍝', r: 'yum', k: ['짜장면', '짜장', '스파게티', '파스타'] },
    { id: 'curry', hasVeg: true, name: '카레', e: '🍛', r: 'hot', k: ['카레', '볶음밥'] }, { id: 'sushi', name: '초밥', e: '🍣', r: 'yum', k: ['초밥', '스시'] },
    { id: 'dumpling', hasVeg: true, name: '만두', e: '🥟', r: 'hot', k: ['만두'] }, { id: 'sandwich', hasVeg: true, name: '샌드위치', e: '🥪', r: 'yum', k: ['샌드위치', '토스트'] },
    { id: 'egg', name: '계란 프라이', e: '🍳', r: 'yum', k: ['계란', '달걀', '계란프라이'] }, { id: 'rice', name: '밥', e: '🍚', r: 'yum', k: ['밥', '쌀밥', '공기밥'] },
    { id: 'soup', name: '국', e: '🥣', r: 'hot', k: ['국', '떡국', '미역국', '수프'] }, { id: 'taco', name: '타코', e: '🌮', r: 'yum', k: ['타코'] },
    { id: 'pepper', name: '고추', e: '🌶️', r: 'spicy', k: ['고추', '청양고추', '매운'] },
    /* 과일 · 채소 */
    { id: 'apple', name: '사과', e: '🍎', r: 'yum', k: ['사과'] }, { id: 'banana', name: '바나나', e: '🍌', r: 'yum', k: ['바나나'] },
    { id: 'watermelon', name: '수박', e: '🍉', r: 'big', k: ['수박'] }, { id: 'grape', name: '포도', e: '🍇', r: 'yum', k: ['포도', '샤인머스캣'] },
    { id: 'tangerine', name: '귤', e: '🍊', r: 'yum', k: ['귤', '오렌지', '한라봉'] }, { id: 'peach', name: '복숭아', e: '🍑', r: 'love', k: ['복숭아'] },
    { id: 'cherry', name: '체리', e: '🍒', r: 'yum', k: ['체리'] }, { id: 'lemon', name: '레몬', e: '🍋', r: 'sour', k: ['레몬', '자몽'] },
    { id: 'carrot', name: '당근', e: '🥕', r: 'dislike', veg: true, k: ['당근'] }, { id: 'broccoli', name: '브로콜리', e: '🥦', r: 'dislike', veg: true, k: ['브로콜리'] },
    { id: 'cucumber', name: '오이', e: '🥒', r: 'dislike', veg: true, k: ['오이'] }, { id: 'onion', name: '양파', e: '🧅', r: 'dislike', veg: true, k: ['양파', '파', '대파', '쪽파'] },
    { id: 'mushroom', name: '버섯', e: '🍄', r: 'dislike', veg: true, k: ['버섯', '표고'] }, { id: 'eggplant', name: '가지', e: '🍆', r: 'dislike', veg: true, k: ['가지'] },
    { id: 'spinach', name: '시금치', e: '🥬', r: 'dislike', veg: true, k: ['시금치', '나물', '상추', '양배추', '배추'] }, { id: 'bellpepper', name: '피망', e: '🫑', r: 'dislike', veg: true, k: ['피망', '파프리카'] },
    { id: 'kimchi', name: '김치', e: '🥬', r: 'dislike', veg: true, k: ['김치', '깍두기'] }, { id: 'beans', name: '콩', e: '🫘', r: 'dislike', veg: true, k: ['콩', '콩밥', '완두콩'] },
    { id: 'sweetpotato', name: '군고구마', e: '🍠', r: 'hot', k: ['고구마', '군고구마'] }, { id: 'corn', name: '옥수수', e: '🌽', r: 'yum', k: ['옥수수'] },
    /* 마실 것 */
    { id: 'milk', name: '우유', e: '🥛', r: 'drink', k: ['우유'] }, { id: 'strawmilk', name: '딸기우유', e: '🍓🥛', r: 'love', k: ['딸기우유', '딸우'] },
    { id: 'juice', name: '주스', e: '🧃', r: 'drink', k: ['주스', '쥬스'] }, { id: 'bubbletea', name: '버블티', e: '🧋', r: 'drink', k: ['버블티', '밀크티', '타피오카'] },
    { id: 'coffee', name: '커피', e: '☕', r: 'bitter', k: ['커피', '아메리카노', '아아'] }, { id: 'cocoa', name: '핫초코', e: '☕', r: 'hot', k: ['핫초코', '코코아'] },
    { id: 'soda', name: '콜라', e: '🥤', r: 'drink', k: ['콜라', '사이다', '탄산'] }
];
function findIn(list, txt) {
    var w = String(txt || '').replace(/\s/g, ''), best = null, bl = 0;
    if (!w) return null;
    list.forEach(function (it) { it.k.concat([it.name]).forEach(function (k) { k = k.replace(/\s/g, ''); if (k && w.indexOf(k) >= 0 && k.length > bl) { best = it; bl = k.length; } }); });
    return best;
}
P.findToy = function (txt) { return findIn(P.TOYS, txt); };
P.findFood = function (txt) {
    var f = findIn(P.FOODS, txt);
    if (!f && /야채|채소|샐러드|풀/.test(String(txt || ''))) { var v = P.FOODS.filter(function (x) { return x.veg; }); f = v[Math.floor(Math.random() * v.length)]; }
    return f;
};
})(typeof window !== 'undefined' ? window : this);
