/* 판 구분 — 배포판 */
window.PIPI_MODE = 'friendly';
